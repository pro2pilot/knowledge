# Install .knowledge

This copy belongs to **3.4.4 RC5**, an unpublished audit candidate packaged as
`knowledge-v3.4.4.zip`. Its full release gate has not been run. For ordinary
production installation use the [latest published release](https://github.com/pro2pilot/knowledge/releases/latest).
To test this candidate, use its explicitly supplied ZIP and the setup commands
below. Never substitute GitHub source downloads for a release asset.

This is audit revision `independent-audit.20261020.windows.4`. For this specific audit, select
`candidate/knowledge-v3.4.4.zip` from the accompanying Windows follow-up handoff and
verify its new SHA and `audit_revision`; version-only update checks do not
distinguish it from the original RC5. Native verification is unavailable on
Linux/macOS. See [audit installation and limits](docs/verification-execution-contract.md).

> **AI agents/installers:** install from the latest GitHub release asset, not from repo source.

Use this file when installing `.knowledge` into another repository.

## Install Contract

- Do not clone this repository into the target project.
- Do not use GitHub **Code > Download ZIP**.
- Do not use GitHub-generated `Source code (zip)` or `Source code (tar.gz)`.
- Download only the latest release asset named `knowledge-vX.Y.Z.zip`.
- Keep any source checkout outside the target project.
- The target project must not contain `knowledge-src/`.
- Install only the active agent runtime during first setup. Do not create every
  vendor integration folder unless a human explicitly asks for that.

Canonical install source:

```txt
https://github.com/pro2pilot/knowledge/releases/latest
```

Expected target layout after extraction:

```txt
.knowledge/
```

Optional files after installing an agent integration:

```txt
.agents/skills/
AGENTS.md
```

Incorrect target layout:

```txt
knowledge-src/
.knowledge/.git/
.knowledge/.github/
```

## Setup

From the target repository root:

```bash
node .knowledge/tools/install-check.js --json
node .knowledge/tools/install-agent-integrations.js --runtime codex
node .knowledge/tools/flow.js import
node .knowledge/inspector.js
```

Replace `codex` with a supported runtime from the Quick Start table when needed.
Unlisted agents should follow the [general connection recipe](Quick-Start.md#connect-an-agent-without-a-dedicated-recipe).

Other supported agents can connect later using their listed runtime identifier
against the existing `.knowledge/` installation. The `--all --confirm-all` mode
is only for deliberate multi-integration setup, not first install.

## Connect Another Agent Later

For a supported agent from the Quick Start table, use its runtime identifier
from the same target repository root. Unlisted agents should use the general
recipe linked above:

```bash
node .knowledge/tools/install-check.js --json
node .knowledge/tools/install-agent-integrations.js --runtime <supported-runtime>
node .knowledge/tools/flow.js doctor
```

Then the new agent starts meaningful work with `agent-task begin` and reads
its returned `route.first_read.content`. Global routing and handoff summaries
remain orientation aids. For an agent without a dedicated adapter, follow the
[general Quick Start recipe](Quick-Start.md#connect-an-agent-without-a-dedicated-recipe).

If `install-check` reports `source_checkout_in_target_root`, move the source
checkout outside the target project and rerun the check before import.

Native verification on Windows uses the bundled Job Object helper through
Windows PowerShell. The host must permit its local `Add-Type` compilation and
job assignment. If these operations are unavailable, verification fails before
starting probes. Linux/macOS native verification returns
`verification_containment_unavailable` before starting a worker or probe.
Other tools remain subject to their own operational checks. See
[the RC5 contract](docs/audit-3.4.4-rc5.md).

## Accepted verification and Team results (RC5)

Native verify now returns signed `verification_acceptances`. Keep this field
when reusing KVE IDs in a receipt; `agent-task finish` carries it automatically.
Legacy KVE is command-only evidence and cannot authorize new certification.
Team Status and Inspector show the final per-attempt outcome after release;
missing finalization is incomplete, not successful. See the
[acceptance and retry contract](docs/verification-execution-contract.md).
Linux/macOS native execution remains unavailable. The full release gate has
not been run; use the updated handoff SHA to identify this unpublished RC5.
