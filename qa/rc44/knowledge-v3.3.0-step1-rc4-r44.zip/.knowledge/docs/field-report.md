# Field Report

Field Report is a semi-automatic, agent-assisted account of real `.knowledge` use, not a benchmark. Local facts come from runtime artifacts; usefulness, accuracy, speed, limitations, publication permission, and reuse permission remain the tester's judgments.

## Safe workflow

```bash
node .knowledge/tools/field-report.js start --new --language=<source-bcp47> --public-language=<public-bcp47> --json
node .knowledge/tools/field-report.js questions --report-id=<id> --json
node .knowledge/tools/field-report.js ingest --report-id=<id> --answers=<path>
node .knowledge/tools/field-report.js render --report-id=<id>
node .knowledge/tools/field-report.js approve --report-id=<id> --yes
node .knowledge/tools/field-report.js publish --report-id=<id> --yes --dry-run --tester-actor=<github-login>
```

Ask only the questions returned by `questions --json`. Show the tester `public.md` and `redaction-report.json` before approval. Approval binds the exact title/body, semantic facts, routing snapshot, canonical baseline, metrics comparison, live-input digest, readiness, continuation, translation, and redaction identities. A semantic edit invalidates approval; collection timestamps and other excluded runtime metadata do not.

Set both languages explicitly when starting a report. If `--language=auto` is
used, resolve it once with
`translation-export --language=<source-bcp47>`; the resolved source language is
then immutable. When source and public languages differ, run:

```bash
node .knowledge/tools/field-report.js translation-export --report-id=<id> --json
node .knowledge/tools/field-report.js translation-ingest --report-id=<id> --answers=<translation.json>
node .knowledge/tools/field-report.js translation-approve --report-id=<id> --yes --tester-actor=<independent-reviewer>
node .knowledge/tools/field-report.js render --report-id=<id>
```

The translation response must identify `provider`, `model`, and `actor`, retain
the exported `original_hash`, and attest that it adds no facts, does not soften
negative answers, and preserves uncertainty. The approving tester/reviewer
must be explicitly identified and must not be the translator. Rendering
revalidates the identity, hashes, and attestations.

Actual GitHub publication is a second explicit action without `--dry-run` and
with `--confirm-preview=<exact-preview-hash>`. The default target is
`pro2pilot/knowledge`, category `field-reports`. Before the remote create, a
write-ahead journal binds the report, actor, target, approved content, preview,
and idempotency marker. If the outcome is unknown, the report enters
`reconciliation_required`; the next final-publish attempt searches for that
exact marker before it can create anything. Ambiguous matches or a content-hash
mismatch fail closed and never create another Discussion. There is no
republish override, and a published report cannot be published again.

If automated publication is unavailable, copy `discussion-title.txt` and `discussion-body.md` into the GitHub Discussion form manually. The bundled schema is pinned to the current form field IDs and dropdown labels; contract drift fails closed before the interview starts.

## Automatic facts and rendering

The facts file uses `knowledge-field-report-facts.v2`. Each fact carries its
value, kind (`observed`, `derived`, or `unavailable`), source, schema path,
collection time, confidence, and warning. Trust metrics remain distinct:
`modules_suspect`, `modules_low_confidence`, and
`modules_needing_recheck` (the unique union of `suspect`,
`low_confidence`, and `needs_recheck`). Repair metrics also remain distinct:
open, completed/closed, reopened, and unmanaged.

When exactly one task snapshot is available, Field Report additionally records
its scope and source, workspace/task module and path counts, unrelated-path
narrowing, canonical workspace-baseline recipe and identity, required-source
state, comparison validity, claim eligibility, and measurement kind.
Workspace-wide debt and task-relevant findings remain separate. An ineligible,
non-comparable, or explicitly stale route does not block report rendering,
approval, or offline preview. The public report names the limitation and omits
the comparative percentage. Relevant source/trust drift still invalidates the
approval until routing is refreshed and the report is rendered and approved
again.

The comparison kind is `workspace_to_task_first_read_narrowing`: a canonical
workspace-wide first read versus the task-scoped first read for the selected
task. It is intentionally not a same-scope, release-version, provider-token,
speed, accuracy, or error-rate comparison. The report separates
`Workspace-wide`, `Task-scoped`, and `Estimated local context` facts. The last
section is rendered only through the shared exclusive formatter as narrowing,
overhead, neutral, or unavailable, with the local-estimate disclaimer. Raw
assessment enums are never public output. A single-project workspace is
identified as such because fixed overhead may limit narrowing.

Enum identifiers are converted to their labels only while rendering their
typed Field Report fields. Free-form tester text is never post-processed, so
identifiers in prose, inline code, fenced code, links, and tables are preserved
byte-for-byte.

## Evidence rules

- Agents must not invent answers, make negative answers more positive, or approve on the tester's behalf.
- Ask at most one useful follow-up when an answer is vague or lacks evidence.
- Preserve the tester's original language and meaning. Translation is agent-assisted, identity-attributed, and must be approved by an independent tester.
- `measured` speed derives a signed percentage from comparable durations: positive is faster, negative is slower.
- `estimated_from_comparable_tasks` and `general_observation` are not measurements.
- Accuracy is never inferred from doctor score, test success, or flow duration.
- GitHub publication permission and external-reuse permission are separate required answers.

## Privacy and storage

Artifacts live under `<stateRoot>/reports/field-reports/<report-id>/`: original and public answers, facts, provenance, draft/public Markdown, redaction report, Discussion payload, and publication record. Writes are atomic and report-specific locks prevent concurrent mutation.

Before rendering, local paths, emails, credentials, tokens, and private URLs are redacted. High-severity unresolved secrets block approval and publication. `--anonymize` hides repository identity and owner. No telemetry, upload, or network request happens before explicit `publish`. By default `--dry-run` is an offline preview and never creates a Discussion; add `--verify-remote` only when a live GitHub viewer/repository/category check is intended.

The CLI accepts the shared context flags, including `--system-root`,
`--target-root`, `--project-knowledge-root`, `--state-root`, and the team-mode
flags. Repeat the same flags on noninteractive follow-up commands, or provide
the equivalent `KNOWLEDGE_*` environment variables, so report state remains in
the intended isolated workspace.

`field-report --help` exits successfully before context resolution and has no
filesystem or network side effects. An unknown flag exits with code 2 before
context resolution and likewise leaves report state untouched.

To remove an unfinished report, first confirm the exact report ID and delete only that report directory. Runtime report directories are excluded from release packages and ignored by the installed Git policy.

## Agent protocol

When a user asks for a Field Report, resolve the intended source and public
languages, run `questions --json`, ask only the returned questions, and ingest
the answers. If translation is required, export its contract, retain the
translator identity and attestations, and stop for an independent tester
review before rendering. Show the public draft and redaction report, then stop
for explicit approval. Create a publication preview only on request; publish
only after a separate explicit request that supplies the exact preview hash.
If reconciliation is required, preserve the journal and reconcile it rather
than starting a fresh publication.
