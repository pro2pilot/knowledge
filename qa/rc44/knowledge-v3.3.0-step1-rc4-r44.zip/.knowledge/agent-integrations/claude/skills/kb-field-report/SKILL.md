---
name: kb-field-report
description: Prepare a tester-approved Field Report from real .knowledge use without inventing evidence or publishing automatically.
---

Use the Field Report CLI as a progressive-disclosure interview.

1. Start with explicit `--language=<source-bcp47>` and
   `--public-language=<public-bcp47>`, or resume with
   `node .knowledge/tools/field-report.js questions --json`. If the source was
   deliberately set to `auto`, resolve it once through
   `translation-export --language=<source-bcp47>`.
2. Ask only the returned questions. Preserve negative and uncertain answers; ask at most one concrete follow-up when evidence is vague.
3. Save the answers as JSON and run `ingest --report-id=<id> --answers=<path>`.
   If source and public languages differ, use `translation-export`, require a
   complete translator identity (`provider`, `model`, `actor`) and all safety
   attestations, then use `translation-ingest`.
4. Run `translation-approve --yes --tester-actor=<independent-reviewer>` only
   after that tester reviews the translation. The reviewer must not be the
   translator. Then render.
5. Show the tester `public.md` and the redaction status. Do not approve on the tester's behalf.
6. Run `approve --report-id=<id> --yes` only after the tester explicitly approves that exact draft.
7. On a separate request, create an actor-bound preview with
   `publish --dry-run --yes --tester-actor=<github-login>`. Actual publication
   requires another explicit request and
   `--confirm-preview=<exact-preview-hash>`.

Never infer usefulness, accuracy, speed, publication permission, or external-reuse permission from doctor scores or test results. Label measurements, estimates, observations, and agent-assisted translations accurately. A high-severity redaction finding blocks approval and publication.

Publication has no republish override. If its state is `publishing` or
`reconciliation_required`, keep the durable journal and run the same confirmed
final-publication command so the exact idempotency marker is reconciled first.
Never start a fresh create or edit the bound artifacts to escape
reconciliation.
