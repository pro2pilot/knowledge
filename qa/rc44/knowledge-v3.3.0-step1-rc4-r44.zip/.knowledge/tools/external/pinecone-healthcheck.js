#!/usr/bin/env node
'use strict';
const pc=require('./pinecone-common');
const {systemVersion}=require('../lib/system-version');
async function main(options={}){const e=pc.env(); const result={schema_version:systemVersion(),generated_at:new Date().toISOString(),provider:'pinecone',mode:e.mode,configured:e.configured,api_key_required:e.apiKeyRequired,source_of_truth:false}; if(!e.configured){result.status='skipped';result.reason=e.mode==='local'?'PINECONE_HOST is required for Pinecone Local, e.g. http://localhost:5082.':'Cloud mode requires PINECONE_API_KEY and PINECONE_HOST, or set PINECONE_MODE=local for Pinecone Local.'; if(!options.quiet)console.log(JSON.stringify(result,null,2)); return result} try{result.response=await pc.request('/query',{namespace:e.namespace,topK:1,sparseVector:{indices:[1],values:[0.1]},includeMetadata:false}); result.status='pass'}catch(err){result.status='fail';result.error=err.message;result.response=err.response||null} if(!options.quiet)console.log(JSON.stringify(result,null,2)); return result}
module.exports=main; if(require.main===module)main({quiet:process.argv.includes('--quiet')}).catch(e=>{console.error(e.stack||e.message);process.exit(1)});
