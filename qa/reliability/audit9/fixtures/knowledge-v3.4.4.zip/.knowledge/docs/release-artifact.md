# Release Artifact

> **Install note:** Do not use GitHub "Download ZIP" as the install package. Use the release asset only.

Use the official GitHub release asset named `knowledge-vX.Y.Z.zip`.
Maintainer packaging commands are source-checkout-only tools and are
intentionally not included in installed user `.knowledge` artifacts.

Expected artifact:

```bash
VERSION="$(node -p "require('./package.json').version")"
echo "dist/knowledge-v${VERSION}.zip"
```

Do not copy a source checkout into a repository as `.knowledge/`. The release artifact is the install artifact.
Do not leave a source checkout such as `knowledge-src/` beside `.knowledge/` in the target repository; agents may otherwise index the installer source as project code.

Artifact validation is source-only maintainer tooling. Installed user artifacts
do not include release validators, release gates, post-release asset tools, or
release policy files.

The artifact excludes source and runtime state, including:

- `.git/`
- `.github/`
- `node_modules/`
- `dist/`
- `maintenance/flow-logs/`
- runtime memory provider state
- `metrics/external_memory.json`
- generated `inspector/index.html`

The source checkout package and validator share a release policy. That policy
defines required public entries, forbidden paths/content, package-only
exclusions, and ZIP safety limits so packaging and validation do not drift
apart. Release gates remain source-only maintainer checks and are not shipped in
the user artifact.

Build the local Inspector after install/import:

```bash
node .knowledge/tools/build-visual-inspector.js
```

## Canonical ZIP subset

The validator accepts single-disk, non-ZIP64 stored or Deflate entries with
consistent local/central names, flags, CRC and sizes. Signed or unsigned 32-bit
data descriptors and an exactly declared archive comment remain supported.
The runtime inventory contains regular files; Unix directory/special-file modes
and DOS directory attributes are rejected even when the filename lacks a slash.
Local records must cover the payload region without overlap, hidden records or
unaccounted prefixes/gaps; the central directory must end at the EOCD record.

Local and central extra fields are rejected. In particular, Unicode Path or
Unix link metadata can change the path/type chosen by an external extractor.
The canonical product packager emits no extra fields, so existing canonical
candidates remain compatible. A third-party repack carrying timestamp or other
extra metadata must be rebuilt with the canonical packager before validation.
No alternate extraction path is treated as safe merely because the ordinary
filename passed a path check.

Archive reads are bounded to 64 MiB; the existing public policy limits entries
to 5,000, each uncompressed entry to 10 MiB and total uncompressed payload to
50 MiB. The total limit is enforced before decompression, and a deflated entry
cannot expand beyond its own declared size. These are validator admission
limits, not proof that installation or native runtime behavior is qualified.

Mem0 OSS is the recommended optional memory backend. Pinecone remains an optional vector/cloud bridge. Claude MEM first-class bridge was removed and legacy artifacts are advisory-only migration data. Graphiti and Zep are not bundled in the free/core install asset.
