# 3.4.4 RC5 reliability audit status

The current source revision is `independent-audit.20261028.reliability.8`.
The package version remains `3.4.4` and its candidate label remains `RC5`.
This is an unpublished development candidate: `release_qualified=false`.
The accompanying handoff identifies the exact source, installable ZIP, patch,
test inputs and observed results. Version-only update checks cannot distinguish
these RC5 derivatives; compare their audit revision and SHA-256.

## Verified input and changes

This revision starts from upstream commit
`9a1b1d5987902e486a54fccbb1e97365bb12844c` and the RELIABILITY7 input ZIP
`055b9d950038f00a9716a57b7c6b8e9f5103d760bb9f1449181669cbe2ccd0b7`.
The input handoff SHA-256 is
`a1db78c4f4d77fa654d39f83ab29af05fe98a028805e0a427321dec82fcc5996`.

The audit covers the relationships between import/routing, repair and evidence,
verification ownership, cancellation/recovery, diagnostics, installation,
updating, packaging and the QA harness. Its focused changes reuse existing
bounded file readers and persistence primitives, preserve the original recovery
deadline, distinguish work progress from cleanup, and prevent late macOS events
from renewing an expired phase. ZIP validation now admits payloads within its
size budget and rejects unsupported extraction metadata and contradictory
physical headers. QA rejects contradictory successful reports and attempts
bounded emergency cleanup after an observer exception.

The accompanying report separates product defects, QA defects, test setup
limitations, modeled controller tests and physical local filesystem/process
observations. A before/after regression proves only the property it exercises.
Neither those regressions nor ZIP integrity certify every supported platform.

## Platform evidence remains scoped

The ten packaged native binary/manifest pairs are reused byte-for-byte from
the verified input. Their C sources are unchanged. Their original build
provenance is retained; reuse does not turn historical execution into a new
physical run of this revision.

- **Windows x64 and ARM64:** the original complete RELIABILITY7 cohort was
  `NOT_ACCEPTED`. Later targeted Doctor/lock-layout fixes and an ARM64 Team
  normal-flow pass are separate observations. The original Team cancellation
  remained `TIMEOUT_CLEANUP_UNCONFIRMED`; a normal-flow pass does not prove
  forced-termination cleanup. This revision requires new platform results
  bound to its final installable ZIP.
- **Linux:** the namespace backend requires successful admission in the actual
  execution environment. An `EPERM` refusal on a restricted host is a safe
  refusal, not evidence that command execution or tree cleanup succeeded.
  Local Linux tests and helper-launch checks in this handoff have their stated
  scope. The separate administrator-installed production Linux service remains
  **NOT_IMPLEMENTED**; UID history and component tests do not supply its missing
  transport, admission, runtime and recovery integration.
- **macOS Intel/ARM64:** model-based tests exercise the JavaScript controller's
  event ordering and deadlines. They do not qualify the native broker or stock
  SIP. Verification is still opt-in per request with
  `native_execution.darwin.enabled=true`, `mode="isolated_copy"`, configured
  broker paths and copy limits. Broker installation and reserved UID provisioning
  remain separate administrator tasks. Writable Flow/Team work requires its own
  provisioned workspace; isolated-copy verification does not enable it.

## Recovery and operational limits

After a recovery budget expires, optional diagnostic persistence cannot acquire
a new lock budget. The existing claimed attempt and active recovery reservation
may therefore remain visible. This preserves the fence against new work; it is
not a terminal result or permission to remove a lock by age or PID. A subsequent
recovery still needs the exact identity and native custody proof.

Bounded file reads reject growth, non-regular files and namespace changes. They
do not make regular-device I/O interruptible. Synchronous storage in direct
CLI paths and direct `spawnSync` children in Restore Trust, Inspector actions
and updater post-checks are not universally covered by the same outer native
ownership boundary. Do not claim that every public command has a hard return
deadline or whole-tree cancellation proof. The handoff lists these concrete
remaining integration gaps and the tests needed to close them.

Update only after prior writers have stopped and released their locks normally.
The updater preserves project data and retains a verified backup for recovery;
its multi-file system update is not a single atomic directory switch. An
interrupted update requires review of its backup/report and reapplication or
verification of the exact candidate before normal operations resume. Preserve
the nonempty `locks/v1/.stale/` generation history during upgrade and cleanup.

## Remaining release conditions

1. Supply the current maintainer release tooling and run its full gate locally.
   The transferred source still declares missing maintainer paths, including
   `tools/release-gate.js`; this audit does not invent a replacement gate.
2. Run a fresh exact-ZIP platform matrix, including forced Windows Team
   cancellation and real stock-SIP Intel/ARM64 macOS hosts.
3. Implement and qualify the production Linux service if it is required for
   restricted hosts; do not relabel the available namespace backend or UID
   history component as that service.
4. Close the documented direct-CLI/Inspector/updater ownership gaps and perform
   the required storage-failure, restart, power-loss and live D-state work on
   suitable disposable hosts. Delayed-reaping or pipe-stall tests do not prove
   those different failure modes.

Earlier evidence is retained in the input handoff and source baseline. The
historical second ownerless-lock cause remains **UNKNOWN**. Successful replay of
a controlled mechanism does not identify that historical writer. The earlier
operational discussion is also preserved in
[the historical 2026-10-19 audit](historical/audit-3.4.4-rc5-operational-20261019.md).

`flow release` is a user workflow name, not a claim that the missing maintainer
release gate passed. Integrity checks establish artifact identity and internal
consistency; physical qualification is a separate result.
