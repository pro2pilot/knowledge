# EVID-P2-03 reproduction record

The independent RC39 audit found that the two verifier tools could not run
after a clean audit extraction because local dependency closure was absent.
RC40 closes that condition with `replay/manifest.json` and the 6/6
candidate-bound replay smoke in `tests/audit-tool-portability-report.json`.
