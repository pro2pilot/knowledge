# DOC-P2-01 reproduction record

RC39 inventory names diverged from the production lock-policy registry. RC40
generates inventory from that registry and validates 71 assertions, including
`agent-integrations`, `sync`, and project-root install-check coverage.
