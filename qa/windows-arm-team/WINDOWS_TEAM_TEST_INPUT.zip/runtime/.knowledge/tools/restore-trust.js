#!/usr/bin/env node
'use strict';

const path = require('path');
const owned = require('./lib/command-runner');
const { withMaintenanceOperation } = require('./lib/maintenance-operation');
const { installedAuthorityEntry } = require('./lib/command-authority-entry');
const { parseCliArgs, resolveKnowledgeContext, contextEnv } = require('./lib/path-context');
const { readJson, assertSafeContainedFile, writeFileAtomicContained, writeJsonAtomicContained } = require('./lib/json-store');
const { systemVersion } = require('./lib/system-version');
const { inspectSemanticJson } = require('./lib/semantic-json');

const SAFE_STEPS = [
  ['sync', ['tools/sync-tracked.js', '--scan']],
  ['wiki_graph', ['tools/build-wiki-graph.js']],
  ['wiki_lint', ['tools/lint-wiki.js']],
  ['external_memory', ['tools/external-memory-status.js', '--json']],
  ['routing', ['tools/build-routing-bundle.js']],
  ['search', ['tools/build-search-index.js']],
  ['inspector', ['tools/build-visual-inspector.js', '--json']],
  ['secret_scan', ['tools/scan-secrets.js', '--json']],
  ['doctor', ['tools/doctor.js', '--json']]
];

async function runStep(context, [name, command], control) {
  const started = Date.now();
  const script = path.join(context.systemRoot, command[0]);
  const request = { executable: process.execPath, args: [script, ...command.slice(1)],
    cwd: context.targetRoot, env: contextEnv(context) };
  request.nestedAuthority = installedAuthorityEntry(request) !== null;
  const result = await control.run(request, 240000);
  const processSuccess = result.status === 0 && !result.error && !result.signal;
  let semantic = { ok: true, errors: [] };
  if (command.includes('--json')) {
    try {
      semantic = inspectSemanticJson(JSON.parse(String(result.stdout || '').trim().replace(/^\uFEFF/, '')));
    } catch (error) {
      semantic = { ok: false, errors: [`invalid_step_json: ${error.message}`] };
    }
  }
  return {
    name,
    command: ['node', ...command].join(' '),
    status: processSuccess && semantic.ok ? 'passed' : 'failed',
    exit_code: result.status,
    process_success: processSuccess,
    semantic_pass: semantic.ok,
    semantic_errors: semantic.errors,
    spawn_error: result.error ? { code: result.error.code || null, message: result.error.message } : null,
    signal: result.signal || null,
    duration_ms: Date.now() - started,
    stdout_tail: String(result.stdout || '').slice(-1600),
    stderr_tail: String(result.stderr || '').slice(-1600)
  };
}

function renderPlainReport(context, steps) {
  const maintenance = path.join(context.stateRoot, 'maintenance');
  const trust = readJson(path.join(maintenance, 'trust_report.json'), {});
  const stale = readJson(path.join(maintenance, 'stale_items.json'), { items: [] });
  const repair = readJson(path.join(maintenance, 'repair_queue.json'), { queue: [] });
  const failed = steps.filter((step) => step.status !== 'passed');
  return `# Restore Trust Report

Status: ${failed.length ? 'failed' : 'passed'}

What I checked:
- Health, routing, search, wiki graph, freshness and generated Inspector artifacts.
- External memory policy remains advisory-only.
- Repair queue and stale item reports were refreshed from local files.

What changed:
- Generated .knowledge reports were rebuilt.
- No source code files were intentionally changed.
- No branches were merged.

Current state:
- Trust status: ${trust.status || 'unknown'}
- Stale items: ${(stale.items || stale.stale_items || []).length}
- Repair items: ${(repair.queue || repair.items || []).length}

Next step:
${failed.length ? '- Review failed command output in maintenance/restore-trust-report.json.' : '- Review the Inspector or run PR Impact before merging source changes.'}
`;
}

async function mainBody(argv, runtime, control) {
  const parsed = parseCliArgs(argv);
  if (![true, 'true', '1'].includes(parsed.flags.safe)) {
    throw new Error('Restore Trust requires --safe.');
  }
  const context = runtime.context || resolveKnowledgeContext(parsed.flags);
  const jsonReport = path.join(context.stateRoot, 'maintenance', 'restore-trust-report.json');
  const plainReport = path.join(context.stateRoot, 'maintenance', 'restore-trust-report.md');
  // Reject unsafe report locations before any rebuild, then recheck before
  // publication because a child can change the state tree.
  for (const file of [jsonReport, plainReport]) assertSafeContainedFile(context.stateRoot, file, { allowMissing: true });
  const steps = [];
  for (const step of SAFE_STEPS) steps.push(await runStep(context, step, control));
  await control.quiesce();
  const report = {
    schema_version: systemVersion(),
    generated_at: new Date().toISOString(),
    safe: true,
    status: steps.every((step) => step.status === 'passed') ? 'passed' : 'failed',
    source_code_changed: false,
    merged_branches: false,
    raised_trust_without_evidence: false,
    ownership: { status: 'pending_outer_cleanup' },
    steps
  };
  for (const file of [jsonReport, plainReport]) assertSafeContainedFile(context.stateRoot, file, { allowMissing: true });
  control.guard();
  writeJsonAtomicContained(jsonReport, report, context.stateRoot);
  const plain = renderPlainReport(context, steps);
  control.guard();
  writeFileAtomicContained(plainReport, plain, context.stateRoot);
  return report;
}
function policy(options, argv) {
  return { ...options, budgets: options.budgets || owned.cliBudgets(parseCliArgs(argv).flags) };
}
function printReport(report, argv) {
  if (parseCliArgs(argv).flags.json) console.log(JSON.stringify(report, null, 2));
  else console.log(`restore trust ${report.status}`);
  if (report.status !== 'passed') process.exitCode = 2;
  return report;
}
function main(argv = process.argv.slice(2), options = {}) {
  return printReport(owned.runOwnedOperationSync('restore-trust-main', { argv }, policy(options, argv)), argv);
}
async function mainAsync(argv = process.argv.slice(2), options = {}) {
  return (await owned.runOwnedOperation('restore-trust-main', { argv }, policy(options, argv))).value;
}
async function cli(runtime = {}) {
  const argv = process.argv.slice(2), controller = new AbortController();
  const cancel = () => controller.abort();
  process.on('SIGINT', cancel); process.on('SIGTERM', cancel);
  try { printReport(await mainAsync(argv, { ...runtime, signal: controller.signal }), argv); }
  catch (error) { console.error(error.code || error.message); process.exitCode = 1; }
  finally { process.removeListener('SIGINT', cancel); process.removeListener('SIGTERM', cancel); }
}
if (require.main === module) cli();
module.exports = { main, mainAsync, __owned: {
  main: (argv, runtime = {}) => withMaintenanceOperation(runtime, control => mainBody(argv, runtime, control)), cli
} };
