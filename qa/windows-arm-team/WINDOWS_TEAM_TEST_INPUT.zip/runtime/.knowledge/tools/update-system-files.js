#!/usr/bin/env node
'use strict';
const { runtimeFileMode } = require('./lib/runtime-file-mode');

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const owned = require('./lib/command-runner');
const { withMaintenanceOperation } = require('./lib/maintenance-operation');
const { installedAuthorityEntry } = require('./lib/command-authority-entry');
const {
  ensureDir,
  writeJsonAtomic,
  writeJsonAtomicContained,
  writeFileAtomicContained,
  assertSafeContainmentRoot,
  assertSafeContainedPath,
  ensureContainedDir,
  normalizeSystemAlias
} = require('./lib/json-store');
const { inspectSemanticJson, parseJsonOutput } = require('./lib/semantic-json');
const { readStableFile } = require('./lib/stable-file');
const { readStableJson } = require('./lib/stable-file');
const { acquireContainedLock } = require('./lib/contained-lock-manager');
const { LOCKS } = require('./lib/lock-policy');
const { UpdateGeneration, MAX_BYTES, MAX_ENTRIES } = require('./lib/update-generation');
const { captureTempDirIdentity, removeTempDirStrict } = require('./lib/strict-temp-cleanup');
const { systemVersion } = require('./lib/system-version');
const { inspectLegacyGate } = require('./migrate-legacy-release-gate');

const defaultKnowledgeRoot = path.resolve(__dirname, '..');
const defaultRepoRoot = path.basename(defaultKnowledgeRoot).toLowerCase() === '.knowledge' ? path.dirname(defaultKnowledgeRoot) : process.cwd();
let activeKnowledgeRoot = defaultKnowledgeRoot;
let activeRepoRoot = defaultRepoRoot;

const DEFAULT_MANIFEST = {
  schema_version: systemVersion(),
  system_paths: [
    '.gitattributes',
    '.gitignore',
    '.release-notes',
    'INSTALL.md',
    'README.md',
    'Quick-Start.md',
    'Portal.md',
    'RELEASE_NOTES.md',
    'SECURITY.md',
    'SBOM.memory.json',
    'THIRD_PARTY_NOTICES.md',
    'LICENSE',
    'NOTICE',
    'package.json',
    'install-policy.json',
    'verification-policy.json',
    'config.yaml',
    'inspector.js',
    'open-inspector.vbs',
    'assets',
    'agent-integrations',
    'commands',
    'docs',
    'flows',
    'external_memory',
    'maintenance/concurrency_policy.json',
    'maps/critical_paths.json',
    'github-action-templates',
    'memory-providers',
    'models',
    'schemas',
    'skills',
    'templates',
    'tools',
    'install-manifest.json'
  ],
  required_system_files: [
    'tools/recertify-core.js',
    'tools/lib/update-generation.js',
    'tools/lib/maintenance-operation.js',
    'tools/lib/watch-intervals.js',
    'tools/lib/command-authority-entry.js',
    'tools/lib/macos-command-runner.js',
    'tools/lib/macos-command-scope.js',
    'tools/lib/macos-command-worker.js',
    'tools/lib/macos-lock-preflight.js',
    'tools/lib/macos-worker-envelope.js',
    'tools/lib/macos-workspace-protocol.js',
    'tools/lib/macos-workspace-session.js',
    'tools/lib/watch-maintenance-worker.js',
    'verification-policy.json',
    'tools/repair-on-touch.js',
    'tools/lib/repair-on-touch.js',
    'tools/lib/dedicated-verification.js',
    'tools/self-test-repair-on-touch.js',
    'tools/self-test-dedicated-verification.js',
    'tools/self-test-repair-session-isolation.js',
    'tools/doctor.js',
    'tools/recertify.js',
    'tools/build-visual-inspector.js',
    'tools/serve-inspector.js',
    'tools/install-agent-integrations.js',
    'tools/lib/queue-lifecycle.js',
    'tools/lib/json-transaction.js',
    'tools/lib/inert-data.js',
    'tools/lib/contained-artifact.js',
    'tools/lib/workspace-baseline.js',
    'tools/lib/task-routing.js',
    'schemas/repair-opportunities.schema.json',
    'schemas/verification-execution.schema.json',
    'schemas/verification-execution-observation.schema.json',
    'schemas/verification-receipt.schema.json',
    'schemas/dedicated-verification-receipt.schema.json',
    'docs/repair-on-touch.md',
    'agent-integrations/_shared/trust-routing.md',
    'agent-integrations/_shared/final-report-contract.md',
    'agent-integrations/_shared/metrics-reporting.md'
  ],
  approved_local_rebuild_tools: [
    'tools/build-routing-bundle.js',
    'tools/build-search-index.js',
    'tools/build-wiki-graph.js'
  ],
  immutable_runtime_evidence_paths: [
    'maintenance/knowledge_currency/receipts',
    'maintenance/verification_receipts',
    'maintenance/verification_executions',
    'maintenance/verification_finalizations',
    'maintenance/dedicated_verification_receipts'
  ],
  runtime_preserve_paths: [
    'maintenance/knowledge_currency',
    'maintenance/recording_blockers.json',
    'maintenance/repair_opportunities.json',
    'maintenance/repair_on_touch_telemetry.json',
    'maintenance/repair_sessions',
    'maintenance/transactions',
    'maintenance/recertifications.json',
    'settings/operator-profile.json'
  ],
  project_preserve_paths: [
    'project_index.json',
    'freshness.json',
    'decisions.json',
    'contradictions.json',
    'glossary.json',
    'evidence',
    'external_memory',
    'invariants',
    'maintenance',
    'maps',
    'metrics',
    'modules',
    'search',
    'sessions',
    'reports',
    'settings',
    'wiki',
    'inspector'
  ],
  curated_preserve_paths: [
    'external_memory',
    'wiki',
    'modules',
    'evidence',
    'decisions.json',
    'glossary.json',
    'contradictions.json',
    'project_index.json'
  ],
  curated_runtime_mutable_paths: [
    'modules/module_registry.json',
    'evidence/file_facts.json'
  ],
  runtime_regenerate_paths: [
    'freshness.json',
    'external_memory',
    'maintenance',
    'maps',
    'metrics',
    'search',
    'inspector'
  ],
  repair_default_paths: [
    'external_memory/registry.json',
    'external_memory/retrieval_policy.json'
  ],
  system_remove_paths: [
    '.release-notes/v3.2.12.md',
    '.release-notes/v3.3.1.md'
  ],
  // 3.2.11's updater accepts removals only when they also name a source
  // system path. Source-only benchmark material cannot be shipped merely to
  // satisfy that legacy restriction, so modern updaters complete this one
  // migration after a verified 3.2.11 hand-off instead.
  legacy_compatible_remove_paths: [
    'benchmarks',
    'tools/run-benchmarks.js',
    'agent-integrations/codex/skills/release-preparation-workflow.md',
    'agent-integrations/devin/rules/knowledge.md'
  ],
  system_exclude_paths: [
    'benchmarks',
    'benchmarks/results',
    'benchmark-runs',
    'marketing-proof-packs',
    'tools/run-benchmarks.js',
    'agent-integrations/codex/skills/release-preparation-workflow.md',
    'dist',
    '.git',
    '.github',
    '.self-test-tmp',
    '.qa-tmp',
    'node_modules',
    'maintenance/install-backups',
    'maintenance/update-generations',
    'maintenance/update-downloads',
    'maintenance/flow-logs',
    'maintenance/events',
    'maintenance/knowledge_currency',
    'maintenance/recording_blockers.json',
    'maintenance/repair_opportunities.json',
    'maintenance/repair_on_touch_telemetry.json',
    'maintenance/verification_receipts',
    'maintenance/verification_executions',
    'maintenance/verification_finalizations',
    'maintenance/dedicated_verification_receipts',
    'maintenance/repair_sessions',
    'maintenance/transactions',
    'maintenance/dev-notes',
    'maintenance/github-release-update-log-*.md',
    'exports',
    'modules',
    'pro',
    'docs/canonical',
    'docs/product',
    'docs/strategy',
    'docs/release-gates.md',
    'docs/pro-subscription.md',
    'docs/pro-inspector.md',
    'memory-providers/graphiti',
    'memory-providers/zep',
    'tools/validate-paid-manifest.js',
    'tools/lib/paid-inspector-model.js',
    'tools/release-gate.js',
    'tools/check-public-consistency.js',
    'tools/package-release.js',
    'tools/validate-release-artifact.js',
    'tools/post-release-live-asset.js',
    'tools/conformance-install-smoke.js',
    'tools/classify-release-impact.js',
    'tools/generate-conformance-report.js',
    'tools/validate-sbom.js',
    'tools/validate-third-party-notices.js',
    'tools/validate-source-deliverable.js',
    'tools/self-test-release-gate-p0.js',
    'release-policy.json',
    'tools/verify-routing-rc4-r6-contract.js',
    'tools/verify-workspace-narrowing-rc4-r7.js',
    'tools/self-test-routing-rc4-r4.js',
    'tools/self-test-routing-rc4-r5.js',
    'tools/self-test-workspace-narrowing-rc4-r7.js',
    'tools/lib/release-policy.js',
    'tools/lib/release-step-evidence.js',
    'evaluation/results',
    'search',
    '.lock',
    '.runtime'
  ],
  forbidden_paths: [
    '.git',
    '.github',
    'node_modules',
    'dist',
    '.env',
    '.env.local'
  ]
};

const SYSTEM_PATHS = DEFAULT_MANIFEST.system_paths;
const PROJECT_PATHS = DEFAULT_MANIFEST.project_preserve_paths;
const LEGACY_OLD_UPDATER_COMPATIBLE_REMOVALS = new Set([
  'benchmarks',
  'tools/run-benchmarks.js',
  'agent-integrations/codex/skills/release-preparation-workflow.md',
  'agent-integrations/devin/rules/knowledge.md'
]);

function validateManifestPath(value, field = 'path') {
  if (typeof value !== 'string') throw new Error(`Invalid install manifest ${field}: expected a string path.`);
  const rel = value.replace(/\\/g, '/').replace(/^\.\//, '').replace(/\/+$/, '').normalize('NFC');
  const parts = rel.split('/');
  if (!rel || /^[a-z]:/i.test(rel) || rel.startsWith('/') || /[\x00-\x1f\x7f:]/.test(rel) ||
      parts.some((part) => !part || part === '.' || part === '..' || /[. ]$/.test(part))) {
    throw new Error(`Unsafe install manifest ${field}: ${JSON.stringify(value)}`);
  }
  return rel;
}

function assertUpdatePath(root, absolute, allowMissing = false) {
  assertSafeContainedPath(root, absolute, { allowMissing });
  let stat;
  try { stat = fs.lstatSync(absolute); } catch (error) {
    if (allowMissing && error.code === 'ENOENT') return null;
    throw error;
  }
  if ((!stat.isFile() && !stat.isDirectory()) || stat.isSymbolicLink() || (stat.isFile() && stat.nlink !== 1)) {
    throw new Error(`Unsafe update path (physical, singly linked file or directory required): ${absolute}`);
  }
  return stat;
}

function readPhysicalFile(filePath) {
  assertUpdatePath(path.dirname(filePath), filePath);
  // System artifacts have a finite admitted size. The bounded reader also
  // binds ctime and parent identities, so restoring mtime after a same-size
  // rewrite cannot turn stale source bytes into an authorized update plan.
  return readStableFile(path.dirname(filePath), filePath, { maxBytes: 64 * 1024 * 1024 });
}

function readJson(filePath, fallback) {
  try { fs.lstatSync(filePath); }
  catch (error) { if (error.code === 'ENOENT' && fallback !== undefined) return fallback; throw error; }
  try { return readStableJson(path.dirname(filePath), filePath, { maxBytes: 64 * 1024 * 1024 }); }
  catch (error) { if (error.code === 'ENOENT' && fallback !== undefined) return fallback; throw error; }
}

function assertUpdateTree(root, directory, skip = () => false) {
  const stat = assertUpdatePath(root, directory);
  if (!stat.isDirectory()) return;
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const absolute = path.join(directory, entry.name);
    if (skip(normalizeRel(path.relative(root, absolute)))) continue;
    assertUpdateTree(root, absolute, skip);
  }
}

function isPreservedDefault(relPath) {
  return relPath === 'external_memory' || relPath.startsWith('external_memory/');
}

function configWithoutVersion(bytes) {
  return String(bytes).replace(/^\uFEFF/, '').replace(/^version:[^\r\n]*(?:\r?\n|$)/m, '');
}

function mergedConfigBytes(source, existing) {
  const version = String(source).match(/^version:\s*[^\r\n]+/m)?.[0];
  if (!version) throw new Error('Source config.yaml has no version.');
  const text = String(existing).replace(/^\uFEFF/, '');
  if ((text.match(/^version:/gm) || []).length > 1) throw new Error('Target config.yaml contains duplicate version fields.');
  return Buffer.from(/^version:/m.test(text) ? text.replace(/^version:[^\r\n]*/m, version) : `${version}\n${text}`, 'utf8');
}

function normalizeRel(value) {
  return String(value || '').replace(/\\/g, '/').replace(/^\.\//, '').replace(/\/+$/g, '');
}

function uniqueNormalized(values) {
  return Array.from(new Set((values || []).map(normalizeRel).filter(Boolean)));
}

function parseArgs(argv) {
  const args = {
    from: null,
    targetKnowledgeRoot: null,
    dryRun: false,
    apply: false,
    yes: false,
    json: false,
    verifyUpgrade: false,
    preflight: false,
    pruneVerifiedBackups: false,
    recoverUpdate: false,
    repairDefaults: true,
    postUpgradeTrustRefresh: 'repair_queue'
  };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--from') args.from = argv[++i];
    else if (arg.startsWith('--from=')) args.from = arg.slice('--from='.length);
    else if (arg === '--target-knowledge-root' || arg === '--target') args.targetKnowledgeRoot = argv[++i];
    else if (arg.startsWith('--target-knowledge-root=')) args.targetKnowledgeRoot = arg.slice('--target-knowledge-root='.length);
    else if (arg.startsWith('--target=')) args.targetKnowledgeRoot = arg.slice('--target='.length);
    else if (arg === '--dry-run') args.dryRun = true;
    else if (arg === '--apply') args.apply = true;
    else if (arg === '--yes') args.yes = true;
    else if (arg === '--json') args.json = true;
    else if (arg === '--verify-upgrade') args.verifyUpgrade = true;
    else if (arg === '--preflight') args.preflight = true;
    else if (arg === '--prune-verified-backups') args.pruneVerifiedBackups = true;
    else if (arg === '--recover-update') args.recoverUpdate = true;
    else if (arg === '--no-repair-defaults') args.repairDefaults = false;
    else if (arg === '--repair-defaults') args.repairDefaults = true;
    else if (arg.startsWith('--repair-defaults=')) args.repairDefaults = !['false', '0', 'no', 'off'].includes(arg.slice('--repair-defaults='.length).toLowerCase());
    else if (arg === '--post-upgrade-trust-refresh') args.postUpgradeTrustRefresh = argv[++i];
    else if (arg.startsWith('--post-upgrade-trust-refresh=')) args.postUpgradeTrustRefresh = arg.slice('--post-upgrade-trust-refresh='.length);
    else throw new Error(`Unknown update argument: ${arg}`);
  }
  for (const [name, value] of [['--from', args.from], ['--target', args.targetKnowledgeRoot], ['--post-upgrade-trust-refresh', args.postUpgradeTrustRefresh]]) {
    if (value === undefined || (typeof value === 'string' && (!value || value.startsWith('--')))) throw new Error(`Missing value for ${name}.`);
  }
  if ([args.dryRun, args.apply, args.preflight, args.verifyUpgrade, args.pruneVerifiedBackups, args.recoverUpdate].filter(Boolean).length > 1) throw new Error('Choose only one update phase.');
  if (!args.verifyUpgrade && !args.preflight && !args.pruneVerifiedBackups && !args.recoverUpdate && !args.dryRun && !args.apply) args.dryRun = true;
  return args;
}

function configureTarget(targetArg) {
  if (!targetArg) return;
  const resolved = path.resolve(process.cwd(), targetArg);
  if (path.basename(resolved).toLowerCase() === '.knowledge') {
    activeKnowledgeRoot = resolved;
    activeRepoRoot = path.dirname(resolved);
    return;
  }
  const nested = path.join(resolved, '.knowledge');
  if (fs.existsSync(nested) || !fs.existsSync(resolved)) {
    activeKnowledgeRoot = nested;
    activeRepoRoot = resolved;
    return;
  }
  activeKnowledgeRoot = resolved;
  activeRepoRoot = path.dirname(resolved);
}

function sha256(filePath) {
  return crypto.createHash('sha256').update(readPhysicalFile(filePath)).digest('hex');
}

function isDirectory(filePath) {
  try { return fs.statSync(filePath).isDirectory(); } catch { return false; }
}

function isFile(filePath) {
  try { return fs.statSync(filePath).isFile(); } catch { return false; }
}

function isRegularFile(filePath) {
  try {
    const stat = fs.lstatSync(filePath);
    return stat.isFile() && !stat.isSymbolicLink();
  } catch {
    return false;
  }
}

function walkFiles(root) {
  const out = [];
  if (!fs.existsSync(root)) return out;
  assertUpdatePath(path.dirname(root), root);
  function walk(dir) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const abs = path.join(dir, entry.name);
      const rel = normalizeRel(path.relative(root, abs));
      const parts = rel.split('/');
      if (parts.includes('.git') || parts.includes('node_modules')) continue;
      if (rel.includes('.tmp-') || rel.includes('.bak-')) continue;
      assertUpdatePath(root, abs);
      if (entry.isDirectory()) walk(abs);
      else if (entry.isFile()) out.push({ abs, rel });
    }
  }
  walk(root);
  out.sort((a, b) => a.rel.localeCompare(b.rel));
  return out;
}

function loadInstallManifest(root = activeKnowledgeRoot) {
  const manifestPath = path.join(root, 'install-manifest.json');
  assertSafeContainmentRoot(root);
  assertUpdatePath(root, manifestPath, true);
  const raw = fs.existsSync(manifestPath) ? JSON.parse(readPhysicalFile(manifestPath).toString('utf8').replace(/^\uFEFF/, '')) : {};
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('Invalid install manifest: expected a JSON object.');
  const validatePaths = (values, field, allowPatterns = false) => {
    if (!Array.isArray(values)) throw new Error(`Invalid install manifest ${field}: expected an array.`);
    const seen = new Map();
    return values.map(value => {
      const rel = validateManifestPath(value, field);
      if (!allowPatterns && /[?*<>"|]/.test(rel)) throw new Error(`Unsafe install manifest ${field}: ${JSON.stringify(value)}`);
      const identity = rel.toLowerCase();
      if (seen.has(identity) && seen.get(identity) !== rel) throw new Error(`Install manifest path case collision: ${rel}`);
      seen.set(identity, rel);
      return rel;
    });
  };
  for (const [field, values] of Object.entries(raw)) {
    if (!Array.isArray(DEFAULT_MANIFEST[field]) && field !== 'project_default_paths') continue;
    validatePaths(values, field, field === 'system_exclude_paths');
  }
  const contract = raw.release_contract === undefined ? {} : raw.release_contract;
  if (!contract || typeof contract !== 'object' || Array.isArray(contract)) throw new Error('Invalid install manifest release_contract: expected an object.');
  const contractPaths = field => contract[field] === undefined ? []
    : validatePaths(contract[field], `release_contract.${field}`);
  // The canonical packager excludes these declared source-only paths. Apply
  // the same restrictions without importing its source-only release helper
  // into installed runtime or treating exclusions as deletion authority.
  const releaseExclusions = ['source_only_test_paths', 'source_only_document_paths', 'maintainer_tool_paths']
    .flatMap(contractPaths);
  const requiredPublic = contractPaths('required_public_paths');
  const merged = (field, aliases = []) => uniqueNormalized([
    ...(DEFAULT_MANIFEST[field] || []),
    ...[field, ...aliases].flatMap((name) =>
      Array.isArray(raw[name]) ? raw[name] : [])
  ]);
  const requiredSystem = uniqueNormalized([...merged('required_system_files'), ...requiredPublic]);
  const exclusions = uniqueNormalized([...merged('system_exclude_paths'), ...releaseExclusions]);
  for (const required of requiredSystem) {
    const identity = required.toLowerCase();
    if (exclusions.some(excluded => identity === excluded.toLowerCase() || identity.startsWith(`${excluded.toLowerCase()}/`))) {
      throw new Error(`Required system artifact cannot be excluded by install manifest: ${required}`);
    }
  }
  return {
    schema_version: raw.schema_version || DEFAULT_MANIFEST.schema_version,
    system_paths: merged('system_paths'),
    required_system_files: requiredSystem,
    approved_local_rebuild_tools:
      merged('approved_local_rebuild_tools'),
    immutable_runtime_evidence_paths:
      merged('immutable_runtime_evidence_paths'),
    runtime_preserve_paths: merged('runtime_preserve_paths'),
    project_preserve_paths: merged('project_preserve_paths'),
    curated_preserve_paths: merged('curated_preserve_paths'),
    curated_runtime_mutable_paths:
      merged('curated_runtime_mutable_paths'),
    runtime_regenerate_paths: merged('runtime_regenerate_paths'),
    repair_default_paths:
      merged('repair_default_paths', ['project_default_paths']),
    system_remove_paths: merged('system_remove_paths'),
    legacy_compatible_remove_paths: merged('legacy_compatible_remove_paths')
      .filter((relPath) => LEGACY_OLD_UPDATER_COMPATIBLE_REMOVALS.has(relPath)),
    system_exclude_paths: exclusions,
    forbidden_paths: merged('forbidden_paths'),
    manifest_path: fs.existsSync(manifestPath) ? manifestPath : null,
    used_default: !fs.existsSync(manifestPath)
  };
}

function obsoleteSystemPaths(manifest) {
  return uniqueNormalized([
    ...(manifest.system_remove_paths || []),
    ...(manifest.legacy_compatible_remove_paths || [])
  ]);
}

function sourcePathFor(sourceRoot, relPath) {
  const rel = validateManifestPath(relPath);
  if (rel === '.gitignore') {
    const installedTemplate = path.join(sourceRoot, 'templates', 'git-policy', '.knowledge.gitignore');
    assertUpdatePath(sourceRoot, installedTemplate, true);
    if (fs.existsSync(installedTemplate)) return installedTemplate;
  }
  const absolute = path.join(sourceRoot, rel);
  assertUpdatePath(sourceRoot, absolute, true);
  return absolute;
}

function isExcludedByManifest(relPath, manifest) {
  const rel = normalizeRel(relPath);
  return (manifest.system_exclude_paths || []).some((excluded) => rel === excluded || rel.startsWith(`${excluded}/`));
}

function resolveSourceRoot(fromArg) {
  if (!fromArg) throw new Error('Missing --from <new-knowledge-root>.');
  const candidate = path.resolve(process.cwd(), fromArg);
  const direct = path.join(candidate, 'tools', 'flow.js');
  const nested = path.join(candidate, '.knowledge', 'tools', 'flow.js');
  if (fs.existsSync(direct)) { assertUpdatePath(candidate, direct); return candidate; }
  if (fs.existsSync(nested)) { assertUpdatePath(path.join(candidate, '.knowledge'), nested); return path.join(candidate, '.knowledge'); }
  throw new Error(`Cannot find a .knowledge root at ${candidate}. Expected tools/flow.js or .knowledge/tools/flow.js.`);
}

function sourceMissingSystemPaths(sourceRoot, manifest) {
  const missing = manifest.system_paths
    .filter((relPath) =>
      !isExcludedByManifest(relPath, manifest) && !fs.existsSync(sourcePathFor(sourceRoot, relPath)));
  for (const relPath of manifest.required_system_files || []) {
    if (!isRegularFile(sourcePathFor(sourceRoot, relPath))) {
      missing.push(relPath);
    }
  }
  return Array.from(new Set(missing)).sort();
}

function planActions(sourceRoot, options = {}) {
  const targetRoot = options.targetKnowledgeRoot || activeKnowledgeRoot;
  const manifest = options.manifest || loadInstallManifest(sourceRoot);
  assertSafeContainmentRoot(sourceRoot);
  assertSafeContainmentRoot(targetRoot);
  const actions = [];
  const seenFiles = new Set();
  function planFile(src, dst, relFile) {
    if (seenFiles.has(relFile)) return;
    seenFiles.add(relFile);
    assertSystemWriteAllowed(relFile, manifest);
    const targetStat = assertUpdatePath(targetRoot, dst, true);
    if (targetStat && !targetStat.isFile()) throw new Error(`Update target must be a file: ${relFile}`);
    if (isPreservedDefault(relFile) && (targetStat || (manifest.repair_default_paths || []).includes(relFile))) {
      actions.push({ action: 'preserve', path: relFile, reason: targetStat ? 'existing_project_default' : 'repair_default_only' });
      return;
    }
    const sourceBytes = readPhysicalFile(src);
    const existing = targetStat ? readPhysicalFile(dst) : null;
    const sourceHash = crypto.createHash('sha256').update(sourceBytes).digest('hex');
    const targetHash = existing ? crypto.createHash('sha256').update(existing).digest('hex') : null;
    const desired = relFile === 'config.yaml' && existing ? mergedConfigBytes(sourceBytes, existing) : sourceBytes;
    const nativeModeNeedsRepair = process.platform !== 'win32' && runtimeFileMode(relFile) === 0o755 &&
      targetStat && (targetStat.mode & 0o777) !== 0o755;
    actions.push(existing && desired.equals(existing) && !nativeModeNeedsRepair
      ? { action: 'skip', path: relFile, reason: 'unchanged' }
      : { action: existing ? 'update' : 'create', path: relFile, kind: 'file', source_sha256: sourceHash,
          target_sha256: targetHash, ...(relFile === 'config.yaml' && existing ? { reason: 'preserve_operator_config_update_version' } : {}) });
  }
  for (const relPath of manifest.system_paths) {
    if (isExcludedByManifest(relPath, manifest)) continue;
    assertSystemWriteAllowed(relPath, manifest);
    const src = sourcePathFor(sourceRoot, relPath);
    const dst = path.join(targetRoot, relPath);
    const targetStat = assertUpdatePath(targetRoot, dst, true);
    if (!fs.existsSync(src)) {
      actions.push({ action: 'skip', path: relPath, reason: 'source_missing' });
      continue;
    }
    if (isDirectory(src)) {
      if (targetStat && !targetStat.isDirectory()) throw new Error(`Update target must be a directory: ${relPath}`);
      const files = walkFiles(src)
        .filter((file) => !isExcludedByManifest(path.posix.join(relPath, file.rel), manifest));
      if (!fs.existsSync(dst)) actions.push({ action: 'create', path: relPath, kind: 'directory' });
      for (const file of files) {
        const dstFile = path.join(dst, file.rel);
        const relFile = normalizeRel(path.posix.join(relPath, file.rel));
        planFile(file.abs, dstFile, relFile);
      }
      continue;
    }
    if (isFile(src)) {
      planFile(src, dst, relPath);
    }
  }

  for (const relPath of obsoleteSystemPaths(manifest)) {
    assertSystemWriteAllowed(relPath, manifest, 'remove');
    if (fs.existsSync(sourcePathFor(sourceRoot, relPath)) && !isExcludedByManifest(relPath, manifest)) {
      throw new Error(`Refusing to remove a shipped system artifact: ${relPath}`);
    }
    assertUpdatePath(targetRoot, path.join(targetRoot, relPath), true);
    if (fs.existsSync(path.join(targetRoot, relPath))) {
      actions.push({ action: 'remove', path: relPath, reason: 'obsolete_system_path' });
    }
  }

  for (const relPath of manifest.project_preserve_paths) {
    validateManifestPath(relPath);
    assertUpdatePath(targetRoot, path.join(targetRoot, relPath), true);
    if (fs.existsSync(path.join(targetRoot, relPath))) actions.push({ action: 'preserve', path: relPath, reason: 'project_specific' });
  }
  return actions;
}

function planRepairDefaults(sourceRoot, manifest, options = {}) {
  if (options.repairDefaults === false) return [];
  const targetRoot = options.targetKnowledgeRoot || activeKnowledgeRoot;
  const actions = [];
  for (const relPath of manifest.repair_default_paths || []) {
    assertRepairDefaultWriteAllowed(relPath, manifest);
    const src = sourcePathFor(sourceRoot, relPath);
    const dst = path.join(targetRoot, relPath);
    assertUpdatePath(targetRoot, dst, true);
    if (!fs.existsSync(src)) {
      actions.push({ action: 'skip', path: relPath, reason: 'source_missing', kind: 'repair_default' });
      continue;
    }
    if (fs.existsSync(dst)) {
      actions.push({ action: 'skip', path: relPath, reason: 'target_exists', kind: 'repair_default' });
      continue;
    }
    actions.push({ action: 'repair_default', path: relPath, reason: 'missing_project_default', kind: 'file', source_sha256: sha256(src) });
  }
  return actions;
}

function copyFile(src, dst) {
  assertUpdatePath(activeKnowledgeRoot, dst, true);
  writeFileAtomicContained(dst, readPhysicalFile(src), activeKnowledgeRoot, { mode: fs.lstatSync(src).mode & 0o777 });
}

function timestamp() {
  return new Date().toISOString().replace(/[:.]/g, '-');
}

function copyKnowledgeBackup() {
  const backupRoot = path.join(activeKnowledgeRoot, 'maintenance', 'install-backups', `system-files-${timestamp()}-${crypto.randomBytes(8).toString('hex')}`);
  function copyDir(src, dst) {
    ensureContainedDir(activeKnowledgeRoot, dst);
    for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
      const from = path.join(src, entry.name);
      const rel = normalizeRel(path.relative(activeKnowledgeRoot, from));
      if (['.lock', '.runtime', 'locks', 'maintenance/update-generations'].some(skip => rel === skip || rel.startsWith(`${skip}/`))) continue;
      if (rel.startsWith('maintenance/install-backups/')) continue;
      const to = path.join(dst, entry.name);
      assertUpdatePath(activeKnowledgeRoot, from);
      if (entry.isDirectory()) copyDir(from, to);
      else if (entry.isFile()) copyFile(from, to);
    }
  }
  copyDir(activeKnowledgeRoot, backupRoot);
  return backupRoot;
}

function finalizeBackupVerification(backupRoot, state) {
  if (!backupRoot) return null;
  const curatedPreserved = state.curatedProof?.status === 'preserved';
  const runtimePreserved = state.runtimeProof?.status === 'preserved';
  const systemParity = state.systemCompleteness?.status === 'ok' &&
    Number(state.systemCompleteness?.checked_system_files || 0) > 0;
  const postChecksPassed = state.postChecks.length > 0 && state.postChecks.every((check) => check.success === true);
  const safeToRemove = state.errors.length === 0 && curatedPreserved && runtimePreserved && systemParity && postChecksPassed;
  const receipt = {
    schema_version: 'knowledge-update-backup-verification.v1',
    generated_at: new Date().toISOString(),
    status: safeToRemove ? 'verified' : 'retained_for_rollback',
    safe_to_remove: safeToRemove,
    checks: {
      curated_preservation: curatedPreserved ? 'pass' : 'fail',
      runtime_evidence_preservation: runtimePreserved ? 'pass' : 'fail',
      system_sha256_parity: systemParity ? 'pass' : 'fail',
      semantic_post_checks: postChecksPassed ? 'pass' : 'fail'
    },
    checked_system_files: Number(state.systemCompleteness?.checked_system_files || 0),
    mismatched_system_paths: state.systemCompleteness?.mismatched_system_paths || [],
    curated_changed_files: state.curatedProof?.changed_files || [],
    curated_added_files: state.curatedProof?.added_files || [],
    curated_runtime_mutable_changed_files: state.curatedProof?.runtime_mutable_changed_files || [],
    runtime_changed_files: state.runtimeProof?.changed_files || [],
    runtime_removed_files: state.runtimeProof?.removed_files || [],
    runtime_added_files: state.runtimeProof?.added_files || [],
    semantic_post_check_failures: state.postChecks
      .filter((check) => !check.success)
      .map((check) => ({ label: check.label, semantic_errors: check.semantic_errors || [] })),
    update_errors: [...state.errors],
    cleanup_command: 'node .knowledge/tools/update-system-files.js --prune-verified-backups --yes --json'
  };
  try {
    writeJsonAtomicContained(path.join(backupRoot, 'backup-verification.json'), receipt, activeKnowledgeRoot);
    receipt.receipt_path = path.join(backupRoot, 'backup-verification.json');
    return receipt;
  } catch (error) {
    return {
      ...receipt,
      status: 'verification_receipt_write_failed',
      safe_to_remove: false,
      error: error.message
    };
  }
}

function pruneVerifiedBackups(confirmed) {
  // This early CLI phase does not pass through ordinary update preflight.
  // Authenticate its namespace independently before listing or removing it.
  assertSafeContainmentRoot(activeKnowledgeRoot);
  const backupParent = path.join(activeKnowledgeRoot, 'maintenance', 'install-backups');
  const parentStat = assertUpdatePath(activeKnowledgeRoot, backupParent, true);
  if (parentStat && !parentStat.isDirectory()) throw new Error('Backup store must be a physical directory.');
  const rootIdentity = captureTempDirIdentity(activeKnowledgeRoot);
  const parentIdentity = parentStat ? captureTempDirIdentity(backupParent) : null;
  const assertNamespace = () => {
    assertUpdatePath(activeKnowledgeRoot, backupParent);
    for (const expected of [rootIdentity, parentIdentity]) {
      const current = captureTempDirIdentity(expected.directory);
      if (current.dev !== expected.dev || current.ino !== expected.ino) {
        throw Object.assign(new Error('Backup prune namespace changed physical identity.'), { code: 'update_backup_namespace_changed' });
      }
    }
  };
  const candidates = parentStat
    ? fs.readdirSync(backupParent, { withFileTypes: true })
      .filter((entry) => entry.isDirectory() && /^system-files-/.test(entry.name))
      .map((entry) => path.join(backupParent, entry.name))
      .sort()
    : [];
  if (!confirmed) {
    return {
      schema_version: 'knowledge-update-backup-prune.v1',
      status: 'failed',
      phase: 'prune_verified_backups',
      removed: [],
      retained: candidates.map((candidate) => ({ path: candidate, reason: 'confirmation_required' })),
      errors: ['Refusing to prune backups without --yes.']
    };
  }
  const removed = [];
  const retained = [];
  const errors = [];
  for (const candidate of candidates) {
    const receiptPath = path.join(candidate, 'backup-verification.json');
    let receipt, identity;
    try {
      assertNamespace();
      const stat = assertUpdatePath(activeKnowledgeRoot, candidate);
      if (!stat.isDirectory()) throw new Error('Backup candidate is not a physical directory.');
      identity = captureTempDirIdentity(candidate);
      receipt = JSON.parse(readStableFile(activeKnowledgeRoot, receiptPath, { maxBytes: 1024 * 1024 }).toString('utf8'));
    } catch (error) {
      retained.push({ path: candidate, reason: error.code === 'ENOENT' ? 'verification_receipt_missing' : 'verification_receipt_unreadable', code: error.code || 'ERROR' });
      continue;
    }
    if (!receipt || receipt.schema_version !== 'knowledge-update-backup-verification.v1' ||
        receipt.status !== 'verified' ||
        receipt.safe_to_remove !== true) {
      retained.push({ path: candidate, reason: receipt?.status || 'verification_receipt_missing' });
      continue;
    }
    const requiredChecks = [
      'curated_preservation',
      'runtime_evidence_preservation',
      'system_sha256_parity',
      'semantic_post_checks'
    ];
    if (!requiredChecks.every((name) => receipt.checks?.[name] === 'pass')) {
      retained.push({ path: candidate, reason: 'legacy_runtime_proof_required' });
      continue;
    }
    try {
      // Recheck namespace and the captured candidate before every retry, then
      // verify removal. These checks do not claim atomic hostile-UID exclusion.
      removeTempDirStrict(candidate, {
        expectedIdentity: identity,
        remove(target) {
          assertNamespace();
          assertUpdatePath(activeKnowledgeRoot, target);
          fs.rmSync(target, { recursive: true, force: true, maxRetries: 0 });
        }
      });
      assertNamespace();
      removed.push(candidate);
    } catch (error) {
      retained.push({ path: candidate, reason: 'cleanup_unconfirmed', code: error.code || 'ERROR' });
      errors.push(`Backup removal was not confirmed for ${candidate}: ${error.code || 'ERROR'}`);
    }
  }
  return {
    schema_version: 'knowledge-update-backup-prune.v1',
    status: errors.length ? 'failed' : 'ok',
    phase: 'prune_verified_backups',
    removed,
    retained,
    removed_count: removed.length,
    retained_count: retained.length,
    errors
  };
}

function contextEnv(extra = {}) {
  return {
    ...process.env,
    ...extra,
    KNOWLEDGE_SYSTEM_ROOT: activeKnowledgeRoot,
    KNOWLEDGE_TARGET_ROOT: activeRepoRoot,
    KNOWLEDGE_PROJECT_KNOWLEDGE_ROOT: activeKnowledgeRoot,
    KNOWLEDGE_STATE_ROOT: activeKnowledgeRoot,
    KNOWLEDGE_FLOW_NO_OPEN: '1',
    KNOWLEDGE_INSPECTOR_NO_OPEN: '1'
  };
}

async function runNode(script, args, label, control) {
  const command = { executable: process.execPath, args: [path.join(activeKnowledgeRoot, 'tools', script), ...args],
    cwd: activeRepoRoot, env: contextEnv() };
  command.nestedAuthority = installedAuthorityEntry(command) !== null;
  const res = await control.run(command);
  const rawStdout = String(res.stdout || '');
  let parsed = null;
  const semanticErrors = [];
  try {
    parsed = parseJsonOutput(rawStdout);
    semanticErrors.push(...inspectSemanticJson(parsed).errors);
  } catch (error) {
    semanticErrors.push(`invalid JSON stdout: ${error.message}`);
  }
  if (res.status !== 0) semanticErrors.push(`exit code ${res.status}`);
  if (res.error) semanticErrors.push(`spawn error ${res.error.code || 'unknown'}`);
  if (res.signal) semanticErrors.push(`signal ${res.signal}`);
  const processSuccess = res.status === 0 && !res.error && !res.signal;
  const success = processSuccess && semanticErrors.length === 0;
  return {
    label: label || script.replace(/\.js$/, ''),
    command: `node .knowledge/tools/${script}${args.length ? ' ' + args.join(' ') : ''}`,
    exit: res.status,
    process_success: processSuccess,
    spawn_error: res.error ? { code: res.error.code || null, message: res.error.message } : null,
    signal: res.signal || null,
    success,
    status: success ? 'pass' : 'fail',
    json_status: parsed?.status || null,
    semantic_errors: semanticErrors,
    stdout: rawStdout.trim().slice(0, 12000),
    stderr: String(res.stderr || '').trim().slice(0, 4000)
  };
}

function assertSystemWriteAllowed(actionPath, manifest, operation = 'write') {
  const rel = validateManifestPath(actionPath, 'system path');
  const trustedSystemPath = DEFAULT_MANIFEST.system_paths.some((candidate) => rel === candidate || rel.startsWith(`${candidate}/`));
  const legacyRemoval = operation === 'remove' && [...LEGACY_OLD_UPDATER_COMPATIBLE_REMOVALS]
    .some(candidate => rel === candidate || rel.startsWith(`${candidate}/`));
  if (!trustedSystemPath && !legacyRemoval) {
    throw new Error(`Refusing to write outside the system path policy: ${actionPath}`);
  }
  const protectedPaths = [...DEFAULT_MANIFEST.curated_preserve_paths, ...DEFAULT_MANIFEST.immutable_runtime_evidence_paths,
    ...DEFAULT_MANIFEST.runtime_preserve_paths, ...(manifest.curated_preserve_paths || []),
    ...(manifest.immutable_runtime_evidence_paths || []), ...(manifest.runtime_preserve_paths || []), 'extensions', 'pro'];
  if (operation !== 'remove' && isPreservedDefault(rel)) return;
  if (protectedPaths.some((item) => rel === item || rel.startsWith(`${item}/`) || (operation === 'remove' && item.startsWith(`${rel}/`)))) {
    throw new Error(`Refusing to modify protected project data: ${actionPath}`);
  }
  const systemPath = manifest.system_paths.some((candidate) => rel === candidate || rel.startsWith(`${candidate}/`));
  const removablePath = obsoleteSystemPaths(manifest).some((candidate) => rel === candidate || rel.startsWith(`${candidate}/`));
  if (!systemPath && !removablePath) throw new Error(`Refusing to write non-system path: ${actionPath}`);
  if (!removablePath && isExcludedByManifest(rel, manifest)) throw new Error(`Refusing to write excluded system path: ${actionPath}`);
}

function assertRepairDefaultWriteAllowed(actionPath, manifest) {
  const rel = validateManifestPath(actionPath, 'repair default');
  const allowed = (manifest.repair_default_paths || []).some((defaultPath) => rel === defaultPath);
  if (!allowed || !DEFAULT_MANIFEST.repair_default_paths.includes(rel)) throw new Error(`Refusing to write non-repair-default path: ${actionPath}`);
  if (isExcludedByManifest(rel, manifest)) throw new Error(`Refusing to write excluded repair default path: ${actionPath}`);
}

function targetChangedError(action, actualHash, stage) {
  const error = new Error(stage === 'prepare'
    ? `Target changed after update planning: ${action.path}`
    : `Target changed before update write: ${action.path}`);
  error.code = 'update_target_changed';
  error.update_precondition = {
    code: error.code,
    stage,
    path: action.path,
    action: action.action,
    expected_exists: action.target_sha256 != null,
    actual_exists: actualHash != null,
    expected_sha256: action.target_sha256 ?? null,
    actual_sha256: actualHash
  };
  return error;
}

function prepareGeneration(sourceRoot, actions, migrationDefaults, manifest, generation) {
  const mutations = [], directories = [], createdDirectories = [];
  let bytes = 0;
  function add(row) {
    bytes += (row.before?.length || 0) + (row.after?.length || 0);
    if (bytes > MAX_BYTES || mutations.length + directories.length + createdDirectories.length >= MAX_ENTRIES) {
      throw Object.assign(new Error('Update generation exceeds its admitted aggregate size'), { code: 'update_generation_limit' });
    }
    mutations.push(row);
  }
  function remove(rel) {
    assertSystemWriteAllowed(rel, manifest, 'remove');
    const target = path.join(activeKnowledgeRoot, rel), stat = assertUpdatePath(activeKnowledgeRoot, target);
    if (stat.isDirectory()) {
      directories.push(rel);
      if (directories.length + mutations.length > MAX_ENTRIES) throw new Error('Update removal inventory exceeds its admitted size');
      for (const name of fs.readdirSync(target)) remove(`${rel}/${name}`);
    } else add({ path: rel, operation: 'remove', before: readPhysicalFile(target), after: null,
      beforeMode: stat.mode & 0o777, afterMode: 0o644 });
  }
  for (const action of actions) {
    if (action.action === 'remove') { remove(action.path); continue; }
    if (!['create', 'update'].includes(action.action)) continue;
    assertSystemWriteAllowed(action.path, manifest);
    if (action.kind === 'directory') { createdDirectories.push(action.path); continue; }
    const target = path.join(activeKnowledgeRoot, action.path), stat = assertUpdatePath(activeKnowledgeRoot, target, true);
    const before = stat ? readPhysicalFile(target) : null;
    const actual = before ? crypto.createHash('sha256').update(before).digest('hex') : null;
    if (actual !== action.target_sha256) throw targetChangedError(action, actual, 'prepare');
    const source = readPhysicalFile(sourcePathFor(sourceRoot, action.path));
    if (crypto.createHash('sha256').update(source).digest('hex') !== action.source_sha256) throw new Error(`Source changed after update planning: ${action.path}`);
    add({ path: action.path, operation: 'write', before, after: action.path === 'config.yaml' && before ? mergedConfigBytes(source, before) : source,
      beforeMode: stat ? stat.mode & 0o777 : 0o644, afterMode: runtimeFileMode(action.path) });
  }
  for (const action of migrationDefaults) {
    if (action.action !== 'repair_default') continue;
    assertRepairDefaultWriteAllowed(action.path, manifest);
    const target = path.join(activeKnowledgeRoot, action.path);
    if (assertUpdatePath(activeKnowledgeRoot, target, true)) throw targetChangedError(action, sha256(target), 'prepare');
    const after = readPhysicalFile(sourcePathFor(sourceRoot, action.path));
    if (crypto.createHash('sha256').update(after).digest('hex') !== action.source_sha256) throw new Error(`Repair default changed after planning: ${action.path}`);
    add({ path: action.path, operation: 'repair_default', before: null, after, beforeMode: 0o644, afterMode: 0o644 });
  }
  generation.stage(mutations, directories, createdDirectories);
}

function snapshotPath(root, relPath) {
  const abs = path.join(root, relPath);
  if (!fs.existsSync(abs)) return { exists: false, files: new Map() };
  if (isFile(abs)) return { exists: true, files: new Map([[normalizeRel(relPath), sha256(abs)]]) };
  const files = new Map();
  for (const file of walkFiles(abs)) files.set(normalizeRel(path.posix.join(relPath, file.rel)), sha256(file.abs));
  return { exists: true, files };
}

function matchesManifestPath(relPath, patterns = []) {
  const rel = normalizeRel(relPath);
  return patterns.some((pattern) => rel === pattern || rel.startsWith(`${pattern}/`));
}

function curatedPreservationProof(backupRoot, manifest) {
  if (!backupRoot) return null;
  const paths = [];
  const changedFiles = [];
  const addedFiles = [];
  const runtimeMutableChanges = [];
  const mutable = manifest.curated_runtime_mutable_paths || [];
  for (const relPath of manifest.curated_preserve_paths) {
    const before = snapshotPath(backupRoot, relPath);
    const after = snapshotPath(activeKnowledgeRoot, relPath);
    const beforeKeys = Array.from(before.files.keys()).sort();
    const afterKeys = Array.from(after.files.keys()).sort();
    const changed = beforeKeys.filter((key) => (
      !matchesManifestPath(key, mutable) && before.files.get(key) !== after.files.get(key)
    ));
    const mutableChanged = beforeKeys.filter((key) => (
      matchesManifestPath(key, mutable) && before.files.get(key) !== after.files.get(key)
    ));
    const added = afterKeys.filter((key) => !before.files.has(key));
    if (before.exists && !after.exists && beforeKeys.length === 0 && !matchesManifestPath(relPath, mutable)) {
      changed.push(relPath);
    }
    changedFiles.push(...changed);
    addedFiles.push(...added);
    runtimeMutableChanges.push(...mutableChanged);
    paths.push({
      path: relPath,
      backup_exists: before.exists,
      current_exists: after.exists,
      compared_existing_files: beforeKeys.length,
      changed_existing_files: changed,
      added_files: added,
      runtime_mutable_changed_files: mutableChanged
    });
  }
  return {
    status: changedFiles.length ? 'changed' : 'preserved',
    paths,
    changed_files: changedFiles,
    changed_files_count: changedFiles.length,
    added_files: addedFiles,
    added_files_count: addedFiles.length,
    runtime_mutable_changed_files: runtimeMutableChanges,
    runtime_mutable_changed_files_count: runtimeMutableChanges.length
  };
}

const QUEUE_APPEND_POLICY = 'validated_queue_journal_append_only.v1';
const QUEUE_JOURNAL_FILE = /^maintenance\/transactions\/((sync|doctor)-queue-[0-9]+-[0-9]+-[a-f0-9]{24})\/(.+)$/;

function validateQueueJournalAdditions(backupRoot, addedFiles) {
  const groups = new Map();
  const files = [];
  const errors = [];
  for (const file of uniqueNormalized(addedFiles)) {
    const match = QUEUE_JOURNAL_FILE.exec(file);
    if (!match) { errors.push('addition_is_not_a_queue_journal'); continue; }
    if (!groups.has(match[1])) groups.set(match[1], { kind: match[2], paths: [] });
    groups.get(match[1]).paths.push(file);
  }
  const exactWritePaths = ['stale_items.json', 'repair_queue.json']
    .map(file => path.join(activeKnowledgeRoot, 'maintenance', file));
  const { inspectTransaction } = require('./lib/json-transaction');
  for (const [id, group] of groups) {
    const relative = `maintenance/transactions/${id}`;
    try {
      // An append may introduce a complete new journal, never extend or alter
      // a transaction that was already present at the update checkpoint.
      assertUpdatePath(backupRoot, path.join(backupRoot, relative), true);
      let existed = true;
      try { fs.lstatSync(path.join(backupRoot, relative)); }
      catch (error) { if (error.code === 'ENOENT') existed = false; else throw error; }
      if (existed) throw new Error('queue_journal_existed_in_backup');
      const inspection = inspectTransaction(path.join(activeKnowledgeRoot, relative), {
        allowedContainmentRoots: [activeKnowledgeRoot], allowedWriteRoots: [activeKnowledgeRoot],
        allowedGuardRoots: [activeKnowledgeRoot], exactWritePaths, expectedTransactionId: id
      });
      const metadata = inspection.manifest.intent.metadata;
      const guards = inspection.manifest.intent.guards;
      if (inspection.status !== 'committed' || !inspection.terminal || !inspection.commit_marker ||
          metadata.type !== `${group.kind}_queue_projection` || !Array.isArray(guards) || guards.length !== 2) {
        throw new Error('queue_journal_contract_invalid');
      }
      const expectedFiles = ['manifest.json', 'prepared.json', 'commit.json', 'terminal.json'];
      for (const { entry } of inspection.entries) {
        const guard = guards.find(row => path.resolve(row.target) === path.resolve(entry.target));
        if (!guard || guard.kind !== undefined || path.resolve(guard.containment_root) !== path.resolve(activeKnowledgeRoot) ||
            (entry.old_exists ? guard.expected_sha256 !== entry.old_sha256 || guard.expected_exists === false
              : guard.expected_exists !== false)) throw new Error('queue_journal_preimage_guard_invalid');
        expectedFiles.push(entry.staged);
        if (entry.backup !== null) expectedFiles.push(entry.backup);
      }
      const expected = expectedFiles.map(file => `${relative}/${file}`).sort();
      const live = snapshotPath(activeKnowledgeRoot, relative);
      if (JSON.stringify([...live.files.keys()].sort()) !== JSON.stringify(expected) ||
          JSON.stringify([...group.paths].sort()) !== JSON.stringify(expected)) {
        throw new Error('queue_journal_file_set_invalid');
      }
      for (const file of expected) files.push({ path: file, sha256: live.files.get(file) });
    } catch (error) {
      errors.push(error.code || (/^queue_journal_/.test(error.message) ? error.message : 'queue_journal_invalid'));
    }
  }
  return {
    status: errors.length ? 'failed' : 'verified',
    transaction_ids: [...groups.keys()].sort(),
    files: files.sort((a, b) => a.path.localeCompare(b.path)),
    errors: [...new Set(errors)].sort()
  };
}

function runtimePreservationProof(backupRoot, manifest, options = {}) {
  if (!backupRoot) return null;
  const paths = uniqueNormalized([
    ...DEFAULT_MANIFEST.immutable_runtime_evidence_paths,
    ...DEFAULT_MANIFEST.runtime_preserve_paths,
    ...(manifest.immutable_runtime_evidence_paths || []),
    ...(manifest.runtime_preserve_paths || [])
  ]);
  const details = [];
  const changedFiles = [];
  const removedFiles = [];
  const addedFiles = [];
  for (const relPath of paths) {
    const before = snapshotPath(backupRoot, relPath);
    const after = snapshotPath(activeKnowledgeRoot, relPath);
    const beforeKeys = Array.from(before.files.keys()).sort();
    const afterKeys = Array.from(after.files.keys()).sort();
    const changed = beforeKeys.filter((key) => after.files.has(key) && before.files.get(key) !== after.files.get(key));
    const removed = beforeKeys.filter((key) => !after.files.has(key));
    const added = afterKeys.filter((key) => !before.files.has(key));
    if (before.exists && !after.exists && beforeKeys.length === 0) removed.push(relPath);
    changedFiles.push(...changed);
    removedFiles.push(...removed);
    addedFiles.push(...added);
    details.push({
      path: relPath,
      backup_exists: before.exists,
      current_exists: after.exists,
      before_files: beforeKeys.length,
      after_files: afterKeys.length,
      changed_files: changed,
      removed_files: removed,
      added_files: added
    });
  }
  const appendPolicy = options.allowQueueJournalAdditions === true;
  const additions = appendPolicy ? validateQueueJournalAdditions(backupRoot, addedFiles) : null;
  const allowed = new Set(additions?.status === 'verified' ? additions.files.map(row => row.path) : []);
  const unapprovedAdded = addedFiles.filter(file => !allowed.has(file));
  const violations = [...changedFiles, ...removedFiles, ...unapprovedAdded];
  const historyUnchanged = changedFiles.length === 0 && removedFiles.length === 0;
  return {
    status: violations.length || (additions && additions.status !== 'verified') ? 'changed' : 'preserved',
    proof_source: 'live_backup_comparison',
    backup_path: path.resolve(backupRoot),
    required_paths: [...paths].sort(),
    paths: details,
    changed_files: changedFiles,
    changed_files_count: changedFiles.length,
    removed_files: removedFiles,
    removed_files_count: removedFiles.length,
    added_files: addedFiles,
    added_files_count: addedFiles.length,
    hash_set_unchanged: historyUnchanged && addedFiles.length === 0,
    history_unchanged: historyUnchanged,
    preservation_policy: appendPolicy ? QUEUE_APPEND_POLICY : 'exact_hash_set',
    unapproved_added_files: unapprovedAdded,
    ...(appendPolicy ? { queue_journal_additions: additions } : {})
  };
}

function legacyBackupPathBinding(rawPath) {
  if (typeof rawPath !== 'string' || !rawPath.trim()) {
    return { ok: false, reason: 'legacy_backup_path_missing', path: null };
  }
  // macOS reports the same temporary directory through both /var and
  // /private/var. Normalize only these documented system aliases before the
  // lexical boundary check; user-created links remain rejected below.
  const backupParent = normalizeSystemAlias(path.resolve(
    activeKnowledgeRoot,
    'maintenance',
    'install-backups'
  ));
  const candidate = normalizeSystemAlias(rawPath);
  const relative = path.relative(backupParent, candidate);
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative) ||
      relative.includes(path.sep) || !/^system-files-/.test(relative)) {
    return { ok: false, reason: 'legacy_backup_path_outside_store', path: candidate };
  }
  return { ok: true, reason: null, path: candidate };
}

function safeLegacyBackupPath(rawPath) {
  const binding = legacyBackupPathBinding(rawPath);
  if (!binding.ok) return binding;
  const candidate = binding.path;
  const backupParent = path.resolve(
    activeKnowledgeRoot,
    'maintenance',
    'install-backups'
  );
  let candidateStat;
  try {
    candidateStat = fs.lstatSync(candidate);
  } catch {
    return { ok: false, reason: 'legacy_backup_missing', path: candidate };
  }
  if (!candidateStat.isDirectory() || candidateStat.isSymbolicLink()) {
    return { ok: false, reason: 'legacy_backup_not_real_directory', path: candidate };
  }
  try {
    const realParent = fs.realpathSync(backupParent);
    const realCandidate = fs.realpathSync(candidate);
    const realRelative = path.relative(realParent, realCandidate);
    if (!realRelative || realRelative.startsWith('..') ||
        path.isAbsolute(realRelative) || realRelative.includes(path.sep)) {
      return {
        ok: false,
        reason: 'legacy_backup_realpath_outside_store',
        path: candidate
      };
    }
    return { ok: true, reason: null, path: realCandidate };
  } catch {
    return { ok: false, reason: 'legacy_backup_realpath_unavailable', path: candidate };
  }
}

function requiredRuntimeProofPaths(manifest) {
  return uniqueNormalized([
    ...DEFAULT_MANIFEST.immutable_runtime_evidence_paths,
    ...DEFAULT_MANIFEST.runtime_preserve_paths,
    ...(manifest.immutable_runtime_evidence_paths || []),
    ...(manifest.runtime_preserve_paths || [])
  ]).sort();
}

function validatePreservedRuntimeProof(proof, manifest, expectedBackupPath) {
  const errors = [];
  const requiredPaths = requiredRuntimeProofPaths(manifest);
  if (!proof || typeof proof !== 'object') {
    return { ok: false, errors: ['runtime_proof_missing'], required_paths: requiredPaths };
  }
  if (proof.status !== 'preserved') errors.push('runtime_proof_status_not_preserved');
  const appendPolicy = proof.preservation_policy === QUEUE_APPEND_POLICY;
  const allowedAdditions = new Set();
  if (appendPolicy) {
    const additions = proof.queue_journal_additions;
    if (proof.history_unchanged !== true || additions?.status !== 'verified' ||
        !Array.isArray(additions?.files) || !Array.isArray(additions?.transaction_ids) ||
        !Array.isArray(additions?.errors) || additions.errors.length !== 0) errors.push('runtime_proof_queue_append_invalid');
    for (const row of Array.isArray(additions?.files) ? additions.files : []) {
      if (typeof row?.path !== 'string' || !QUEUE_JOURNAL_FILE.test(row.path) ||
          typeof row.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(row.sha256) || allowedAdditions.has(row.path)) {
        errors.push('runtime_proof_queue_append_file_invalid');
      } else allowedAdditions.add(row.path);
    }
    const ids = [...new Set([...allowedAdditions].map(file => QUEUE_JOURNAL_FILE.exec(file)[1]))].sort();
    if (JSON.stringify(additions?.transaction_ids) !== JSON.stringify(ids)) errors.push('runtime_proof_queue_append_ids_invalid');
    if (!Array.isArray(proof.added_files) || Number(proof.added_files_count) !== proof.added_files.length ||
        JSON.stringify(uniqueNormalized(proof.added_files).sort()) !== JSON.stringify([...allowedAdditions].sort()) ||
        proof.hash_set_unchanged !== (allowedAdditions.size === 0)) errors.push('runtime_proof_queue_append_coverage_invalid');
  } else if (proof.hash_set_unchanged !== true) errors.push('runtime_proof_hash_set_not_unchanged');
  for (const field of appendPolicy ? ['changed_files', 'removed_files'] : ['changed_files', 'removed_files', 'added_files']) {
    if (!Array.isArray(proof[field]) || proof[field].length !== 0) {
      errors.push(`runtime_proof_${field}_not_empty`);
    }
    if (Number(proof[`${field}_count`]) !== 0) {
      errors.push(`runtime_proof_${field}_count_not_zero`);
    }
  }
  const detailPaths = Array.isArray(proof.paths)
    ? proof.paths.map((item) => normalizeRel(item?.path)).filter(Boolean).sort()
    : [];
  const declaredPaths = Array.isArray(proof.required_paths)
    ? uniqueNormalized(proof.required_paths).sort()
    : detailPaths;
  if (JSON.stringify(declaredPaths) !== JSON.stringify(requiredPaths)) {
    errors.push('runtime_proof_declared_path_coverage_mismatch');
  }
  if (detailPaths.length !== new Set(detailPaths).size ||
      JSON.stringify(detailPaths) !== JSON.stringify(requiredPaths)) {
    errors.push('runtime_proof_required_path_coverage_mismatch');
  }
  for (const detail of Array.isArray(proof.paths) ? proof.paths : []) {
    for (const field of appendPolicy ? ['changed_files', 'removed_files'] : ['changed_files', 'removed_files', 'added_files']) {
      if (!Array.isArray(detail?.[field]) || detail[field].length !== 0) {
        errors.push(`runtime_proof_detail_${field}_not_empty`);
      }
    }
    if (appendPolicy && (!Array.isArray(detail?.added_files) || detail.added_files.some(file => !allowedAdditions.has(file)))) {
      errors.push('runtime_proof_detail_queue_append_invalid');
    }
  }
  const proofBinding = legacyBackupPathBinding(proof.backup_path);
  const expectedBinding = legacyBackupPathBinding(expectedBackupPath);
  if (!proofBinding.ok || !expectedBinding.ok ||
      path.resolve(proofBinding.path || '') !== path.resolve(expectedBinding.path || '')) {
    errors.push('runtime_proof_backup_binding_mismatch');
  }
  return {
    ok: errors.length === 0,
    errors: Array.from(new Set(errors)),
    required_paths: requiredPaths
  };
}

function eligibleApplyReport(previousReport, expectedVersion) {
  return previousReport?.status === 'ok' &&
    (previousReport?.phase === 'apply' || previousReport?.mode === 'apply') &&
    previousReport?.installed_version === expectedVersion &&
    previousReport?.source_version === expectedVersion;
}

function reconstructLegacyRuntimeProof(previousReport, manifest, expectedVersion) {
  const eligible = previousReport?.schema_version === '3.2.11' &&
    eligibleApplyReport(previousReport, expectedVersion) &&
    previousReport?.curated_preservation_proof?.status === 'preserved' &&
    Number(previousReport?.curated_preservation_proof?.changed_files_count) === 0;
  if (!eligible) {
    return {
      status: 'not_eligible',
      reason: 'missing_runtime_proof_is_not_an_eligible_3_2_11_apply'
    };
  }
  const backup = safeLegacyBackupPath(previousReport.backup_path);
  if (!backup.ok) {
    return {
      status: 'failed',
      reason: backup.reason,
      backup_path: backup.path
    };
  }
  const proof = runtimePreservationProof(backup.path, manifest);
  const reconstructed = {
    ...proof,
    proof_source: 'reconstructed_legacy_backup',
    reconstructed_at: new Date().toISOString(),
    legacy_report_schema_version: previousReport.schema_version,
    legacy_report_phase: previousReport.phase || previousReport.mode,
    backup_path: backup.path
  };
  return {
    status: proof?.status === 'preserved' ? 'reconstructed' : 'failed',
    reason: proof?.status === 'preserved'
      ? null
      : 'legacy_backup_runtime_evidence_changed',
    backup_path: backup.path,
    proof: reconstructed
  };
}

function revalidatePreviousRuntimeProof(previousReport, manifest, expectedVersion) {
  if (!eligibleApplyReport(previousReport, expectedVersion)) {
    return {
      status: 'failed',
      reason: 'previous_report_is_not_matching_successful_apply',
      errors: ['previous_report_is_not_matching_successful_apply']
    };
  }
  const binding = legacyBackupPathBinding(previousReport.backup_path);
  if (!binding.ok) {
    return { status: 'failed', reason: binding.reason, errors: [binding.reason] };
  }
  const shape = validatePreservedRuntimeProof(
    previousReport.runtime_preservation_proof,
    manifest,
    binding.path
  );
  if (!shape.ok) {
    return {
      status: 'failed',
      reason: 'previous_runtime_proof_invalid',
      errors: shape.errors
    };
  }
  const backup = safeLegacyBackupPath(binding.path);
  if (!backup.ok) {
    return { status: 'failed', reason: backup.reason, errors: [backup.reason] };
  }
  const appendPolicy = previousReport.runtime_preservation_proof.preservation_policy === QUEUE_APPEND_POLICY;
  if (appendPolicy) {
    // Newly appended journals recorded by the prior successful apply are now
    // history too. Their old byte pins cannot be replaced by self-consistent
    // but rewritten manifests/markers during a later verification.
    for (const row of previousReport.runtime_preservation_proof.queue_journal_additions.files) {
      try {
        assertUpdatePath(activeKnowledgeRoot, path.join(activeKnowledgeRoot, row.path));
        if (sha256(path.join(activeKnowledgeRoot, row.path)) !== row.sha256) throw new Error('changed');
      } catch {
        return { status: 'failed', reason: 'previous_appended_journal_changed', errors: ['previous_appended_journal_changed'] };
      }
    }
  }
  const recomputed = runtimePreservationProof(backup.path, manifest, { allowQueueJournalAdditions: appendPolicy });
  const recomputedShape = validatePreservedRuntimeProof(recomputed, manifest, backup.path);
  if (!recomputedShape.ok) {
    return {
      status: 'failed',
      reason: 'live_backup_runtime_evidence_changed',
      errors: recomputedShape.errors,
      backup_path: backup.path,
      proof: recomputed
    };
  }
  return {
    status: 'revalidated',
    reason: null,
    backup_path: backup.path,
    proof: {
      ...recomputed,
      proof_source: 'previous_update_report_revalidated'
    }
  };
}

function persistReconstructedLegacyProof(context, proof) {
  const reportPath = context?.report_path;
  if (!reportPath || !context?.report_sha256 || !context?.previous_report) {
    return {
      status: 'failed',
      message: 'Legacy proof persistence context is incomplete.'
    };
  }
  try {
    if (!fs.existsSync(reportPath) || sha256(reportPath) !== context.report_sha256) {
      throw new Error('The prior apply report changed before legacy proof persistence.');
    }
    const current = readJson(reportPath);
    const enriched = {
      ...current,
      runtime_preservation_proof: proof,
      runtime_proof_provenance: {
        schema_version: 'knowledge-runtime-proof-provenance.v1',
        source: 'reconstructed_legacy_backup',
        reconstructed_at: new Date().toISOString(),
        apply_report_sha256_before_enrichment: context.report_sha256,
        backup_path: proof.backup_path
      }
    };
    writeJsonAtomic(reportPath, enriched);
    const persisted = readJson(reportPath);
    const validation = validatePreservedRuntimeProof(
      persisted.runtime_preservation_proof,
      context.manifest,
      persisted.backup_path
    );
    if (!validation.ok ||
        persisted.phase !== current.phase ||
        persisted.mode !== current.mode ||
        JSON.stringify(persisted.actions || []) !== JSON.stringify(current.actions || [])) {
      throw new Error('Persisted legacy proof failed read-back validation or changed apply provenance.');
    }
    return {
      status: 'ok',
      path: reportPath,
      report_sha256_before: context.report_sha256,
      report_sha256_after: sha256(reportPath),
      preserved_phase: persisted.phase,
      preserved_actions_count: Array.isArray(persisted.actions) ? persisted.actions.length : 0
    };
  } catch (error) {
    return {
      status: 'failed',
      path: reportPath,
      code: error.code || 'ERROR',
      message: error.message
    };
  }
}

function verifySystemCompleteness(sourceRoot, manifest) {
  const missingSystemPaths = new Set();
  const sourceMissing = [];
  const hashMismatches = [];
  const comparedPaths = new Set();
  let checkedFiles = 0;
  const preservedDefaults = [];

  function compareFile(src, dst, relPath) {
    if (!isRegularFile(src)) {
      sourceMissing.push(relPath);
      return;
    }
    if (!isRegularFile(dst)) {
      missingSystemPaths.add(relPath);
      return;
    }
    assertUpdatePath(sourceRoot, src);
    assertUpdatePath(activeKnowledgeRoot, dst);
    if (isPreservedDefault(relPath)) {
      preservedDefaults.push(relPath);
      return;
    }
    if (comparedPaths.has(relPath)) return;
    comparedPaths.add(relPath);
    checkedFiles += 1;
    const expected = relPath === 'config.yaml'
      ? crypto.createHash('sha256').update(mergedConfigBytes(readPhysicalFile(src), readPhysicalFile(dst))).digest('hex')
      : sha256(src);
    const actual = sha256(dst);
    if (expected !== actual) hashMismatches.push({ path: relPath, expected_sha256: expected, actual_sha256: actual });
  }

  for (const relPath of manifest.system_paths) {
    if (isExcludedByManifest(relPath, manifest)) continue;
    const src = sourcePathFor(sourceRoot, relPath);
    if (!fs.existsSync(src)) {
      sourceMissing.push(relPath);
      continue;
    }
    const dst = path.join(activeKnowledgeRoot, relPath);
    if (!fs.existsSync(dst)) missingSystemPaths.add(relPath);
    if (isDirectory(src)) {
      for (const file of walkFiles(src)) {
        const relFile = normalizeRel(path.posix.join(relPath, file.rel));
        if (isExcludedByManifest(relFile, manifest)) continue;
        compareFile(file.abs, path.join(activeKnowledgeRoot, relFile), relFile);
      }
    } else if (isFile(src)) {
      compareFile(src, dst, relPath);
    }
  }
  for (const relPath of manifest.required_system_files || []) {
    compareFile(
      sourcePathFor(sourceRoot, relPath),
      path.join(activeKnowledgeRoot, relPath),
      relPath
    );
  }
  const obsoletePathsPresent = obsoleteSystemPaths(manifest)
    .filter((relPath) => fs.existsSync(path.join(activeKnowledgeRoot, relPath)));
  const missing = Array.from(missingSystemPaths).sort();
  const uniqueSourceMissing = Array.from(new Set(sourceMissing)).sort();
  const failed = uniqueSourceMissing.length || missing.length ||
    hashMismatches.length || obsoletePathsPresent.length;
  return {
    status: failed ? 'failed' : 'ok',
    source_missing_system_paths: uniqueSourceMissing,
    missing_system_paths: missing,
    mismatched_system_paths: hashMismatches.map((item) => item.path),
    system_hash_mismatches: hashMismatches,
    obsolete_system_paths_present: obsoletePathsPresent,
    checked_system_files: checkedFiles,
    preserved_project_defaults: Array.from(new Set(preservedDefaults)).sort()
  };
}

function verifyInstalledSystemPaths(manifest) {
  const missingSystemPaths = Array.from(new Set([
    ...manifest.system_paths.filter((relPath) =>
      !isExcludedByManifest(relPath, manifest) && !fs.existsSync(path.join(activeKnowledgeRoot, relPath))),
    ...(manifest.required_system_files || []).filter((relPath) =>
      !isRegularFile(path.join(activeKnowledgeRoot, relPath)))
  ])).sort();
  const obsoletePathsPresent = obsoleteSystemPaths(manifest)
    .filter((relPath) => fs.existsSync(path.join(activeKnowledgeRoot, relPath)));
  return {
    status: missingSystemPaths.length || obsoletePathsPresent.length ? 'failed' : 'ok',
    source_missing_system_paths: [],
    missing_system_paths: missingSystemPaths,
    mismatched_system_paths: [],
    system_hash_mismatches: [],
    obsolete_system_paths_present: obsoletePathsPresent,
    checked_system_files: 0
  };
}

function markerCounts(filePath) {
  if (!fs.existsSync(filePath)) return { exists: false, blocks: 0, dotKnowledge: 0, knowledgeKit: 0 };
  const text = readPhysicalFile(filePath).toString('utf8');
  const legacyMarker = ['KNOWLEDGE', 'KIT'].join('-');
  const anyMarkerPattern = new RegExp(`<!-- BEGIN (?:DOT-KNOWLEDGE|${legacyMarker}) MANAGED BLOCK -->`, 'g');
  const legacyMarkerPattern = new RegExp(`<!-- BEGIN ${legacyMarker} MANAGED BLOCK -->`, 'g');
  return {
    exists: true,
    blocks: (text.match(anyMarkerPattern) || []).length,
    dotKnowledge: (text.match(/<!-- BEGIN DOT-KNOWLEDGE MANAGED BLOCK -->/g) || []).length,
    knowledgeKit: (text.match(legacyMarkerPattern) || []).length
  };
}

function readVersionFromConfig(root) {
  const configPath = path.join(root, 'config.yaml');
  if (!fs.existsSync(configPath)) return null;
  const match = readPhysicalFile(configPath).toString('utf8').match(/^version:\s*['"]?([^'"\r\n]+)['"]?/m);
  return match ? match[1].trim() : null;
}

function readPackageVersion(root) {
  const packagePath = path.join(root, 'package.json');
  const pkg = fs.existsSync(packagePath) ? readJson(packagePath, {}) : {};
  return String(pkg?.version || readVersionFromConfig(root) || 'unknown');
}

function detectTargetCapabilities(root = activeKnowledgeRoot) {
  return {
    version: readPackageVersion(root),
    has_update_system_files: fs.existsSync(path.join(root, 'tools', 'update-system-files.js')),
    has_install_manifest: fs.existsSync(path.join(root, 'install-manifest.json')),
    has_external_memory_registry: fs.existsSync(path.join(root, 'external_memory', 'registry.json')),
    has_external_memory_retrieval_policy: fs.existsSync(path.join(root, 'external_memory', 'retrieval_policy.json')),
    has_memory_providers: fs.existsSync(path.join(root, 'memory-providers')),
    agent_integration_markers: markerCounts(path.join(path.dirname(root), 'AGENTS.md'))
  };
}

function permissionError(error, check, targetPath) {
  return {
    check,
    status: 'fail',
    path: targetPath,
    code: error.code || 'ERROR',
    message: error.message,
    remediation: `Run the update from a process that can write ${targetPath}, or fix filesystem permissions before retrying.`
  };
}

function cleanupPath(targetPath) {
  try { fs.rmSync(targetPath, { recursive: true, force: true }); } catch {}
}

function probeAtomicWrite(dirPath, check) {
  if (!fs.existsSync(dirPath)) {
    return { check, status: 'warn', path: dirPath, message: 'directory_missing; parent write check must cover creation during apply' };
  }
  const base = path.join(dirPath, `.update-preflight-${process.pid}-${Date.now()}-${Math.random().toString(16).slice(2)}`);
  const tmpPath = `${base}.tmp`;
  const finalPath = `${base}.json`;
  try {
    fs.writeFileSync(tmpPath, '{}\n', 'utf8');
    fs.renameSync(tmpPath, finalPath);
    fs.rmSync(finalPath, { force: true });
    return { check, status: 'pass', path: dirPath };
  } catch (error) {
    cleanupPath(tmpPath);
    cleanupPath(finalPath);
    return permissionError(error, check, dirPath);
  }
}

function probeDirectoryCreate(parentPath, check) {
  if (!fs.existsSync(parentPath)) {
    return { check, status: 'warn', path: parentPath, message: 'parent_missing; root write check must cover creation during apply' };
  }
  const target = path.join(parentPath, `.update-preflight-dir-${process.pid}-${Date.now()}-${Math.random().toString(16).slice(2)}`);
  try {
    fs.mkdirSync(target);
    fs.rmSync(target, { recursive: true, force: true });
    return { check, status: 'pass', path: parentPath };
  } catch (error) {
    cleanupPath(target);
    return permissionError(error, check, parentPath);
  }
}

function permissionPreflight(sourceRoot, manifest) {
  const checks = [];
  const reportDir = path.join(activeKnowledgeRoot, 'maintenance');
  const backupParent = path.join(reportDir, 'install-backups');
  try {
    assertSafeContainmentRoot(activeKnowledgeRoot);
    assertUpdateTree(activeKnowledgeRoot, activeKnowledgeRoot, (rel) =>
      rel === '.lock' || rel === '.runtime' || rel.startsWith('.lock/') || rel.startsWith('.runtime/') || rel.startsWith('maintenance/install-backups/'));
    assertUpdatePath(activeKnowledgeRoot, backupParent, true);
    if (sourceRoot) {
      planActions(sourceRoot, { manifest });
      planRepairDefaults(sourceRoot, manifest);
    }
    checks.push({ check: 'physical_path_safety', status: 'pass', path: activeKnowledgeRoot });
  } catch (error) {
    const failure = permissionError(error, 'physical_path_safety', activeKnowledgeRoot);
    return { status: 'failed', checks: [failure], errors: [failure.message], manual_action_required: [failure.remediation],
      report_path: path.join(reportDir, 'update_system_files_report.json'), backup_parent: backupParent };
  }
  checks.push(fs.existsSync(activeKnowledgeRoot)
    ? { check: 'knowledge_root_exists', status: 'pass', path: activeKnowledgeRoot }
    : { check: 'knowledge_root_exists', status: 'fail', path: activeKnowledgeRoot, message: 'target .knowledge root does not exist' });
  checks.push(probeAtomicWrite(activeKnowledgeRoot, 'knowledge_root_atomic_write'));
  checks.push(probeAtomicWrite(reportDir, 'maintenance_report_atomic_write'));
  checks.push(probeDirectoryCreate(reportDir, 'backup_directory_create'));
  checks.push(probeDirectoryCreate(activeKnowledgeRoot, 'lock_directory_create'));
  if (sourceRoot) {
    const missing = sourceMissingSystemPaths(sourceRoot, manifest);
    checks.push({
      check: 'source_system_completeness',
      status: missing.length ? 'fail' : 'pass',
      path: sourceRoot,
      missing_system_paths: missing
    });
  }
  const failed = checks.filter((check) => check.status === 'fail');
  return {
    status: failed.length ? 'failed' : 'ok',
    checked_at: new Date().toISOString(),
    checks,
    errors: failed.map((check) => `${check.check}: ${check.message || check.code || 'failed'}`),
    manual_action_required: failed.map((check) => check.remediation || `Fix ${check.path} before retrying.`),
    report_path: path.join(reportDir, 'update_system_files_report.json'),
    backup_parent: backupParent
  };
}

function collectPostUpgradeHealth(mode) {
  const quality = readJson(path.join(activeKnowledgeRoot, 'maintenance', 'quality_report.json'), {});
  const stale = readJson(path.join(activeKnowledgeRoot, 'maintenance', 'stale_items.json'), { items: [], stale_items: [] });
  const repair = readJson(path.join(activeKnowledgeRoot, 'maintenance', 'repair_queue.json'), { queue: [] });
  const trust = readJson(path.join(activeKnowledgeRoot, 'maintenance', 'trust_report.json'), { modules: {}, module_statuses: [] });
  const staleItems = stale.items || stale.stale_items || [];
  const repairItems = repair.queue || [];
  const suspectModules = new Set([
    ...((trust.modules || {}).suspect || []),
    ...(trust.module_statuses || []).filter((item) => item.trust_status === 'suspect').map((item) => item.module_id)
  ].filter(Boolean));
  return {
    mode,
    quality_status: quality.status || 'unknown',
    quality_score: quality.quality_score ?? quality.score ?? null,
    stale_items_count: staleItems.length,
    repair_queue_count: repairItems.length,
    suspect_modules_count: suspectModules.size,
    generated_at: new Date().toISOString()
  };
}

function reportManualActions(errors, postUpgradeHealth) {
  const actions = [...errors];
  if (postUpgradeHealth?.stale_items_count > 0) actions.push(`Review ${postUpgradeHealth.stale_items_count} stale item(s) in .knowledge/maintenance/stale_items.json.`);
  if (postUpgradeHealth?.repair_queue_count > 0) actions.push(`Review ${postUpgradeHealth.repair_queue_count} repair queue item(s) in .knowledge/maintenance/repair_queue.json.`);
  if (postUpgradeHealth?.suspect_modules_count > 0) actions.push(`Re-check ${postUpgradeHealth.suspect_modules_count} suspect module(s) against current code/tests before trusting them.`);
  return Array.from(new Set(actions));
}

async function verifyUpgrade(sourceRoot, manifest, control) {
  const checks = [];
  const errors = [];
  const manifestExists = fs.existsSync(path.join(activeKnowledgeRoot, 'install-manifest.json'));
  checks.push({ check: 'install_manifest', status: manifestExists ? 'pass' : 'fail', artifact: '.knowledge/install-manifest.json' });
  if (!manifestExists) errors.push('install-manifest.json is missing.');

  const completeness = sourceRoot ? verifySystemCompleteness(sourceRoot, manifest) : verifyInstalledSystemPaths(manifest);
  checks.push({ check: 'system_completeness', ...completeness });
  if (completeness.source_missing_system_paths.length) errors.push(`Source is missing system artifacts: ${completeness.source_missing_system_paths.join(', ')}`);
  if (completeness.missing_system_paths.length) errors.push(`Installed .knowledge is missing system artifacts: ${completeness.missing_system_paths.slice(0, 20).join(', ')}`);
  if (completeness.mismatched_system_paths.length) errors.push(`Installed system artifacts do not match source SHA-256: ${completeness.mismatched_system_paths.slice(0, 20).join(', ')}`);
  if (completeness.obsolete_system_paths_present.length) errors.push(`Obsolete system artifacts are still installed: ${completeness.obsolete_system_paths_present.join(', ')}`);

  const agentsMarkers = markerCounts(path.join(activeRepoRoot, 'AGENTS.md'));
  checks.push({ check: 'agent_integration_markers', status: agentsMarkers.blocks <= 1 ? 'pass' : 'fail', agents_md: agentsMarkers });
  if (agentsMarkers.blocks > 1) errors.push('AGENTS.md contains more than one managed .knowledge block.');

  const missingRepairDefaults = (manifest.repair_default_paths || []).filter((relPath) => !fs.existsSync(path.join(activeKnowledgeRoot, relPath)));
  checks.push({ check: 'repair_defaults', status: missingRepairDefaults.length ? 'fail' : 'pass', missing_paths: missingRepairDefaults });
  if (missingRepairDefaults.length) errors.push(`Installed .knowledge is missing repair default artifacts: ${missingRepairDefaults.join(', ')}`);

  const previousReportPath = path.join(activeKnowledgeRoot, 'maintenance', 'update_system_files_report.json');
  let runtimeProof = null;
  let runtimeProofSource = null;
  let legacyRecovery = null;
  let previousReport = null;
  let runtimeProofValidation = null;
  let legacyPersistenceContext = null;
  const expectedVersion = sourceRoot
    ? readPackageVersion(sourceRoot)
    : readPackageVersion(activeKnowledgeRoot);
  if (fs.existsSync(previousReportPath)) {
    const previousReportSha256 = sha256(previousReportPath);
    previousReport = readJson(previousReportPath, {});
    const curated = previousReport.curated_preservation_proof;
    const changed = Number(curated?.changed_files_count);
    const curatedPreserved = curated?.status === 'preserved' &&
      changed === 0 &&
      Array.isArray(curated?.changed_files) &&
      curated.changed_files.length === 0;
    checks.push({
      check: 'curated_preservation_proof',
      status: curatedPreserved ? 'pass' : 'fail',
      changed_files: Number.isFinite(changed) ? changed : null
    });
    if (!curatedPreserved) errors.push('Curated preservation proof is missing or invalid.');
    if (previousReport.runtime_preservation_proof) {
      runtimeProofValidation = revalidatePreviousRuntimeProof(
        previousReport,
        manifest,
        expectedVersion
      );
      if (runtimeProofValidation.status === 'revalidated') {
        runtimeProof = runtimeProofValidation.proof;
        runtimeProofSource = 'previous_update_report_revalidated';
      }
    } else {
      legacyRecovery = reconstructLegacyRuntimeProof(
        previousReport,
        manifest,
        expectedVersion
      );
      if (legacyRecovery.status === 'reconstructed') {
        runtimeProof = legacyRecovery.proof;
        runtimeProofSource = 'reconstructed_legacy_backup';
        legacyPersistenceContext = {
          report_path: previousReportPath,
          report_sha256: previousReportSha256,
          previous_report: previousReport,
          manifest
        };
      }
    }
    const runtimePreserved = runtimeProof?.status === 'preserved' &&
      (runtimeProofValidation?.status === 'revalidated' ||
        legacyRecovery?.status === 'reconstructed');
    checks.push({
      check: 'runtime_evidence_preservation_proof',
      status: runtimePreserved ? 'pass' : 'fail',
      proof_source: runtimeProofSource,
      recovery_status: legacyRecovery?.status || null,
      recovery_reason: legacyRecovery?.reason || null,
      validation_status: runtimeProofValidation?.status || null,
      validation_reason: runtimeProofValidation?.reason || null,
      validation_errors: runtimeProofValidation?.errors || [],
      changed_files: runtimeProof?.changed_files_count ?? null,
      removed_files: runtimeProof?.removed_files_count ?? null,
      added_files: runtimeProof?.added_files_count ?? null
    });
    if (!runtimePreserved) errors.push('Runtime evidence preservation proof is missing or not preserved.');
  } else {
    checks.push({ check: 'curated_preservation_proof', status: 'warn', note: 'No previous update report found.' });
    checks.push({ check: 'runtime_evidence_preservation_proof', status: 'warn', note: 'No previous update report found.' });
  }

  const postChecks = [
    await runNode('install-check.js', ['--json'], 'install_check', control),
    await runNode('doctor.js', [], 'doctor', control)
  ];
  for (const check of postChecks) {
    checks.push({
      check: check.label,
      status: check.success ? 'pass' : 'fail',
      command: check.command,
      exit: check.exit,
      json_status: check.json_status,
      semantic_errors: check.semantic_errors
    });
    if (!check.success) errors.push(`${check.command} failed semantic verification: ${check.semantic_errors.join('; ')}.`);
  }
  const previousBackup = safeLegacyBackupPath(previousReport?.backup_path);
  const verifiedBackupPath = legacyRecovery?.status === 'reconstructed'
    ? legacyRecovery.backup_path
    : (runtimeProofValidation?.status === 'revalidated' && previousBackup.ok
      ? previousBackup.path
      : null);
  return {
    checks,
    post_checks: postChecks,
    errors,
    system_completeness: completeness,
    curated_preservation_proof: previousReport?.curated_preservation_proof || null,
    runtime_preservation_proof: runtimeProof,
    runtime_proof_source: runtimeProofSource,
    runtime_proof_validation: runtimeProofValidation,
    legacy_recovery: legacyRecovery,
    backup_path: verifiedBackupPath,
    legacy_persistence_context: legacyPersistenceContext
  };
}

function runtimeBootstrapRequired() {
  if (!fs.existsSync(path.join(activeKnowledgeRoot, 'project_index.json'))) return true;
  const registry = readJson(path.join(activeKnowledgeRoot, 'modules', 'module_registry.json'), { modules: [] });
  return !Array.isArray(registry.modules) || registry.modules.length === 0;
}

async function runPostChecks(mode, control) {
  if (mode === 'none') {
    return {
      runtime_bootstrap_required: false,
      runtime_command: null,
      checks: [
        await runNode('install-check.js', ['--json'], 'install_check', control),
        await runNode('doctor.js', [], 'doctor', control)
      ]
    };
  }
  const bootstrap = runtimeBootstrapRequired();
  const runtimeFlow = bootstrap ? 'import' : 'release';
  return {
    runtime_bootstrap_required: bootstrap,
    runtime_command: `node .knowledge/tools/flow.js ${runtimeFlow} --json --no-color`,
    checks: [
      await runNode('install-check.js', ['--json'], 'install_check', control),
      await runNode('flow.js', [runtimeFlow, '--json', '--no-color'], 'runtime_regeneration', control),
      await runNode('doctor.js', [], 'doctor', control),
      await runNode('flow.js', ['release', '--json', '--no-color'], 'final_release', control)
    ]
  };
}

function summarize(actions, postChecks, curatedProof, runtimeProof, completeness, errors, migrationDefaults = []) {
  const runtimeRegenerated = postChecks
    .filter((check) => check.label === 'runtime_regeneration' || check.label === 'final_release')
    .map((check) => ({
      command: check.command,
      exit: check.exit,
      status: check.success ? 'ok' : 'failed',
      json_status: check.json_status,
      semantic_errors: check.semantic_errors
    }));
  const migrationPlanned = migrationDefaults.filter((a) => a.action === 'repair_default');
  const migrationCreated = migrationPlanned.filter((a) => a.applied === true);
  return {
    create: actions.filter((a) => a.action === 'create').length,
    update: actions.filter((a) => a.action === 'update').length,
    remove: actions.filter((a) => a.action === 'remove').length,
    skip: actions.filter((a) => a.action === 'skip').length,
    preserve: actions.filter((a) => a.action === 'preserve').length,
    // Keep the short legacy counters as plan counts. Completed system writes
    // are separate so dry runs, refused apply and partial failures stay honest.
    planned_system_created: actions.filter((a) => a.action === 'create').length,
    planned_system_updated: actions.filter((a) => a.action === 'update').length,
    planned_system_removed: actions.filter((a) => a.action === 'remove').length,
    system_created: actions.filter((a) => a.action === 'create' && a.applied === true).length,
    system_updated: actions.filter((a) => a.action === 'update' && a.applied === true).length,
    system_removed: actions.filter((a) => a.action === 'remove' && a.applied === true).length,
    system_skipped: actions.filter((a) => a.action === 'skip').length,
    project_preserved: actions.filter((a) => a.action === 'preserve').length,
    migration_defaults_created: migrationCreated.length,
    migration_default_paths: migrationCreated.map((action) => action.path),
    migration_defaults_planned: migrationPlanned.length,
    migration_default_planned_paths: migrationPlanned.map((action) => action.path),
    runtime_regenerated: runtimeRegenerated,
    missing_system_paths: completeness ? completeness.missing_system_paths : [],
    source_missing_system_paths: completeness ? completeness.source_missing_system_paths : [],
    mismatched_system_paths: completeness ? completeness.mismatched_system_paths : [],
    obsolete_system_paths_present: completeness ? completeness.obsolete_system_paths_present : [],
    checked_system_files: completeness ? completeness.checked_system_files : 0,
    curated_changed_files: curatedProof ? curatedProof.changed_files_count : null,
    runtime_preservation_status: runtimeProof ? runtimeProof.status : null,
    runtime_changed_files: runtimeProof
      ? runtimeProof.changed_files_count + runtimeProof.removed_files_count +
        (runtimeProof.unapproved_added_files?.length ?? runtimeProof.added_files_count)
      : null,
    manual_action_required: errors.length ? errors : []
  };
}

function safeWriteUpdateReport(report) {
  const reportPath = path.join(activeKnowledgeRoot, 'maintenance', 'update_system_files_report.json');
  try {
    writeJsonAtomicContained(reportPath, { ...report, generated_at: new Date().toISOString() }, activeKnowledgeRoot);
    return { status: 'ok', path: '.knowledge/maintenance/update_system_files_report.json' };
  } catch (error) {
    return {
      status: 'failed',
      path: reportPath,
      code: error.code || 'ERROR',
      message: error.message,
      remediation: `Fix write permissions for ${path.dirname(reportPath)} and rerun --verify-upgrade --json.`
    };
  }
}

function cleanupDeprecatedManagedIntegrations(backupPath) {
  const candidates = [
    {
      rel: path.join('.agents', 'skills', 'release-preparation-workflow.md'),
      signatures: ['# Codex Skill: Release Preparation Workflow', 'tools/package-release.js']
    }
  ];
  const results = [];
  for (const candidate of candidates) {
    const filePath = path.join(activeRepoRoot, candidate.rel);
    if (!fs.existsSync(filePath)) {
      results.push({ path: normalizeRel(candidate.rel), status: 'absent' });
      continue;
    }
    let text = '';
    try { text = readPhysicalFile(filePath).toString('utf8'); }
    catch (error) {
      results.push({ path: normalizeRel(candidate.rel), status: 'unreadable', error: error.message });
      continue;
    }
    if (!candidate.signatures.every((signature) => text.includes(signature))) {
      results.push({ path: normalizeRel(candidate.rel), status: 'preserved_unrecognized' });
      continue;
    }
    // This path is outside the journal's physical .knowledge root. Retain it
    // and make the remaining migration explicit instead of an unjournaled delete.
    results.push({ path: normalizeRel(candidate.rel), status: 'retained_deprecated_managed_file',
      manual_action: 'Remove this recognized deprecated integration after reviewing its contents.' });
  }
  return results;
}

function legacyBackupForCompatibilityRemoval(relPath) {
  const backupsRoot = path.join(activeKnowledgeRoot, 'maintenance', 'install-backups');
  if (!fs.existsSync(backupsRoot) || !isDirectory(backupsRoot)) return null;
  const candidates = fs.readdirSync(backupsRoot, { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && entry.name.startsWith('system-files-'))
    .map((entry) => path.join(backupsRoot, entry.name))
    .sort()
    .reverse();
  for (const backupRoot of candidates) {
    // A verify pass is normally read-only. The sole exception is completing
    // the known 3.2.11 hand-off, whose updater has already made this backup
    // and copied the new updater into the installed tree.
    if (readPackageVersion(backupRoot) !== '3.2.11') continue;
    if (fs.existsSync(path.join(backupRoot, relPath))) return backupRoot;
  }
  return null;
}

function completeLegacyUpdaterCompatibilityRemovals(manifest) {
  const results = [];
  for (const relPath of manifest.legacy_compatible_remove_paths || []) {
    const target = path.join(activeKnowledgeRoot, relPath);
    if (!fs.existsSync(target)) {
      results.push({ path: relPath, status: 'absent' });
      continue;
    }
    const backupRoot = legacyBackupForCompatibilityRemoval(relPath);
    if (!backupRoot) {
      results.push({
        path: relPath,
        status: 'retained_without_verified_3_2_11_backup'
      });
      continue;
    }
    results.push({ path: relPath, status: 'retained_requires_generation_apply',
      backup_path: path.relative(activeKnowledgeRoot, backupRoot).replace(/\\/g, '/'),
      manual_action: 'Use --from <trusted source> --apply --yes to remove this path through a recoverable generation.' });
  }
  return results;
}

async function mainBody(argv, runtime, control) {
  const args = parseArgs(argv);
  configureTarget(args.targetKnowledgeRoot || runtime.context?.projectKnowledgeRoot || defaultKnowledgeRoot);
  const generation = new UpdateGeneration(activeKnowledgeRoot, { guard: control.guard,
    allowPath: (rel, operation) => operation === 'repair_default'
      ? assertRepairDefaultWriteAllowed(rel, DEFAULT_MANIFEST)
      : assertSystemWriteAllowed(rel, DEFAULT_MANIFEST, operation) });
  const mutating = args.apply && args.yes || args.recoverUpdate && args.yes || args.verifyUpgrade || args.preflight || args.pruneVerifiedBackups && args.yes;
  let lock;
  try {
    if (mutating) {
      control.guard();
      lock = acquireContainedLock({ rootKind: 'project', rootPath: activeKnowledgeRoot,
        context: { projectKnowledgeRoot: activeKnowledgeRoot }, lockName: 'system-update', purpose: LOCKS['system-update'].purpose,
        timeoutMs: 1000 });
      control.guard();
    }
    if (args.recoverUpdate) {
      if (!args.yes) throw new Error('Refusing --recover-update without --yes.');
      const recovery = generation.recover();
      await control.quiesce();
      return { status: 'ok', phase: 'recover_update', recovery, ownership: { status: 'pending_outer_cleanup' } };
    }
    let recovery = null;
    if (generation.pending()) {
      if (args.apply && args.yes) recovery = generation.recover();
      else throw Object.assign(new Error('An unfinished update generation requires --recover-update --yes before this phase.'), { code: 'update_recovery_required' });
    }
    runtime.onMaintenanceSessionOpened = scope => {
      if (args.verifyUpgrade && (!generation.state || ['committed', 'rolled_back', 'aborted'].includes(generation.state.phase))) {
        generation.begin(); generation.stage([]); generation.ready(null); generation.apply();
      }
      return generation.commandOpened(scope);
    };
    runtime.onMaintenanceSessionClosed = id => generation.commandClosed(id);
    return await mainBodyUnlocked(argv, runtime, control, generation, recovery);
  } finally {
    delete runtime.onMaintenanceSessionOpened;
    delete runtime.onMaintenanceSessionClosed;
    if (lock) lock.release();
  }
}

async function mainBodyUnlocked(argv, runtime, control, generation, recovery) {
  const args = parseArgs(argv);
  configureTarget(args.targetKnowledgeRoot || runtime.context?.projectKnowledgeRoot || defaultKnowledgeRoot);
  if (args.pruneVerifiedBackups) {
    const prune = pruneVerifiedBackups(args.yes);
    control.guard();
    return prune;
  }
  const warnings = [];
  const errors = [];
  let sourceRoot = null;
  let manifest = { ...DEFAULT_MANIFEST, manifest_path: null, used_default: true };
  let actions = [];
  let migrationDefaults = [];
  let backupPath = null;
  let postChecks = [];
  let runtimeRegeneration = null;
  let curatedApplyProof = null;
  let runtimeApplyProof = null;
  let curatedProof = null;
  let runtimeProof = null;
  let systemCompleteness = null;
  let verify = null;
  let permission = null;
  let postUpgradeHealth = null;
  let backupVerification = null;
  let reportWrite = null;
  let legacyProofPersistence = null;
  let deprecatedIntegrationCleanup = [];
  let legacyCompatibilityCleanup = [];
  let preconditionFailure = null;

  try {
    manifest = loadInstallManifest(activeKnowledgeRoot);
    if (!['repair_queue', 'report_only', 'none'].includes(args.postUpgradeTrustRefresh)) {
      errors.push(`Invalid --post-upgrade-trust-refresh value: ${args.postUpgradeTrustRefresh}. Use repair_queue, report_only, or none.`);
    }
    if (args.verifyUpgrade) {
      if (args.from) sourceRoot = resolveSourceRoot(args.from);
      manifest = sourceRoot ? loadInstallManifest(sourceRoot) : loadInstallManifest(activeKnowledgeRoot);
      legacyCompatibilityCleanup = completeLegacyUpdaterCompatibilityRemovals(manifest);
      verify = await verifyUpgrade(sourceRoot, manifest, control);
      const legacyPersistenceContext = verify.legacy_persistence_context;
      delete verify.legacy_persistence_context;
      systemCompleteness = verify.system_completeness;
      curatedProof = verify.curated_preservation_proof;
      runtimeProof = verify.runtime_preservation_proof;
      backupPath = verify.backup_path;
      postChecks = verify.post_checks;
      errors.push(...verify.errors);
      if (verify.legacy_recovery?.status === 'reconstructed') {
        control.guard();
        legacyProofPersistence = persistReconstructedLegacyProof(
          legacyPersistenceContext,
          runtimeProof
        );
        if (legacyProofPersistence.status !== 'ok') {
          errors.push(
            `Failed to persist reconstructed legacy runtime proof: ${legacyProofPersistence.message}`
          );
          runtimeProof = null;
          verify.runtime_preservation_proof = null;
          verify.runtime_proof_source = null;
        }
      }
    } else if (args.preflight) {
      if (args.from) sourceRoot = resolveSourceRoot(args.from);
      manifest = sourceRoot ? loadInstallManifest(sourceRoot) : loadInstallManifest(activeKnowledgeRoot);
      permission = permissionPreflight(sourceRoot, manifest);
      errors.push(...permission.errors);
    } else {
      sourceRoot = resolveSourceRoot(args.from);
      manifest = loadInstallManifest(sourceRoot);
      const sourceMissing = sourceMissingSystemPaths(sourceRoot, manifest);
      if (sourceMissing.length) errors.push(`Source is missing system artifacts: ${sourceMissing.join(', ')}`);
      actions = planActions(sourceRoot, { manifest });
      migrationDefaults = planRepairDefaults(sourceRoot, manifest, { repairDefaults: args.repairDefaults });
      const missingDefaultSources = migrationDefaults.filter((action) => action.kind === 'repair_default' && action.reason === 'source_missing');
      if (missingDefaultSources.length) errors.push(`Source is missing repair default artifacts: ${missingDefaultSources.map((action) => action.path).join(', ')}`);
      if (args.apply && !args.yes) errors.push('Refusing --apply without --yes.');
      if (args.apply && args.yes && errors.length === 0) {
        permission = permissionPreflight(sourceRoot, manifest);
        errors.push(...permission.errors);
      }
      if (args.apply && args.yes && errors.length === 0) {
        generation.begin();
        prepareGeneration(sourceRoot, actions, migrationDefaults, manifest, generation);
        backupPath = copyKnowledgeBackup();
        generation.ready(backupPath);
        generation.apply(row => {
          const action = [...actions, ...migrationDefaults].find(item => item.path === row.path && item.action !== 'preserve');
          if (action && action.action !== 'remove') action.applied = true;
        });
        for (const action of actions.filter(row => row.action === 'remove')) action.applied = true;
        deprecatedIntegrationCleanup = cleanupDeprecatedManagedIntegrations(backupPath);
        curatedApplyProof = curatedPreservationProof(backupPath, manifest);
        if (fs.existsSync(path.join(backupPath, 'config.yaml')) &&
            configWithoutVersion(readPhysicalFile(path.join(backupPath, 'config.yaml'))) !== configWithoutVersion(readPhysicalFile(path.join(activeKnowledgeRoot, 'config.yaml')))) {
          errors.push('System-file apply changed operator config outside the version field.');
        }
        runtimeApplyProof = runtimePreservationProof(backupPath, manifest);
        systemCompleteness = verifySystemCompleteness(sourceRoot, manifest);
        if (systemCompleteness.source_missing_system_paths.length) errors.push(`Source is missing system artifacts: ${systemCompleteness.source_missing_system_paths.join(', ')}`);
        if (systemCompleteness.missing_system_paths.length) errors.push(`Installed .knowledge is missing system artifacts: ${systemCompleteness.missing_system_paths.slice(0, 20).join(', ')}`);
        if (systemCompleteness.mismatched_system_paths.length) errors.push(`Installed system artifacts do not match source SHA-256: ${systemCompleteness.mismatched_system_paths.slice(0, 20).join(', ')}`);
        if (systemCompleteness.obsolete_system_paths_present.length) errors.push(`Obsolete system artifacts are still installed: ${systemCompleteness.obsolete_system_paths_present.join(', ')}`);
        if (curatedApplyProof && curatedApplyProof.changed_files_count > 0) {
          errors.push(`System-file apply changed ${curatedApplyProof.changed_files_count} protected curated file(s).`);
        }
        if (runtimeApplyProof && runtimeApplyProof.status !== 'preserved') {
          errors.push('System-file apply changed protected runtime evidence or operator settings.');
        }
        if (errors.length === 0) {
          const postCheckRun = await runPostChecks(args.postUpgradeTrustRefresh, control);
          postChecks = postCheckRun.checks;
          runtimeRegeneration = {
            bootstrap_required: postCheckRun.runtime_bootstrap_required,
            command: postCheckRun.runtime_command
          };
          for (const check of postChecks) {
            if (!check.success) errors.push(`${check.command} failed semantic verification: ${check.semantic_errors.join('; ')}.`);
          }
          postUpgradeHealth = collectPostUpgradeHealth(args.postUpgradeTrustRefresh);
        }
        curatedProof = curatedPreservationProof(backupPath, manifest);
        runtimeProof = runtimePreservationProof(backupPath, manifest, { allowQueueJournalAdditions: true });
        if (curatedProof && curatedProof.changed_files_count > 0) {
          errors.push(`Post-update verification found ${curatedProof.changed_files_count} changed protected curated file(s).`);
        }
        if (runtimeProof && runtimeProof.status !== 'preserved') {
          errors.push('Post-update verification found a changed protected runtime evidence hash-set.');
        }
      }
    }
  } catch (error) {
    if (control.stopped) throw error;
    errors.push(error.message);
    if (error.code === 'update_target_changed') preconditionFailure = error.update_precondition;
  }

  await control.quiesce();
  control.guard();
  if (backupPath) {
    backupVerification = finalizeBackupVerification(backupPath, {
      curatedProof,
      runtimeProof,
      systemCompleteness,
      postChecks,
      errors
    });
    if (backupVerification?.status === 'verification_receipt_write_failed') {
      errors.push(`Backup verification receipt could not be written: ${backupVerification.error}`);
    }
  }

  const legacyReleaseGate = inspectLegacyGate(activeRepoRoot);
  if (legacyReleaseGate.status === 'obsolete') warnings.push(
    'Obsolete project tools/release-gate.js detected. Run node .knowledge/tools/migrate-legacy-release-gate.js --apply to preserve a backup and redirect it to the maintained gate. The runtime distribution does not contain maintainer release certification tools.'
  );
  const plannedDefaults = migrationDefaults.filter((action) => action.action === 'repair_default');
  const completedDefaults = plannedDefaults.filter((action) => action.applied === true);
  const report = {
    schema_version: systemVersion(),
    status: errors.length ? 'failed' : 'ok',
    phase: args.verifyUpgrade ? 'verify_upgrade' : (args.preflight ? 'preflight' : (args.apply ? 'apply' : 'dry_run')),
    mode: args.verifyUpgrade ? 'verify_upgrade' : (args.preflight ? 'preflight' : (args.apply ? 'apply' : 'dry_run')),
    installed_version: readPackageVersion(activeKnowledgeRoot),
    source_version: sourceRoot ? readPackageVersion(sourceRoot) : null,
    source_root: sourceRoot,
    knowledge_root: activeKnowledgeRoot,
    repo_root: activeRepoRoot,
    backup_path: backupPath,
    generation: generation.state ? { id: generation.state.id, phase: generation.state.phase, recovery } : null,
    installed_capabilities: detectTargetCapabilities(activeKnowledgeRoot),
    manifest: {
      schema_version: manifest.schema_version,
      path: manifest.manifest_path,
      used_default: manifest.used_default,
      system_paths: manifest.system_paths.length,
      project_preserve_paths: manifest.project_preserve_paths.length,
      curated_preserve_paths: manifest.curated_preserve_paths.length,
      curated_runtime_mutable_paths: (manifest.curated_runtime_mutable_paths || []).length,
      required_system_files: (manifest.required_system_files || []).length,
      immutable_runtime_evidence_paths: (manifest.immutable_runtime_evidence_paths || []).length,
      runtime_preserve_paths: (manifest.runtime_preserve_paths || []).length,
      runtime_regenerate_paths: manifest.runtime_regenerate_paths.length,
      repair_default_paths: (manifest.repair_default_paths || []).length,
      system_remove_paths: (manifest.system_remove_paths || []).length,
      legacy_compatible_remove_paths: (manifest.legacy_compatible_remove_paths || []).length
    },
    options: {
      repair_defaults: args.repairDefaults,
      post_upgrade_trust_refresh: args.postUpgradeTrustRefresh
    },
    permission_preflight: permission,
    actions,
    migration_defaults: {
      status: !plannedDefaults.length ? 'none_required' : (!args.apply ? 'planned'
        : completedDefaults.length === plannedDefaults.length ? 'applied'
          : completedDefaults.length ? 'partially_applied' : 'not_applied'),
      actions: migrationDefaults,
      planned_paths: plannedDefaults.map((action) => action.path),
      created_paths: completedDefaults.map((action) => action.path)
    },
    precondition_failure: preconditionFailure,
    summary: summarize(actions, postChecks, curatedProof, runtimeProof, systemCompleteness, errors, migrationDefaults),
    system_completeness: systemCompleteness,
    curated_apply_preservation_proof: curatedApplyProof,
    runtime_apply_preservation_proof: runtimeApplyProof,
    curated_preservation_proof: curatedProof,
    runtime_preservation_proof: runtimeProof,
    runtime_regeneration: runtimeRegeneration,
    post_upgrade_health: postUpgradeHealth,
    backup_verification: backupVerification,
    legacy_proof_persistence: legacyProofPersistence,
    legacy_compatibility_cleanup: legacyCompatibilityCleanup,
    deprecated_integration_cleanup: deprecatedIntegrationCleanup,
    legacy_release_gate: legacyReleaseGate,
    verify,
    warnings,
    errors,
    manual_action_required: reportManualActions(errors, postUpgradeHealth),
    post_checks: postChecks
  };

  report.ownership = { status: 'pending_outer_cleanup' };

  if (args.apply && args.yes && (backupPath || permission?.status === 'ok')) {
    control.guard();
    reportWrite = safeWriteUpdateReport(report);
    report.report_write = reportWrite;
    if (reportWrite.status === 'ok') report.report = reportWrite.path;
    else {
      report.status = 'failed';
      report.errors.push(`Failed to write update report: ${reportWrite.message}`);
      report.manual_action_required = reportManualActions(report.errors, postUpgradeHealth);
    }
  }

  if ((args.apply && args.yes || args.verifyUpgrade) && generation.state) {
    try {
      generation.recordReport(report);
      if (report.status === 'ok') report.generation = { ...generation.commit(), recovery };
    } catch (error) {
      if (control.stopped) throw error;
      report.status = 'failed';
      report.errors.push(`Update generation finalization remains unconfirmed: ${error.message}`);
      report.generation_finalization = { status: 'failed', code: error.code || 'ERROR' };
      report.manual_action_required = reportManualActions(report.errors, postUpgradeHealth);
    }
  }

  return report;
}
function optionsFor(options) { return { ...options, budgets: options.budgets || owned.cliBudgets() }; }
function main(argv = process.argv.slice(2), options = {}) {
  return owned.runOwnedOperationSync('updater-main', { argv }, optionsFor(options));
}
async function mainAsync(argv = process.argv.slice(2), options = {}) {
  return (await owned.runOwnedOperation('updater-main', { argv }, optionsFor(options))).value;
}
async function cli(runtime = {}) {
  const controller = new AbortController(), cancel = () => controller.abort();
  process.on('SIGINT', cancel); process.on('SIGTERM', cancel);
  try {
    const report = await mainAsync(process.argv.slice(2), { ...runtime, signal: controller.signal });
    console.log(JSON.stringify(report, null, 2));
    if (report.status !== 'ok') process.exitCode = 2;
  } catch (error) {
    console.log(JSON.stringify({ status: 'failed', phase: 'validation', code: error.code,
      errors: [error.message], ...(error.cleanup ? { cleanup: error.cleanup } : {}) }, null, 2));
    process.exitCode = 2;
  } finally { process.removeListener('SIGINT', cancel); process.removeListener('SIGTERM', cancel); }
}
if (require.main === module) cli();

module.exports = {
  main, mainAsync, parseArgs,
  __owned: { main: (argv, runtime = {}) => {
    const local = { ...runtime };
    return withMaintenanceOperation(local, control => mainBody(argv, local, control));
  }, cli },
  SYSTEM_PATHS,
  PROJECT_PATHS,
  DEFAULT_MANIFEST,
  loadInstallManifest,
  planActions,
  planRepairDefaults,
  permissionPreflight,
  resolveSourceRoot,
  verifySystemCompleteness,
  curatedPreservationProof,
  runtimePreservationProof
};
