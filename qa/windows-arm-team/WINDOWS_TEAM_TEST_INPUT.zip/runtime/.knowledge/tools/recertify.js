#!/usr/bin/env node
'use strict';
// No project context or storage module is loaded before native CLI admission.
const runner = require('./lib/command-runner');
function policy(options, argv) {
  return { ...options, budgets: options.budgets || runner.cliBudgets(require('./lib/path-context').parseCliArgs(argv).flags) };
}
function printResult(result) {
  console.log(JSON.stringify(result, null, 2));
  if (!String(result.status).startsWith('recertified')) process.exitCode = 2;
  return result;
}
function main(argv = process.argv.slice(2), options = {}) {
  return printResult(runner.runOwnedOperationSync('recertify-main', { argv }, policy(options, argv)));
}
async function mainAsync(argv = process.argv.slice(2), options = {}) {
  return (await runner.runOwnedOperation('recertify-main', { argv }, policy(options, argv))).value;
}
async function cli() {
  const argv = process.argv.slice(2), controller = new AbortController();
  const cancel = () => controller.abort();
  process.on('SIGINT', cancel); process.on('SIGTERM', cancel);
  try { printResult(await mainAsync(argv, { signal: controller.signal })); }
  catch (error) { console.error(error.code || error.message); process.exitCode = 1; }
  finally { process.removeListener('SIGINT', cancel); process.removeListener('SIGTERM', cancel); }
}
function ownedMain(argv) {
  if (!Array.isArray(argv) || argv.some(arg => typeof arg !== 'string' || arg.includes('\0'))) throw Object.assign(new Error('Invalid recertify arguments'), { code: 'command_invalid' });
  const flags = require('./lib/path-context').parseCliArgs(argv).flags;
  return require('./recertify-core').createRecertifier(flags).main(argv);
}
let libraryCore;
function library() { return libraryCore ||= require('./recertify-core').createRecertifier(); }
module.exports = { main, mainAsync, __owned: { main: ownedMain } };
// Synchronous in-process library calls preserve their existing signatures.
// Their caller must already own the storage boundary (e.g. repair-on-touch).
// Accessors deliberately avoid spreading or eagerly requiring the core.
for (const key of ['run', 'applyVerificationReceipt', 'validateClosedReceiptSources', 'validatePriorModuleClosures',
  'completedTrustElevation', 'finalizeTrustElevation', '__test']) {
  Object.defineProperty(module.exports, key, { enumerable: true, get: () => library()[key] });
}
if (require.main === module) cli();
