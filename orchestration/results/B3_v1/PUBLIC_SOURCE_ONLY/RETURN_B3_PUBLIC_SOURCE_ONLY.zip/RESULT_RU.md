# Knowledge B3 identity v1 — результат независимого этапа

## Итог

**PARTIAL: поставлен проверенный additive typed/native source slice; настоящая
административная reservation HUID/HGID остаётся POLICY BLOCKED.** Это законченная
передача ограниченного v1, а не положительный bootstrap. Поставленный обычный
provider всегда отказывает; фиктивного successful stub, free-UID authority или
`reserved=true` нет. Исторический blocker B2 закрыт на уровне reviewable
контракта/consumer logic, но **не закрыт как административная host authority**.

START UTC: **2026-11-02 23:25:11**. Hard stop: 2026-11-03 03:25:11 UTC.
Работа завершена до третьего часа; четырёхчасовой лимит не исчерпан.
Реально участвовали implementation agents `identity_native`, `contract_adapter`
и отдельный `independent_critic`. Новые пользовательские чаты не создавались.

Назначенная ветка: `codex/stage-b3-v1-20261103`.
Единственное место результата в repository: `orchestration/results/B3_v1/`.
Здесь передаются additions для независимого применения оркестратором;
продуктовая интеграция и изменение существующего Main не выполнялись.

## Статус по свойствам

| Свойство | Статус | Что фактически сделано / предел |
|---|---|---|
| Закреплённые входы | **DONE** | Все 59 manifest payloads совпали по bytes/SHA. Полученный через GitHub contents API ZIP: 179235 bytes, заданный SHA совпал, CRC 60 entries корректен; все 60 files равны текстовой реконструкции. |
| Additive scope / ABI | **DONE** | 18 новых файлов только под `source4/identity-slice/`; все 59 исходных файлов неизменны. Core, intake, deps, configuration ABI, A3 не менялись. |
| Numeric policy полной pair | **DONE_SOURCE_MODEL** | HUID и HGID исключены из всего inclusive ledger и обоих authorized IDs, включая cross comparisons; sentinels/range проверены. Это validity DATA, не reservation. |
| Закрытые типы / custody | **DONE_SOURCE_MODEL** | Opaque nonrecycled handles, immutable copied request, diagnostic-only snapshot, original-process guard, held namespace duplicate и rechecks, непустой output handle не затирается. |
| Acquisition / fencing / ARM | **DONE_CONSUMER_MODEL** | Typed allocate-before-effects, full pair response, exact request/sequence/ticket binding, local monotonic fencing, conservative partial/unknown debt, one-shot durable-ARM protocol. Настоящую durability должен обеспечить отсутствующий provider. |
| Отказ без provisioning | **DONE_SOURCE_MODEL** | `identity_provider_unavailable.c` не имеет positive branch. При namespace model ordinary provider дал 64 POLICY_BLOCKED + 6 capacity refusals, 0 reservations/births. Physical ordinary namespace probe отдельно NOT_RUN. |
| Отказной Main adapter | **DONE_SOURCE_MODEL** | Frozen original config, exact B1/source consistency, retain возможных effects и terminal cancellation. Gate никогда не возвращает ID_OK, не вызывает arm/offer/spawn/release/exec. |
| Concurrent Main / stale generation | **PARTIAL** | Проверены interleaving model owners, overlap любой компоненты, stale/duplicate/decreasing tickets и local tombstones. Real host arbitration, namespace mappings и external administrators не реализованы. |
| Crash/revocation/C recovery | **PARTIAL** | Consumer сохраняет debts после unknown ARM, modeled crash/live child, revoke, C и close faults. Реального crash/restart/tree observer нет; born/unknown положительно не закрываются. |
| Реальный administrative provisioning | **BLOCKED_POLICY** | Нет утверждённого trust root, provider, глобального pair allocator и durable recovery. Числа/NSS/proc scan это не заменяют. |
| Physical ordinary namespace | **NOT_RUN_ENV_GAP** | `/proc/self/ns/user` в executor возвращает ENOENT; actual unshimmed denial executable rc77. Модель не повышает этот результат до PASS. |
| Main/H/Node/bundle / release | **NOT_RUN / BLOCKED** | Privileged Main/H, credential changes, Node/bundle и product release не запускались; positive release/exec отсутствуют. |
| Применимость передачи | **DONE** | Полные additions и unified patch применены независимо к свежим snapshot; 59 bases и 18 additions совпали по SHA. Fresh-applied runner повторил 48/48 + 25/25. |

## Что поставлено

### Native consumer и закрытая provider boundary

`identity.h` скрывает layout `id_reservation`. Production default не содержит
callback registration, weak-provider override, environment success toggle,
JSON reader или free UID scan. Candidate UID/GID, host/install labels и
namespace metadata отдельно обозначены как DATA. Actual trusted provider
должен независимо установить provenance fixed Main, approved policy и
глобальную область конфликтов.

Native consumer копирует request, удерживает original user namespace duplicate,
проверяет его перед ARM/CHECK/RETIRE и сохраняет ошибки close без повторного
закрытия потенциально reused number. Local 64 slots никогда не переиспользуются,
поэтому старый pointer не становится новой reservation. После исчерпания
возвращается `ID_CAPACITY`; автоматического reset нет.

Provider protocol разделяет `ALLOCATE`, `ACQUIRE_PAIR`, `CHECK`, `ARM`, `RETAIN`
и `RETIRE`. Durable transaction должна предшествовать UID/GID effects. Полная
пара подтверждается целиком; partial, unknown, mismatched или противоречивый
отрицательный ответ удерживает union debt. Local same-namespace collision
проверяется по каждому компоненту, даже если модель provider ошибочно выдаёт
новый positive grant. Это дополнительная защита клиента, не host-wide lock.

ARM расходуется до provider call и должен означать durable «birth may exist».
Потерянный ACK, revocation или новая epoch не дают повторной попытки. Наличие
checks не делает revoke атомарным с будущим clone; обязательная provider policy
после ARM запрещает повторную выдачу IDs при любом исходе.

### Lifetime: сохранённые обязательства после C

Долги UID/GID, descendant tree, output, owned objects, group membership,
subordinate mappings и durable record разделены. Direct-child reap и оба EOF
не закрывают `CHILD_TREE`. Поэтому **born или unknown attempt в v1 никогда не
достигает RETIRED**. Это сознательная консервативная граница, а не реализация
полного положительного recovery.

Never-born attempt может получить durable permanent tombstone; UID/GID при
этом **не возвращаются в свободный пул**, administrative debt остаётся у
provider. Reuse API отсутствует. Неопределённость после Main crash, timeout,
освобождения singleton или PID reuse не считается closure. Противоречивое
позднее birth evidence после known-no-birth необратимо возвращает unknown/tree
debt; повтор no-birth не стирает историю.

Identity API не получает S/W/C и не читает часы. `C_EXPIRED` — trusted observed
event от будущего Main owner loop; модель проверяет sticky latch, не timing.
Provider call синхронный; bounded/nonblocking backend и actual deadline checks
до/после каждого шага остаются отдельной integration обязанностью. Нельзя
считать зависший provider безопасным только по этим тестам.

### Additive adapter

`main-identity-adapter.inc` имеет one-shot capture исходной config и refusal-only
gate на actual B1 seam. Configuration object/address и identity-relevant
ledger/host/install/auth/time fields фиксируются; поздняя подмена отвергается.
Это source consistency, не самостоятельная authentication original Main.

При любом полученном identity handle adapter сохраняет его отдельно от intake,
вызывает retention и отменяет B1. Acquisition, retention, cancel rc/errno и
intake close fault записаны отдельно. Даже модельный успех либо inconsistent
`ID_OK + NULL` не выходит наружу как разрешение. Existing `private-main-intake.c`
не изменён и не включает этот adapter. Exact future call anchors и обязательства
даны в `CHANGES/source4/identity-slice/INTEGRATION_RU.md`.

## Проверки и доказательства

Среда: GCC **13.3.0**, Python **3.12.14**, Git **2.51.1**; exact version stdout
и compiler argv сохранены. Все выполненные операции — source/compiler,
ordinary denial или явно model-only; host policy/accounts/groups/caps/ACL не
менялись.

| Проверка | Результат | Evidence |
|---|---|---|
| Root run02 consumer/model | **48 PASS, 0 FAIL**, 48 unique names | `EVIDENCE/runs/run02/RESULT.json`, `15-model-cases.stdout.txt` |
| Root run02 actual adapter source model | **25 PASS, 0 FAIL**, forbidden API calls 0 | Там же; raw adapter stdout отдельно |
| Fresh applied replay | **48 PASS + 25 PASS**, 0 case failures | `EVIDENCE/runs/fresh_replay/RESULT.json` |
| Независимый critic harness | **6/6 PASS**, exact final consumer SHA | `REVIEWS/NATIVE_FINAL_MODEL_RAW/COMMANDS.json` |
| Native/adapter translation | Strict GCC compile `rc0`; actual pinned core/intake/adapter object не исполнялся | Raw compiler stderr/stdout/rc в run02 и replay |
| Symbol separation | Namespace model не импортирует реальные namespace syscalls; ordinary binary не содержит model hooks | `*-symbols*.stdout.txt` и checks в RESULT.json |
| Negative compile guards | Ожидаемые `rc1`: opaque construction, model provider без test define, unavailable provider с model define | Три raw negative checks; это отказ forbidden build, не успешная его компиляция |
| Actual namespace read | **rc77, errno2 ENOENT, NOT_RUN_ENV_GAP** | `08-ordinary-public-denial.stdout.txt` |
| Exact additions / patch | **59 unchanged + 18 new**, SHA match | `EVIDENCE/APPLICATION.json`, `EVIDENCE/patch_replay/RESULT.json` |
| Apply-helper guard regression | **6/6 independent checks PASS** после исправления unlisted directory symlink | `EVIDENCE/apply-guard-after/RESULT.json`; сохранён semantic FAIL старого helper |
| Input ZIP / text | Exact pinned SHA, CRC и byte equality | `EVIDENCE/INPUT_ZIP_VERIFICATION.json`, `INPUT_TEXT_VERIFICATION.json` |

Root native source SHA:
`e35aa9f59914902a178eee93792352f0995d5f162d25bf7b8364ceca736da998`.
Все полные replacement bytes и exact before/after (для additions `before:null`,
не hash пустого файла) находятся в `CHANGES/` и `BEFORE_AFTER.json`.

### Сохранённые отрицательные результаты

- Root run01: 48 identity model cases прошли, но adapter model compile получил
  **FAIL** из-за неверного test macro в runner. Исправлен runner, run01 и его
  exact новые исходники сохранены в отдельном каталоге.
- Adapter regression: сначала **24 PASS / 1 FAIL**, после изменения
  безусловного final status normalization — **25 PASS / 0 FAIL**. Сохранены
  original adapter before bytes, source pins и оба raw прогона.
- Independent critic ordinary namespace fixture не исполнился (`ENOENT`);
  первая macro-shim модель также имела FAIL из-за fortify alias обхода `open`.
  После исправления оснастки model PASS не заменил старые результаты и не
  объявил физическую namespace доступной.
- Prepublication allowlist поймал оставшиеся промежуточные ELF в review
  directory; они исключены из public packet, original hashes и failure
  сохранены в `EVIDENCE/PACKAGING_ATTEMPTS.json`. Бинарники не опубликованы.
- Независимый helper regression воспроизвёл semantic **FAIL**: старый APPLY.py
  возвращал rc0, но копировал inert marker через unlisted directory symlink.
  Новый helper отвергает все symlink/unsupported nodes, копирует только
  manifest allowlist и сверяет полный output inventory. Шесть проверок
  исправленного helper прошли; old source/raw не переписаны.

## Независимая критика

`REVIEWS/CRITIC_INITIAL_RU.md` и `CRITIC_FINAL_RU.md` содержат **по три
неочевидных вероятных сценария** для каждой из четырёх ключевых проверок:
identity, provenance, ownership, recovery — всего 12. Итоговый review отдельно
сверяет source/compiled snapshot, model/production разделение и сохранность
FAIL. Для каждого сценария указаны точные tests и сохранённые policy/native
пределы; model assumptions не выданы за независимую durability authority.

Исправлены конкретные замечания: contradictory no-effect response, lost
close-fault, duplicate/decreasing ticket, output custody overwrite, sticky
birth contradiction, config/history substitution и defensive adapter ID_OK
return. Для первых source findings pre-fix executable FAIL не придумывался;
реально выполненный adapter regression отделён от source review.

## Что требуется от оркестратора

1. Выбрать administrative policy: постоянный непереиспользуемый dedicated
   principal/pool либо внешний trusted reservation supervisor. Утвердить
   authority domain, запрет конфликтующих login/service/group/subid assignments,
   provenance и durable fencing. Эти решения не выводятся из supplied ABI1.
2. Реализовать и отдельно квалифицировать fixed native provider и его
   authenticated Main session, host-mapped UID/GID arbitration и durable
   crash/rollback handling. Подстановка model provider запрещена.
3. Отдельно решить actual tree/retained custody recovery после born/unknown;
   текущий conservative v1 оставляет reservation удержанной. Не добавлять
   `tree_empty=true`, `cleanup_done` или TTL-release как substitute.
4. Для доказанного namespace env gap использовать ограниченную заявку
   `ACTIONS_REQUEST.json`: standard ubuntu-24.04, timeout 10min, contents read,
   no secrets и только ordinary checks. Workflow не создан и не запущен:
   callable dispatch отсутствует, `.github/workflows` вне разрешённого result
   path. Даже успешный такой run не квалифицирует administrative reservation.
5. Сохранять отдельными protected graph/loader, новый NNP1 entry/addon, full
   offer/descriptor inventory/B5 loop и runtimeFS delegation. HUID не даёт
   private-project access; NNP1 не восстанавливает старый SUID runtime.

Точные команды fresh apply/replay — в `APPLY_RU.md`. Если потребуется новый
этап implementation, использовать **B3 v2** и `NEXT_CHAT_RU.txt`, начиная с
этого exact packet. Продолжение не должно повторно считать текущий source/model
PASS административным или release PASS.
