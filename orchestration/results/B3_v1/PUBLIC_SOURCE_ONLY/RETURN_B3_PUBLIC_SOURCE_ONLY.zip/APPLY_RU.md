# Применение B3 v1 для независимой проверки

## База и область

Использовать exact input snapshot из
`orchestration/stages/B3_identity_v1/input/` на commit
`045424a2528510c317f911cc3a7d3b51bac36f12`.
SHA-256 входного `MANIFEST.json`:
`0e863ed2034050158fac6d29a8d51bc6e4aec01165f3f2e8962f9448c4ecd5af`.

Альтернативно распаковать exact input ZIP из commit
`884d6721293b0c82b66b29d0385fdeb4bc9dcf33`:
179235 bytes, SHA-256
`64660d9aac127eac8e8c61b92945d0a855419cc8a0a6ae8988e71f90d5e58fa9`.
ZIP CRC и полная byte equality с текстовыми input files проверены.

**Все 18 targets новые.** Existing core/intake/deps/config/Main и ABI не
заменяются. `BEFORE_AFTER.json` задаёт `before:null` как отсутствие target, не
как empty-file hash. `CHANGES/` содержит полный итог каждого target;
`CHANGES.patch` — дополнительно проверенный equivalent unified addition patch.
Исходный historical snapshot повторно не публикуется: exact база доступна по
указанному GitHub commit и input manifest.

## Проверка и создание новой копии

Из корня checkout result commit; `b3-v1-applied` должен отсутствовать:

```sh
python3 orchestration/results/B3_v1/APPLY.py \
  --input-snapshot orchestration/stages/B3_identity_v1/input \
  --verify-only

python3 orchestration/results/B3_v1/APPLY.py \
  --input-snapshot orchestration/stages/B3_identity_v1/input \
  --output b3-v1-applied
```

При скачанном отдельном ZIP распаковать его в новый каталог `RETURN_B3`,
использовать `RETURN_B3/APPLY.py` и путь к распакованному exact input. Helper
допускает рядом с packet только три известных outer envelope файла:
`RETURN_B3.zip`, `ZIP_REPLAY.json`, `GITHUB_DELIVERY.json`. Они не являются
исходными additions и не копируются в applied snapshot. Остальные unexpected
payload files отвергаются.

Helper проверяет payload SHA, pinned base SHA, exact file inventory, запрещает
symlinks и target outside `source4/identity-slice/`, не перезаписывает existing
targets/output. После копирования повторно проверяет 59 unchanged bases и все
18 additions. Existing input copy не изменяется.

## Source/compiler/model replay

```sh
python3 b3-v1-applied/source4/identity-slice/tests/run_checks.py \
  --output-dir b3-v1-review-evidence
```

Output directory должен отсутствовать. Runner сохраняет exact source pins,
frozen bytes, stdout/stderr/rc, argv и версии, не перезаписывая FAIL. Нужны
Linux x86_64 GCC/Python/nm. Identity/adaptor модели не создают accounts/groups,
не меняют policy/ACL/caps и не запускают Main/H/Node/bundle. Actual native
core/intake/adapter object только компилируется.

Нормальный source/model результат здесь: 48 consumer/model и 25 adapter/model
cases проходят. При недоступном `/proc/self/ns/user` actual ordinary probe
остаётся `NOT_RUN_ENV_GAP`, даже если model проходит. Флаг
`--require-ordinary-namespace` разрешён для отдельной bounded env-gap проверки
и делает отсутствие этой среды failure; см. `ACTIONS_REQUEST.json`.

## Проверенный альтернативный patch путь

Только в другой fresh копии **input snapshot**, где `source4/identity-slice/`
отсутствует:

```sh
git apply --check /absolute/path/to/RETURN_B3/CHANGES.patch
git apply /absolute/path/to/RETURN_B3/CHANGES.patch
```

Этот путь отдельно replayed: 59 bases и 18 resulting files совпали по SHA.
Нельзя применять patch поверх уже выполненного APPLY.py — targets уже существуют.
Полные additions и exact SHA являются основным контрактом передачи.

## Запрещённые повышения статуса

Не подключать slice к продукту автоматически и не заменять unavailable provider
моделью. Не создавать host identities, не запускать privileged Main/H, старый
SUID runtime, Node/bundle, общий gate или publication/release. Реальный
provisioning и recovery требуют отдельного решения/этапа. Текущая ветка содержит
review packet под results; main/tags/releases и чужие branches не меняются.

`MANIFEST.json` покрывает весь packet payload, исключая себя. Outer archive
SHA/CRC, GitHub payload commit и точный Actions checkout pin представлены
соседними delivery receipts и итоговым сообщением; они не входят в self-hash.
Raw originals сохранены отдельно от public copies. `EVIDENCE/REDACTION.json`
показывает нормализацию ephemeral workspace prefix; никакой stdout FAIL не
удалён и не переименован в PASS.
