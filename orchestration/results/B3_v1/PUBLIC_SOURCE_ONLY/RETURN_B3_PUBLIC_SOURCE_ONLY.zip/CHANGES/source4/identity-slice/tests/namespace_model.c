/* Link-time syscall model: --wrap prevents fortify aliases bypassing the
 * test seam. There are NO __real_* calls. Real namespace access is a separate
 * explicitly NOT_RUN probe if /proc is absent. No model FD is authority. */
#define _GNU_SOURCE
#include "namespace_model.h"
#include <errno.h>
#include <fcntl.h>
#include <linux/nsfs.h>
#include <linux/sched.h>
#include <stdarg.h>
#include <stdint.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>

#define NS_MODEL_FDS 4096u
struct model_fd { unsigned open, is_namespace; uint64_t inode; };
static struct model_fd table[NS_MODEL_FDS];
static uint64_t current_inode = 4001;
static pid_t current_pid = 7001;
static unsigned close_calls, fail_at_close;

void namespace_model_reset(void) {
    memset(table, 0, sizeof table); current_inode = 4001; current_pid = 7001;
    close_calls = fail_at_close = 0;
}
void namespace_model_change_current(void) { ++current_inode; }
void namespace_model_change_pid(void) { ++current_pid; }
void namespace_model_fail_close(unsigned calls_from_now) {
    fail_at_close = close_calls + calls_from_now;
}
unsigned namespace_model_close_calls(void) { return close_calls; }
unsigned namespace_model_open_count(void) {
    unsigned n = 0; for (unsigned i = 0; i < NS_MODEL_FDS; ++i) n += table[i].open;
    return n;
}
static int allocate(unsigned minimum, unsigned is_namespace, uint64_t inode) {
    if (minimum < 3) minimum = 3;
    for (unsigned i = minimum; i < NS_MODEL_FDS; ++i) if (!table[i].open) {
        table[i] = (struct model_fd){1, is_namespace, inode}; return (int)i;
    }
    errno = EMFILE; return -1;
}
int __wrap_open(const char *path, int flags, ...) {
    if ((flags & O_ACCMODE) != O_RDONLY || (flags & (O_CREAT | O_TRUNC))) {
        errno = EACCES; return -1;
    }
    if (!strcmp(path, "/proc/self/ns/user")) return allocate(3, 1, current_inode);
    if (!strcmp(path, "/dev/null")) return allocate(3, 0, 2);
    errno = ENOENT; return -1;
}
int __wrap_fcntl(int fd, int command, ...) {
    if (fd < 0 || (unsigned)fd >= NS_MODEL_FDS || !table[fd].open) {
        errno = EBADF; return -1;
    }
    if (command == F_GETFD) return FD_CLOEXEC;
    if (command != F_DUPFD_CLOEXEC) { errno = EINVAL; return -1; }
    va_list ap; va_start(ap, command); int minimum = va_arg(ap, int); va_end(ap);
    if (minimum < 0) { errno = EINVAL; return -1; }
    return allocate((unsigned)minimum, table[fd].is_namespace, table[fd].inode);
}
int __wrap_fstat(int fd, struct stat *st) {
    if (fd < 0 || (unsigned)fd >= NS_MODEL_FDS || !table[fd].open) {
        errno = EBADF; return -1;
    }
    memset(st, 0, sizeof *st); st->st_dev = 7; st->st_ino = table[fd].inode;
    st->st_mode = S_IFREG | 0400; st->st_nlink = 1; return 0;
}
int __wrap_ioctl(int fd, unsigned long command, ...) {
    if (fd < 0 || (unsigned)fd >= NS_MODEL_FDS || !table[fd].open) {
        errno = EBADF; return -1;
    }
    if (command != NS_GET_NSTYPE || !table[fd].is_namespace) { errno = ENOTTY; return -1; }
    return CLONE_NEWUSER;
}
int __wrap_close(int fd) {
    ++close_calls;
    if (fd < 0 || (unsigned)fd >= NS_MODEL_FDS || !table[fd].open) {
        errno = EBADF; return -1;
    }
    table[fd].open = 0;
    if (close_calls == fail_at_close) { fail_at_close = 0; errno = EINTR; return -1; }
    return 0;
}
pid_t __wrap_getpid(void) { return current_pid; }
