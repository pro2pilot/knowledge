/* ADAPTER SOURCE MODEL ONLY. Includes the actual new adapter and the real
 * pinned configuration declarations, but substitutes explicit MODEL_ONLY
 * facades for Main/intake state and identity API. It never includes/executes
 * core or intake bodies, performs kernel namespace access, creates a child,
 * acquires administrative authority, or invokes privileged host operations.
 * identity.c is tested separately; these facades are not its substitute. */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#if !defined(IDENTITY_MODEL_TEST_ONLY)
#error "Adapter positive provider outcomes are fictitious MODEL ONLY"
#endif
#include "../../BASE_MAIN/verification-linux-service-configuration.h"
#include "../identity.h"
#include <errno.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

/* Only exact field names used by the adapter are represented. Their values
 * are model inputs, not observations of a real Main, accepted V or namespace. */
enum adapter_model_phase { MI_COLD = 0, MI_B1_READY = 5, MI_TERMINAL = 6 };
enum { MI_MAIN_USERNS = 2, MI_ROLE_COUNT = 15 };
struct adapter_model_admin {
    uid_t authorized_uid;
    gid_t authorized_gid;
    uint64_t setup_ns, work_ns, cleanup_ns;
};
static struct {
    enum adapter_model_phase phase;
    pid_t main_pid;
    int fd[MI_ROLE_COUNT];
    struct adapter_model_admin admin;
    uint64_t w, c;
} mi_state;
static struct { int core_offer_blocked, close_fault; } mi_raw;
static volatile sig_atomic_t mi_stopping;
static pid_t adapter_model_pid = 7001;
static pid_t adapter_model_getpid(void) { return adapter_model_pid; }

struct id_reservation { unsigned model_only_marker; };
static struct id_reservation model_handle = {0xB3u};
static struct id_request model_captured_request;
static enum id_status model_acquire_result, model_retain_result;
static enum id_reason model_retention_reason;
static int model_return_handle, model_peer_result, model_cancel_result;
static int model_cancel_errno, model_cancel_close_fault, model_stop_during_acquire;
static int model_late_acquire;
static uint64_t model_now;
static unsigned model_acquire_calls, model_retain_calls, model_cancel_calls;
static unsigned model_peer_calls, model_snapshot_calls;
static unsigned model_forbidden_calls, total_forbidden_calls;
static char model_order[32];
static unsigned model_order_size;
static struct kv_linux_service_configuration model_configuration;
static const char *active_case;
static unsigned passed, failed;

static void step(char tag) {
    if (model_order_size + 1 < sizeof model_order) {
        model_order[model_order_size++] = tag;
        model_order[model_order_size] = 0;
    }
}
static int mi_peer_current(void) {
    ++model_peer_calls;
    step('P');
    return model_peer_result;
}
static int mi_cancel_original(void) {
    ++model_cancel_calls;
    step('C');
    mi_state.phase = MI_TERMINAL;
    mi_raw.close_fault = model_cancel_close_fault;
    if (model_cancel_result < 0) errno = model_cancel_errno;
    return model_cancel_result;
}

enum id_status id_acquire(const struct id_request *request, id_reservation **out) {
    ++model_acquire_calls;
    step('A');
    model_captured_request = *request;
    *out = model_return_handle ? &model_handle : NULL;
    if (model_late_acquire) model_now = mi_state.c + 1;
    if (model_stop_during_acquire) mi_stopping = 1;
    return model_acquire_result;
}
enum id_status id_retain(id_reservation *handle, enum id_reason reason) {
    ++model_retain_calls;
    step('R');
    model_retention_reason = reason;
    if (handle != &model_handle) return ID_INVALID;
    return model_retain_result;
}
/* Trap APIs which this refusal-only adapter must never use. */
enum id_status id_arm_birth(id_reservation *handle) {
    (void)handle;
    ++model_forbidden_calls; ++total_forbidden_calls;
    return ID_BAD_STATE;
}
enum id_status id_try_retire(id_reservation *handle) {
    (void)handle;
    ++model_forbidden_calls; ++total_forbidden_calls;
    return ID_BAD_STATE;
}
enum id_status id_poll_authority(id_reservation *handle) {
    (void)handle;
    ++model_forbidden_calls; ++total_forbidden_calls;
    return ID_BAD_STATE;
}
enum id_status id_get_snapshot(const id_reservation *handle, struct id_snapshot *out) {
    (void)handle;
    ++model_snapshot_calls;
    memset(out, 0, sizeof *out);
    out->phase = ID_PHASE_RESERVED;
    out->last_status = ID_OK;
    out->uid = 2000000000u;
    out->gid = 2000000001u;
    out->birth_armed = 1;
    return ID_OK; /* deliberately optimistic DATA, not a native handle */
}

/* Substitute only getpid in the actual adapter. The public libc declaration
 * above remains unchanged, and no process identity is read at runtime. */
#define getpid adapter_model_getpid
#include "../main-identity-adapter.inc"
#undef getpid

#define CHECK(condition) do { if (!(condition)) { \
    printf("{\"kind\":\"assertion\",\"case\":\"%s\",\"line\":%u}\n", \
           active_case, (unsigned)__LINE__); return 0; } } while (0)

static void reset_model(void) {
    memset(&model_configuration, 0, sizeof model_configuration);
    model_configuration.policy.authorized_uid = 1000;
    model_configuration.policy.authorized_gid = 1001;
    model_configuration.policy.setup_ns = 100;
    model_configuration.policy.work_ns = 200;
    model_configuration.policy.cleanup_ns = 300;
    model_configuration.history.uid_first = 1000000000u;
    model_configuration.history.uid_last = 1800000000u;
    memset(model_configuration.history.host_id, 0x11, 16);
    memset(model_configuration.history.installation_id, 0x22, 16);
    memset(&mi_state, 0, sizeof mi_state);
    adapter_model_pid = 7001;
    mi_state.phase = MI_B1_READY;
    mi_state.main_pid = adapter_model_pid;
    for (unsigned i = 0; i < MI_ROLE_COUNT; ++i) mi_state.fd[i] = -1;
    mi_state.fd[MI_MAIN_USERNS] = 42; /* DATA only; never used as OS FD */
    mi_state.admin.authorized_uid = model_configuration.policy.authorized_uid;
    mi_state.admin.authorized_gid = model_configuration.policy.authorized_gid;
    mi_state.admin.setup_ns = model_configuration.policy.setup_ns;
    mi_state.admin.work_ns = model_configuration.policy.work_ns;
    mi_state.admin.cleanup_ns = model_configuration.policy.cleanup_ns;
    mi_state.w = 1000; mi_state.c = 1500; model_now = 900;
    memset(&mi_raw, 0, sizeof mi_raw);
    mi_stopping = 0;
    memset(&id_main_configuration_original, 0, sizeof id_main_configuration_original);
    id_main_configuration_address = NULL;
    id_main_identity_original = NULL;
    id_main_identity_owner = 0;
    id_main_raw = (struct id_main_adapter_receipt){
        .acquisition = ID_BAD_STATE, .retention = ID_BAD_STATE
    };
    memset(&model_captured_request, 0, sizeof model_captured_request);
    model_acquire_result = ID_POLICY_BLOCKED;
    model_retain_result = ID_RETAINED;
    model_return_handle = 0;
    model_peer_result = model_cancel_result = 0;
    model_cancel_errno = model_cancel_close_fault = 0;
    model_stop_during_acquire = model_late_acquire = 0;
    model_retention_reason = (enum id_reason)0;
    model_acquire_calls = model_retain_calls = model_cancel_calls = 0;
    model_peer_calls = model_snapshot_calls = model_forbidden_calls = 0;
    model_order_size = 0; memset(model_order, 0, sizeof model_order);
}
static int capture(void) {
    return id_main_capture_configuration_original(&model_configuration) == 0;
}
static enum id_status gate(void) {
    return id_main_reserve_original(&model_configuration, 2000000000u, 2000000001u);
}
static int denied_without_acquisition(void) {
    CHECK(gate() == ID_INVALID);
    CHECK(model_acquire_calls == 0 && model_retain_calls == 0);
    CHECK(id_main_raw.origin_refused && id_main_raw.attempted);
    CHECK(model_forbidden_calls == 0);
    return 1;
}

static int no_capture(void) {
    CHECK(gate() == ID_BAD_STATE);
    CHECK(!model_acquire_calls && !model_cancel_calls && !model_peer_calls);
    CHECK(!id_main_identity_original);
    CHECK(id_main_capture_configuration_original(NULL) == -1);
    return 1;
}
static int foreign_configuration_pointer(void) {
    CHECK(capture());
    struct kv_linux_service_configuration copied = model_configuration;
    CHECK(id_main_reserve_original(&copied, 2000000000u, 2000000001u) == ID_INVALID);
    CHECK(!model_acquire_calls && model_cancel_calls == 1);
    CHECK(id_main_raw.origin_refused && !id_main_identity_original);
    return 1;
}
static int changed_ledger_first(void) {
    CHECK(capture()); ++model_configuration.history.uid_first;
    return denied_without_acquisition();
}
static int changed_ledger_last(void) {
    CHECK(capture()); --model_configuration.history.uid_last;
    return denied_without_acquisition();
}
static int changed_installation(void) {
    CHECK(capture()); model_configuration.history.installation_id[7] ^= 1;
    return denied_without_acquisition();
}
static int changed_host(void) {
    CHECK(capture()); model_configuration.history.host_id[5] ^= 1;
    return denied_without_acquisition();
}
static int changed_authorized_uid(void) {
    CHECK(capture()); ++model_configuration.policy.authorized_uid;
    return denied_without_acquisition();
}
static int changed_authorized_gid(void) {
    CHECK(capture()); ++model_configuration.policy.authorized_gid;
    return denied_without_acquisition();
}
static int changed_time_policy(void) {
    CHECK(capture()); ++model_configuration.policy.cleanup_ns;
    return denied_without_acquisition();
}
static int changed_intake_admin(void) {
    CHECK(capture()); ++mi_state.admin.work_ns;
    return denied_without_acquisition();
}
static int original_owner_changed(void) {
    CHECK(capture()); ++adapter_model_pid;
    CHECK(gate() == ID_OWNER_MISMATCH);
    CHECK(!model_acquire_calls && !model_cancel_calls && !model_peer_calls);
    CHECK(id_main_capture_configuration_original(&model_configuration) == -1);
    return 1;
}
static int foreign_intake_owner(void) {
    CHECK(capture()); ++mi_state.main_pid;
    CHECK(gate() == ID_INVALID);
    CHECK(!model_acquire_calls && !model_cancel_calls);
    CHECK(id_main_raw.origin_refused);
    return 1;
}
static int repeated_gate_is_one_shot(void) {
    CHECK(capture());
    CHECK(id_main_capture_configuration_original(&model_configuration) == -1);
    CHECK(gate() == ID_POLICY_BLOCKED);
    CHECK(gate() == ID_BAD_STATE);
    CHECK(model_acquire_calls == 1 && model_cancel_calls == 1);
    return 1;
}
static int peer_revalidation_failure(void) {
    CHECK(capture()); model_peer_result = -1;
    CHECK(gate() == ID_INVALID);
    CHECK(model_peer_calls == 1 && !model_acquire_calls && model_cancel_calls == 1);
    CHECK(!strcmp(model_order, "PC"));
    return 1;
}
static int missing_policy_has_no_authority(void) {
    CHECK(capture());
    CHECK(gate() == ID_POLICY_BLOCKED);
    CHECK(!id_main_identity_original && !id_main_raw.retained_handle);
    CHECK(model_acquire_calls == 1 && model_retain_calls == 0 && model_cancel_calls == 1);
    CHECK(mi_raw.core_offer_blocked && mi_state.phase == MI_TERMINAL);
    CHECK(id_main_raw.acquisition == ID_POLICY_BLOCKED);
    CHECK(model_captured_request.authorized_uid == 1000);
    CHECK(model_captured_request.authorized_gid == 1001);
    CHECK(model_captured_request.ledger_first == 1000000000u);
    CHECK(model_captured_request.ledger_last == 1800000000u);
    CHECK(model_captured_request.candidate_uid == 2000000000u);
    CHECK(model_captured_request.candidate_gid == 2000000001u);
    CHECK(model_captured_request.original_userns_fd == 42);
    CHECK(!memcmp(model_captured_request.host_id, model_configuration.history.host_id, 16));
    CHECK(!memcmp(model_captured_request.installation_id, model_configuration.history.installation_id, 16));
    CHECK(!strcmp(model_order, "PAC"));
    return 1;
}
static int model_acquisition_never_becomes_birth(void) {
    CHECK(capture()); model_acquire_result = ID_OK; model_return_handle = 1;
    CHECK(gate() == ID_RETAINED);
    CHECK(id_main_identity_original == &model_handle && id_main_raw.retained_handle);
    CHECK(model_acquire_calls == 1 && model_retain_calls == 1 && model_cancel_calls == 1);
    CHECK(model_retention_reason == ID_REASON_RECOVERY_REQUIRED);
    CHECK(id_main_raw.acquisition == ID_OK && id_main_raw.retention == ID_RETAINED);
    CHECK(mi_raw.core_offer_blocked && model_forbidden_calls == 0);
    CHECK(!strcmp(model_order, "PARC"));
    return 1;
}
static int inconsistent_success_without_handle(void) {
    CHECK(capture()); model_acquire_result = ID_OK; model_return_handle = 0;
    CHECK(gate() == ID_BAD_STATE);
    CHECK(id_main_raw.acquisition == ID_OK); /* Preserve contradictory input. */
    CHECK(!id_main_identity_original && !model_retain_calls);
    CHECK(model_cancel_calls == 1 && mi_raw.core_offer_blocked);
    CHECK(!strcmp(model_order, "PAC") && !model_forbidden_calls);
    return 1;
}
static int partial_effects_remain_retained(void) {
    CHECK(capture()); model_acquire_result = ID_RETAINED; model_return_handle = 1;
    CHECK(gate() == ID_RETAINED);
    CHECK(id_main_identity_original == &model_handle && model_retain_calls == 1);
    CHECK(model_cancel_calls == 1 && id_main_raw.retained_handle);
    CHECK(!strcmp(model_order, "PARC"));
    return 1;
}
static int stale_unknown_handle_remains_retained(void) {
    CHECK(capture()); model_acquire_result = ID_STALE; model_return_handle = 1;
    CHECK(gate() == ID_STALE);
    CHECK(id_main_identity_original == &model_handle && model_retain_calls == 1);
    CHECK(model_cancel_calls == 1 && id_main_raw.retained_handle);
    return 1;
}
static int retention_and_cancel_failures_visible(void) {
    CHECK(capture()); model_acquire_result = ID_OK; model_return_handle = 1;
    model_retain_result = ID_STALE;
    model_cancel_result = -1; model_cancel_errno = EIO; model_cancel_close_fault = 1;
    CHECK(gate() == ID_RETAINED);
    CHECK(id_main_raw.retention == ID_STALE && id_main_raw.retain_attempted);
    CHECK(id_main_raw.cancel_attempted && id_main_raw.cancel_result == -1);
    CHECK(id_main_raw.cancel_error == EIO && id_main_raw.intake_close_fault == 1);
    CHECK(id_main_identity_original == &model_handle && id_main_raw.retained_handle);
    CHECK(!strcmp(model_order, "PARC") && !model_forbidden_calls);
    return 1;
}
static int late_acquire_still_only_retains(void) {
    CHECK(capture()); model_acquire_result = ID_OK; model_return_handle = 1;
    model_late_acquire = 1;
    CHECK(gate() == ID_RETAINED);
    CHECK(model_now > mi_state.c && model_now > mi_state.w);
    CHECK(model_retain_calls == 1 && model_cancel_calls == 1 && !model_forbidden_calls);
    CHECK(id_main_identity_original == &model_handle);
    return 1;
}
static int stop_during_acquire_still_only_retains(void) {
    CHECK(capture()); model_acquire_result = ID_OK; model_return_handle = 1;
    model_stop_during_acquire = model_late_acquire = 1;
    CHECK(gate() == ID_RETAINED);
    CHECK(mi_stopping && model_now > mi_state.c);
    CHECK(model_retain_calls == 1 && model_cancel_calls == 1 && !model_forbidden_calls);
    CHECK(id_main_identity_original == &model_handle);
    return 1;
}
static int optimistic_snapshot_cannot_mint_authority(void) {
    CHECK(capture());
    struct id_snapshot forged;
    CHECK(id_get_snapshot(NULL, &forged) == ID_OK);
    forged.phase = ID_PHASE_RESERVED; forged.birth_armed = 1;
    forged.retained_debt = 0; forged.pair_permanently_tombstoned = 1;
    CHECK(forged.birth_armed && forged.phase == ID_PHASE_RESERVED);
    CHECK(gate() == ID_POLICY_BLOCKED);
    CHECK(model_snapshot_calls == 1); /* Only the test read it; adapter did not. */
    CHECK(!id_main_identity_original && !model_retain_calls && !model_forbidden_calls);
    return 1;
}
static int stop_before_acquire_refuses(void) {
    CHECK(capture()); mi_stopping = 1;
    CHECK(gate() == ID_INVALID);
    CHECK(!model_acquire_calls && model_cancel_calls == 1 && !model_peer_calls);
    return 1;
}
static int nonready_capsule_refuses(void) {
    CHECK(capture()); mi_state.phase = MI_COLD;
    CHECK(gate() == ID_INVALID);
    CHECK(!model_acquire_calls && !model_peer_calls && model_cancel_calls == 1);
    return 1;
}

struct adapter_case { const char *name; int (*run)(void); };
int main(void) {
    static const struct adapter_case cases[] = {
        {"no_capture", no_capture},
        {"foreign_configuration_pointer", foreign_configuration_pointer},
        {"changed_ledger_first", changed_ledger_first},
        {"changed_ledger_last", changed_ledger_last},
        {"changed_installation", changed_installation},
        {"changed_host", changed_host},
        {"changed_authorized_uid", changed_authorized_uid},
        {"changed_authorized_gid", changed_authorized_gid},
        {"changed_time_policy", changed_time_policy},
        {"changed_intake_admin", changed_intake_admin},
        {"original_owner_changed", original_owner_changed},
        {"foreign_intake_owner", foreign_intake_owner},
        {"repeated_gate_is_one_shot", repeated_gate_is_one_shot},
        {"peer_revalidation_failure", peer_revalidation_failure},
        {"missing_policy_has_no_authority", missing_policy_has_no_authority},
        {"model_acquisition_never_becomes_birth", model_acquisition_never_becomes_birth},
        {"inconsistent_success_without_handle", inconsistent_success_without_handle},
        {"partial_effects_remain_retained", partial_effects_remain_retained},
        {"stale_unknown_handle_remains_retained", stale_unknown_handle_remains_retained},
        {"retention_and_cancel_failures_visible", retention_and_cancel_failures_visible},
        {"late_acquire_still_only_retains", late_acquire_still_only_retains},
        {"stop_during_acquire_still_only_retains", stop_during_acquire_still_only_retains},
        {"optimistic_snapshot_cannot_mint_authority", optimistic_snapshot_cannot_mint_authority},
        {"stop_before_acquire_refuses", stop_before_acquire_refuses},
        {"nonready_capsule_refuses", nonready_capsule_refuses}
    };
    for (unsigned i = 0; i < sizeof cases / sizeof cases[0]; ++i) {
        reset_model(); active_case = cases[i].name;
        int ok = cases[i].run();
        if (model_forbidden_calls) ok = 0;
        if (ok) ++passed; else ++failed;
        printf("{\"kind\":\"case\",\"name\":\"%s\",\"result\":\"%s\","
               "\"scope\":\"ADAPTER_SOURCE_MODEL_ONLY\"}\n",
               active_case, ok ? "PASS" : "FAIL");
    }
    printf("{\"kind\":\"summary\",\"result\":\"%s\",\"passed\":%u,\"failed\":%u,"
           "\"forbidden_api_calls\":%u,\"native_main_h\":\"NOT_RUN\","
           "\"administrative_authority\":\"NOT_PROVEN\"}\n",
           failed ? "FAIL" : "PASS_ADAPTER_SOURCE_MODEL", passed, failed,
           total_forbidden_calls);
    return failed ? 1 : 0;
}
