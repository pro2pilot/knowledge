/* MODEL ONLY. This file must never be linked into production Main. */
#include "model_provider.h"
#include "../identity_internal.h"
#include <stdio.h>
#include <string.h>

#define MODEL_RECORD_LIMIT 256u
struct model_record {
    struct id_bound_request request;
    struct id_provider_ticket ticket;
    const void *owner;
    uint64_t last_sequence;
    uint32_t debt;
    unsigned held, armed, revoked, quarantined, tombstoned;
};
static struct model_record records[MODEL_RECORD_LIMIT];
static unsigned used, calls[IDP_RETIRE + 1], protocol_errors;
static uint64_t epoch, next_transaction, next_fence;
static enum id_provider_operation injected_operation;
static enum model_fault injected_fault;

static int request_same(const struct id_bound_request *a,
                        const struct id_bound_request *b) {
    return a->authorized_uid == b->authorized_uid &&
        a->authorized_gid == b->authorized_gid &&
        a->ledger_first == b->ledger_first && a->ledger_last == b->ledger_last &&
        a->uid == b->uid && a->gid == b->gid &&
        !memcmp(a->host_id, b->host_id, 16) &&
        !memcmp(a->installation_id, b->installation_id, 16) &&
        a->userns_device == b->userns_device && a->userns_inode == b->userns_inode;
}
static int ticket_same(const struct id_provider_ticket *a,
                       const struct id_provider_ticket *b) {
    return !memcmp(a->issuer_id, b->issuer_id, 16) && a->epoch == b->epoch &&
        a->transaction == b->transaction && a->fence == b->fence;
}
static struct model_record *record_for(uint64_t transaction) {
    for (unsigned i = 0; i < used; ++i)
        if (records[i].ticket.transaction == transaction) return &records[i];
    return NULL;
}
void model_reset(void) {
    memset(records, 0, sizeof records); memset(calls, 0, sizeof calls);
    used = protocol_errors = 0; epoch = next_transaction = next_fence = 1;
    injected_operation = 0; injected_fault = MODEL_NORMAL;
}
void model_fault_once(enum id_provider_operation op, enum model_fault fault) {
    injected_operation = op; injected_fault = fault;
}
void model_advance_epoch(void) { ++epoch; }
void model_revoke(uint64_t tx) {
    struct model_record *r = record_for(tx);
    if (r) r->revoked = 1;
}
unsigned model_calls(enum id_provider_operation op) {
    return op >= IDP_ALLOCATE && op <= IDP_RETIRE ? calls[op] : 0;
}
unsigned model_records(void) { return used; }
unsigned model_pair_excluded(uint32_t uid, uint32_t gid) {
    for (unsigned i = 0; i < used; ++i)
        /* Host-global component exclusion intentionally does not partition
         * the namespace by installation ID or by the requesting Main. */
        if (records[i].held && (records[i].request.uid == uid ||
                               records[i].request.gid == gid)) return 1;
    return 0;
}
unsigned model_record_armed(uint64_t tx) {
    struct model_record *r = record_for(tx); return r ? r->armed : 0;
}
unsigned model_record_tombstoned(uint64_t tx) {
    struct model_record *r = record_for(tx); return r ? r->tombstoned : 0;
}
uint32_t model_record_debt(uint64_t tx) {
    struct model_record *r = record_for(tx); return r ? r->debt : 0;
}
unsigned model_protocol_errors(void) { return protocol_errors; }

static void model_step(const struct id_provider_call *call,
                       struct id_provider_reply *reply) {
    memset(reply, 0, sizeof *reply);
    if (!call || call->operation < IDP_ALLOCATE || call->operation > IDP_RETIRE) {
        ++protocol_errors; return;
    }
    ++calls[call->operation];
    reply->request = call->request; reply->ticket = call->ticket;
    reply->sequence = call->sequence; reply->retained_debt = call->retained_debt;
    enum model_fault fault = MODEL_NORMAL;
    if (injected_operation == call->operation) {
        fault = injected_fault; injected_operation = 0; injected_fault = MODEL_NORMAL;
    }
    if (fault == MODEL_POLICY_MISSING) {
        reply->outcome = IDP_POLICY_MISSING; return;
    }
    if (fault == MODEL_NO_EFFECT) { reply->outcome = IDP_NO_EFFECT; return; }
    struct model_record *r = NULL;
    if (call->operation == IDP_ALLOCATE) {
        if (used == MODEL_RECORD_LIMIT || !call->sequence || !call->local_owner) {
            ++protocol_errors; reply->outcome = IDP_UNKNOWN; return;
        }
        r = &records[used++]; r->request = call->request; r->owner = call->local_owner;
        memset(r->ticket.issuer_id, 0x51, sizeof r->ticket.issuer_id);
        r->ticket.epoch = epoch; r->ticket.transaction = next_transaction++;
        r->ticket.fence = next_fence++;
        r->last_sequence = call->sequence; r->debt = ID_DEBT_DURABLE_RECORD;
        reply->ticket = r->ticket; reply->outcome = IDP_ALLOCATED;
        reply->retained_debt = r->debt;
    } else {
        r = record_for(call->ticket.transaction);
        if (!r || !ticket_same(&r->ticket, &call->ticket) ||
            !request_same(&r->request, &call->request) || r->owner != call->local_owner ||
            call->sequence <= r->last_sequence) {
            ++protocol_errors; reply->outcome = IDP_STALE; return;
        }
        r->last_sequence = call->sequence;
        if (r->ticket.epoch != epoch) { reply->outcome = IDP_STALE; return; }
        if (r->revoked && call->operation != IDP_RETAIN) {
            reply->outcome = IDP_REVOKED; return;
        }
        switch (call->operation) {
        case IDP_ACQUIRE_PAIR:
            if (fault != MODEL_ALLOW_OVERLAP && model_pair_excluded(call->request.uid, call->request.gid)) {
                reply->outcome = IDP_BUSY; return;
            }
            r->held = 1; r->debt = ID_ADMIN_DEBT;
            reply->outcome = IDP_PAIR_HELD;
            reply->touched_components = ID_DEBT_UID | ID_DEBT_GID;
            if (fault == MODEL_PARTIAL_UID || fault == MODEL_PARTIAL_GID) {
                /* A partial provider side effect is conservatively quarantined
                 * as a full pair; another transaction cannot acquire its mate. */
                r->quarantined = 1; reply->outcome = IDP_PARTIAL;
                reply->touched_components = fault == MODEL_PARTIAL_UID ? ID_DEBT_UID : ID_DEBT_GID;
            }
            break;
        case IDP_CHECK:
            reply->outcome = r->held && !r->quarantined && !r->tombstoned ? IDP_CURRENT : IDP_QUARANTINED;
            break;
        case IDP_ARM:
            if (!r->held || r->armed || r->quarantined || r->tombstoned) {
                ++protocol_errors; reply->outcome = IDP_UNKNOWN; return;
            }
            r->armed = 1; r->debt = ID_ALL_DEBT; reply->outcome = IDP_ARMED;
            break;
        case IDP_RETAIN:
            r->quarantined = 1; r->debt |= call->retained_debt;
            reply->outcome = IDP_QUARANTINED; break;
        case IDP_RETIRE:
            if (!r->held || (r->armed && !(call->native_facts & ID_FACT_BIRTH_FAILED_KNOWN))) {
                /* Fact bit 0 is the trusted definite-no-birth event. This
                 * remains a model assumption, never an admin attestation. */
                ++protocol_errors; reply->outcome = IDP_UNKNOWN; return;
            }
            r->tombstoned = 1; r->quarantined = 1;
            r->debt = ID_ADMIN_DEBT; reply->outcome = IDP_TOMBSTONED; break;
        default: ++protocol_errors; reply->outcome = IDP_UNKNOWN; return;
        }
        reply->retained_debt = r->debt;
    }
    switch (fault) {
    case MODEL_UNKNOWN_AFTER_COMMIT: reply->outcome = IDP_UNKNOWN; break;
    case MODEL_WRONG_SEQUENCE: ++reply->sequence; break;
    case MODEL_WRONG_PAIR: ++reply->request.uid; break;
    case MODEL_WRONG_INSTALLATION: reply->request.installation_id[0] ^= 1; break;
    case MODEL_WRONG_NAMESPACE: ++reply->request.userns_inode; break;
    case MODEL_WRONG_HOST: reply->request.host_id[0] ^= 1; break;
    case MODEL_WRONG_TICKET: ++reply->ticket.fence; break;
    case MODEL_WRONG_ISSUER: reply->ticket.issuer_id[0] ^= 1; break;
    case MODEL_ZERO_TICKET: memset(&reply->ticket, 0, sizeof reply->ticket); break;
    case MODEL_BAD_DEBT: reply->retained_debt = UINT32_MAX; break;
    case MODEL_MISSING_COMPONENT: reply->touched_components = ID_DEBT_UID; break;
    case MODEL_DENIAL_WITH_EFFECT:
        reply->outcome = IDP_POLICY_MISSING;
        reply->touched_components = ID_DEBT_UID;
        reply->retained_debt = ID_ADMIN_DEBT;
        break;
    case MODEL_UNEXPECTED_OUTCOME: reply->outcome = IDP_TOMBSTONED; break;
    case MODEL_DUPLICATE_TICKET: if (used > 1) reply->ticket = records[0].ticket; break;
    default: break;
    }
}

void id_provider_step(const struct id_provider_call *call,
                      struct id_provider_reply *reply) {
    model_step(call, reply);
    printf("{\"kind\":\"provider_model\",\"operation\":%u,\"sequence\":%llu,"
           "\"transaction\":%llu,\"outcome\":%u,\"touched\":%u,\"debt\":%u}\n",
           call ? (unsigned)call->operation : 0,
           (unsigned long long)(call ? call->sequence : 0),
           (unsigned long long)reply->ticket.transaction,
           (unsigned)reply->outcome, reply->touched_components, reply->retained_debt);
}
