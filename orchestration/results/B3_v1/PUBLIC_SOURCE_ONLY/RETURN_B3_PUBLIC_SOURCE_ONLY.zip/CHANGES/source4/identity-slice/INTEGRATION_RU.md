# B3 v1: точный additive integration contract

## Граница этого результата

Все новые implementation/document/test файлы находятся в `source4/identity-slice/`.
Существующие `BASE_MAIN`, `main-h-birth-core.inc`, `intake-slice`, `deps`,
configuration ABI и публичные маршруты не изменяются. Срез не подключён к Main;
нет исполняемого privileged entry, H birth, положительного release, Node или
bundle execution. A2 остаётся PARTIAL observation capsule.

Основной input pin:
`045424a2528510c317f911cc3a7d3b51bac36f12`, каталог
`orchestration/stages/B3_identity_v1/input/`. Следующие выводы сделаны после
чтения закреплённых исходников. SHA относится к точным входным bytes, не к
будущей адаптации.

| Вход и SHA-256 | Точное место | Что источник действительно предоставляет |
|---|---|---|
| `source4/BASE_MAIN/verification-linux-service-configuration.h`, `b6a7ffc3c804e62b3dd3268701313713b65a9e16fce1718ff440c6fc754287ec` | `kv_linux_service_configuration`, ABI1, 1152 bytes | History scope, authorized UID/GID, time policy и graph pins. H pair, provisioning authority, generation и recovery actor отсутствуют. |
| `source4/BASE_MAIN/verification-linux-service-configuration.c`, `a48818d7af0c8dc601a1942c4c5d85de406a48fbe4fe357c045dd8f84a264b2e` | `decode`, `kv_linux_service_configuration_load` | Проверка формата, root-owned protected administrative DATA, authorized IDs, inclusive ledger limits. Metadata и DATA hashes не являются резервированием principal. |
| `source4/BASE_MAIN/verification-linux-service-main.c`, `579eebd839c026d19daee3c7619a7ff260dab9212a79910f2d3a51fdbb59e157` | `singleton`, `named_lock`, `main` | Один retained `flock` на тот же именованный inode между cooperative Main; этот lease не координирует внешних администраторов и не сохраняет H identity после потери последнего FD. |
| `source4/BASE_MAIN/verification-linux-uid-history.h`, `724dbe32e56de11db5201c0a9d886f0671ef88ac31f2abf34ce198559617f62e` | administrative premise; `kv_linux_uid_reserve`, `kv_linux_uid_record_closed`, `kv_linux_uid_close` | Необратимая история allocations внутри отдельного ledger range; reservation диапазона и конфликтов лежит на администраторе. `close` не записывает CLOSED. Это не allocator для H, который обязан быть вне всего диапазона. |
| `source4/main-h-birth-core.inc`, `6f7855f99258ac702ba6e12e2759a0609e646b190ae0f7474d01faf94478dc7f` | `mh_identity_policy`, `mh_spawn_original`, `mh_progress_original`, `mh_finish_original` | Numeric exclusions; atomic child custody; отдельные reap/EOF observations; `finish` закрывает собственные handles. Administrative reservation и residual identity clearance не предоставляются. |
| `source4/intake-slice/main-intake.inc`, `17f69092381bedbd010e8da49fbd3f157fd15412fd765e99d15a444d1eeaf4ce` | `mi_main_capture`, `mi_receive_original`, `mi_core_offer_original` | Original Main/V observations и effective bounds; B1_READY сохраняет все роли, затем offer terminates unavailable. Присваивания `mh_actual_offer` нет. |
| `source4/intake-slice/private-main-intake.c`, `3da9173e08d53ddc8351834eaa999a724514b36e5e33fcdd6e013dee8c680c76` | `mi_private_main_source_only` после config load и до `mi_main_capture` | Проверенная local config и sole original listener доступны в одном fixed translation unit. Derivative не имеет executable `main` и не создаёт H. |
| `source4/BASE_MAIN/verification-linux-service-runtime-front.c`, `18e71a28bdbbd5abc746999038728c4cab10e7038e15f2f0263178715de221fe` | `kv_linux_runtime_front_open/poll/close`, private slots | Старый front имеет собственную listener/custody модель. Его lease и cleanup не импортируются как H-reservation authority. |
| `source4/BASE_MAIN/verification-linux-service-key-process.c`, `7e44cca2555355794043503cb37cdacb94b88f44534eaae0be05999443e7c505` | `child_drop`, `maps`, `kv_linux_key_close` | Другой lifecycle и namespace/delegation путь. Он не заменяет новый NNP1 H entry или административное H provisioning. |

## Точки будущего подключения

Это обязательства оркестратора для отдельного изменения; они не являются
скрытыми изменениями существующего ABI или заявлением о готовом bootstrap.

1. **До intake admission / H offer.** После проверки установленной
   administrative configuration и actual Main namespace trusted Main должен
   получить отдельную administratively provisioned pair policy из заранее
   выбранного fixed trust source. ABI1 не содержит этого объекта. Нельзя брать
   HUID/HGID из request/argv/environment, выделять free UID сканированием или
   принимать `reserved=true`.
2. **При reservation.** Передать только immutable exclusion scope этой actual
   config: authorized UID/GID, inclusive ledger bounds, host/installation IDs;
   original held user namespace принадлежит Main-native custody. Authority
   должна независимо авторизовать Main, связать актуальный host/namespace и
   выдать reservation обоих компонентов одной транзакцией. 16-byte labels,
   `(dev,ino)` и PID не заменяют provenance.
3. **До любого H birth.** Reservation должна быть активна; exact pair и
   generation bound к exact native attempt; durable arm должен завершиться
   до clone. Необратимый arm остаётся возможным birth obligation даже при
   crash между clone и local record. Отказ/unknown запрещает создание H.
4. **При полном offer в будущем.** Pair копируется только из настоящего
   reservation handle в `mh_slot.policy` той же actual offer. Все остальные
   B1/B3/B4/B5 prerequisites проверяются отдельно. B3 v1 не присваивает
   `mh_actual_offer`, не вызывает `mh_spawn_original` и не ослабляет
   `mi_core_offer_original`.
5. **Сразу после clone.** В owner custody без промежуточных fallible действий
   должны сохраниться actual clone pidfd/child relation. Administrative
   recovery actor либо уже держит custody, либо durable arm означает
   indefinite quarantine до независимо доказанной closure. Ни отсутствие
   local child record, ни `pidfd_open(old_pid)` не восстанавливают ownership.
6. **При lifecycle progress.** Только genuine same Main/slot observations
   могут закрывать соответствующие birth/reap/pipe obligations. Diagnostic
   mirror `slot.h_pidfd`, output JSON, `mh_raw.cleanup_observed` без источника,
   `POLLHUP`, `ESRCH` или exit status не являются aggregate closure proof.
7. **После C и при shutdown.** C запрещает новую attempt work и не освобождает
   pair. Core после C прекращает обычные wait/drain шаги и сохраняет
   unconfirmed custody. Нужен отдельно утверждённый recovery actor/protocol;
   этот срез не запускает ещё один cleanup loop с новой C. Не подтверждённые
   административные obligations сохраняются дольше C и дольше процесса Main.
8. **После `mh_finish_original`.** Core завершает собственную handle custody,
   но не проверяет все descendants, owned filesystem objects, supplementary
   group membership, namespace mappings или внешние пользователи IDs.
   В B3 v1 `id_try_retire` допускает только unarmed попытку либо
   native-подтверждённый failed birth без ребёнка. Born/unknown попытка
   остаётся retained даже после reap и обоих EOF: полного tree proof нет.
   Допустимый no-birth retirement дополнительно требует exact durable provider
   tombstone; pair
   остаётся навсегда зарезервированной, а административные residual obligations
   переходят/остаются у provider. Reclamation не реализован. Для любого будущего
   возврата IDs потребуются отдельная native/policy проверенная полная residual
   closure и новое утверждённое правило. Retirement не означает возврат IDs в
   свободный системный pool.

## Existing core не разрешает прямую положительную интеграцию

В закреплённом core `mh_child_hold` не вызывает `mh_child_drop_checked`; held
child остаётся root0. `mh_progress_original` принимает reap UID0 именно для
этого пути. Попытка просто заполнить `policy.h_uid/h_gid` не делает этот путь
полноценным H runtime и не изменяет проверку `si_uid`. Identity adapter не
исправляет и не расширяет этот core. Переход на H credentials, protected
loader, original-parent/new-entry verification и runtimeFS delegation требуют
отдельно рассмотренного source change и тестов.

`NNP1` не восстанавливает старый NNP0/SUID runtime. Dedicated HUID не даёт
доступа к V0700 project или root0600 secrets. Ни `chown`, ни ACL, ни новые
capabilities, ни host accounts в B3 v1 не добавляются. Missing protected
loader/runtime graph (исторический blocker B3), новый NNP1 entry (B4), event
loop/descriptor inventory (B5) и runtimeFS delegation сохраняют BLOCKED.

## Граница доверия и проверка будущего provider

Существующий singleton допускается только как local fixed-Main serialization
premise. Scope административной authority шире: одна host identity domain,
все installation generations, все Main, локальные и удалённые администраторы,
NSS/directory mappings, service managers и subordinate UID/GID mappings. Pair
arbitration обязана запрещать конфликт по любому одному компоненту, даже если
второй компонент иной. UID и GID являются разными kernel namespaces: равенство
чисел HUID==HGID допустимо только при независимом полном резервировании обеих
ролей.

Нельзя объявить provider установленным только по root owner файла, подписи
DATA без текущего verifier, inode, nonce, boot ID или exact hash. Требуются
утверждённый provisioning trust root и protocol semantics, гарантирующие
эксклюзивность и crash fencing. В supplied input их нет; текущий production
provider возвращает typed policy blocker. Ни compiler success, ни модель
provider, ни source review этого внешнего свойства не доказывают.

## Реально поставленный adapter

`main-identity-adapter.inc` включается после неизменных core/intake только в
отдельном compile/test translation unit. Он **не включён** в существующий
`private-main-intake.c`. Private `id_main_capture_configuration_original` один раз копирует
identity-relevant поля actual config в собственную капсулу; future call anchor
— сразу после успешного `kv_linux_service_configuration_load`, до intake.
Ноль здесь означает только DATA capture. `id_main_reserve_original` допускает
одну попытку от того же Main на `MI_B1_READY`, требует тот же config object и
точное равенство frozen authorized/time/history/host/install fields, сверяет
захваченную `mi_admin`, повторно вызывает `mi_peer_current`. Request получает
exclusions и labels из frozen capsule, original userns из `mi_state`,
candidate pair как DATA. Candidate должен поступать из будущего trusted provisioning source;
текущий ABI1 такого источника не предоставляет.

В supplied production path `id_acquire` возвращает `ID_POLICY_BLOCKED`. Если
явная test-only модель provider выдаст `ID_OK` или retained/partial handle,
adapter сохраняет handle отдельно от intake, вызывает
`id_retain(..., ID_REASON_RECOVERY_REQUIRED)` и терминально отменяет B1. Даже
model success преобразуется в `ID_RETAINED`; противоречивый `ID_OK` без handle
преобразуется в `ID_BAD_STATE`. Оригинальный acquisition status сохраняется в
receipt. `ID_OK` наружу из gate не возвращается.
Это проверяет границу: identity reservation не достраивает full offer и не
разрешает H birth. Namespace duplicate принадлежит identity slice, поэтому
закрытие intake originals не стирает оставшуюся custody. Private `id_main_raw`
раздельно записывает capture/attempt, acquisition status, retention status,
intake cancel rc/errno и sticky intake close fault. Ошибки retention/cancel
не скрываются под успешным status и не уничтожают retained handle. Даже если
acquire вернулся после W/C или после stop, adapter не инициирует новую work: он
только сохраняет effects и отменяет B1. Fixed trusted Main/config provenance
остаётся обязательной предпосылкой; address equality и frozen DATA её не
доказывают.

Adapter не вызывает `id_arm_birth`, `id_observe_original` или `id_try_retire`:
для настоящего H здесь нет producer, child или closure. Внутренний факт API
испытывается отдельно только моделью. Будущая положительная интеграция должна
связать exact reservation с actual core slot до arm и считывать факты до
`mh_finish_original`, пока private core custody ещё существует. Она требует
нового source review; копирование diagnostic snapshot вместо такой связи
запрещено.

Identity API не принимает S/W/C, не читает clock и не квалифицирует deadlines.
`ID_REASON_C_EXPIRED` — trusted observer event, который включает sticky latch
и reason mask; его tests не доказывают время C. Будущий Main обязан делать
свои before/after checks original bounds вокруг provider operations. Новый
consumer повторно сравнивает held/current userns перед ARM/CHECK/RETIRE и
проверяет local ticket monotonicity. Эти проверки не заменяют global durable
fencing или arbitration внешних kernel IDs, на которые могут отображаться
разные user namespaces. Инициализация output handle `NULL` обязательна;
непустой output сохраняется и отвергается без новых effects.

`id_provider_step` вызывается синхронно; в v1 нет механизма остановки зависшего
реального backend или hard latency guarantee. Поставленный unavailable
provider возвращается сразу. Для настоящего provisioning нужен bounded /
nonblocking provider state machine в B5 Main owner loop, original deadline
checks до/после каждого шага без renewal и отдельная physical проверка hung
I/O/crash. Этот blocker документирован; fake timeout-success не добавлен.
