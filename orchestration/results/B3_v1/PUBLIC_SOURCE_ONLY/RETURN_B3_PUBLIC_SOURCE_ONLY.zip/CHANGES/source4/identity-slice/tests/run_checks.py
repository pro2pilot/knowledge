#!/usr/bin/env python3
"""B3 source/compiler/model checks. No Main/H/Node or admin provisioning run.

Each output directory must be new. Raw stdout/stderr/rc, exact argv, all input
hashes and frozen source bytes survive failures. Physical ordinary namespace
denial test is separate from the namespace model and can remain NOT_RUN.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

INPUT_COMMIT = "045424a2528510c317f911cc3a7d3b51bac36f12"
MANIFEST_SHA256 = "0e863ed2034050158fac6d29a8d51bc6e4aec01165f3f2e8962f9448c4ecd5af"
PREFIX = "source4/identity-slice/"
MEMORY_SYMBOLS = {
    "__errno_location", "__stack_chk_fail", "__assert_fail", "__printf_chk",
    "__fprintf_chk", "__snprintf_chk", "__memcpy_chk", "__memset_chk",
    "printf", "fprintf", "snprintf", "puts", "putchar", "putc", "fputs",
    "memset", "memcpy", "memcmp", "memmove", "strcmp", "strncmp", "strlen",
    "strchr", "strstr", "stdout", "stderr", "abort", "exit",
    "__libc_start_main", "__cxa_finalize", "__gmon_start__",
    "_ITM_deregisterTMCloneTable", "_ITM_registerTMCloneTable",
}
ORDINARY_READ_SYMBOLS = MEMORY_SYMBOLS | {"open", "fcntl", "fstat", "ioctl", "close", "getpid"}
WRAP = ["-Wl,--wrap=" + s for s in ("open", "fcntl", "fstat", "ioctl", "close", "getpid")]


def pin(data: bytes) -> dict:
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--compiler", default="gcc")
    p.add_argument("--require-ordinary-namespace", action="store_true",
                   help="For the proposed isolated Actions check: fail if ordinary namespace probe cannot run")
    args = p.parse_args()
    source = Path(__file__).resolve().parents[3]
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=False)
    frozen = output / "frozen"
    frozen.mkdir()
    build = output / "build"
    build.mkdir()
    (output / "compiler-tmp").mkdir()
    env = {"PATH": os.environ.get("PATH", os.defpath), "LANG": "C", "LC_ALL": "C",
           "TMPDIR": str(output / "compiler-tmp")}
    report = {
        "schema": "b3-identity-source-model.v1", "input_commit": INPUT_COMMIT,
        "classification": "SOURCE_COMPILER_MODEL_ONLY", "result": "IN_PROGRESS",
        "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "source_root": str(source), "cwd": str(frozen),
        "python": sys.version, "compiler": args.compiler,
        "platform": {"system": platform.system(), "release": platform.release(), "machine": platform.machine()},
        "runner_euid": os.geteuid() if hasattr(os, "geteuid") else None,
        "native_Main_H": "NOT_RUN", "Node_bundle": "NOT_RUN",
        "host_policy_accounts_caps_ACL_changes": "NONE",
        "administrative_reservation_proof": "NOT_RUN_POLICY_BLOCKED",
        "ordinary_namespace": "NOT_RUN", "actions": [], "checks": [],
        "base_pins": {}, "addition_pins": {},
    }

    def persist():
        (output / "RESULT.json").write_text(json.dumps(report, indent=2) + "\n")

    def run(label, argv, expected=(0,), timeout=30):
        index = len(report["actions"])
        name = f"{index:02d}-{label}"
        action = {"label": label, "argv": list(argv), "cwd": str(frozen),
                  "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
                  "timeout_seconds": timeout, "expected_rc": list(expected),
                  "stdout": name + ".stdout.txt", "stderr": name + ".stderr.txt"}
        start = time.monotonic_ns()
        try:
            r = subprocess.run(argv, cwd=frozen, env=env, capture_output=True, timeout=timeout, check=False)
            rc, out, err = r.returncode, r.stdout, r.stderr
        except subprocess.TimeoutExpired as e:
            rc, out, err = 124, e.stdout or b"", e.stderr or b""
            action["timeout"] = True
        except OSError as e:
            rc, out, err = 125, b"", str(e).encode()
            action["invocation_error"] = type(e).__name__
        action.update(rc=rc, expected=rc in expected, duration_ns=time.monotonic_ns() - start)
        (output / action["stdout"]).write_bytes(out)
        (output / action["stderr"]).write_bytes(err)
        report["actions"].append(action)
        persist()
        return rc, out, err

    def check(label, ok, details=None):
        report["checks"].append({"label": label, "pass": bool(ok), "details": details})
        persist()
        if not ok:
            raise RuntimeError(label)

    def symbols(label, file, allowed, require_no_model=False):
        rc, data, _ = run(label, [nm, "-u", file])
        names = {line.split()[-1].split("@")[0] for line in data.decode().splitlines() if line.split()}
        check(label + "-allowlist", rc == 0 and not (names - allowed),
              {"symbols": sorted(names), "unexpected": sorted(names - allowed)})
        if require_no_model:
            rc, all_data, _ = run(label + "-all", [nm, "-a", file])
            found = [s for s in ("id_model_reset", "__wrap_open", "model_reset") if s in all_data.decode()]
            check(label + "-no-test-hooks", rc == 0 and not found, found)

    def compile_c(label, files, target, extra=(), link=False):
        argv = [compiler, *flags, *extra]
        if not link:
            argv += ["-c"]
        argv += [*files, "-o", "../build/" + target]
        rc, _, _ = run(label, argv)
        check(label, rc == 0)

    def parse_summary(label, data):
        rows = [json.loads(line) for line in data.decode().splitlines() if line.strip()]
        summaries = [x for x in rows if x.get("kind") == "summary"]
        check(label + "-summary-present", len(summaries) == 1)
        return summaries[0], rows

    try:
        manifest_data = (source / "MANIFEST.json").read_bytes()
        check("trusted-input-manifest", hashlib.sha256(manifest_data).hexdigest() == MANIFEST_SHA256)
        manifest = json.loads(manifest_data)
        check("input-count", len(manifest["files"]) == 59)
        for rel, expected in manifest["files"].items():
            path = source / rel
            check("base:" + rel, path.is_file() and not path.is_symlink() and pin(path.read_bytes()) == expected)
            data = path.read_bytes()
            report["base_pins"][rel] = pin(data)
            target = frozen / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        (frozen / "MANIFEST.json").write_bytes(manifest_data)
        for path in sorted((source / PREFIX).rglob("*")):
            if path.is_file() and "__pycache__" not in path.parts:
                rel = path.relative_to(source).as_posix()
                check("addition-regular:" + rel, not path.is_symlink())
                data = path.read_bytes()
                report["addition_pins"][rel] = pin(data)
                dest = frozen / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(data)
        compiler = shutil.which(args.compiler)
        nm = shutil.which("nm")
        check("compiler-and-nm", bool(compiler and nm))
        check("linux-compile-target", platform.system() == "Linux" and platform.machine() in ("x86_64", "amd64"))
        run("compiler-version", [compiler, "--version"])
        run("nm-version", [nm, "--version"])
        flags = ["-std=c11", "-O2", "-Wall", "-Wextra", "-Werror", "-Wpedantic", "-fno-common", "-fno-builtin"]
        includes = ["-I", "source4/BASE_MAIN", "-I", "deps"]
        compile_c("native-identity-compile", [PREFIX + "identity.c"], "identity.o")
        compile_c("native-unavailable-provider-compile", [PREFIX + "identity_provider_unavailable.c"], "provider.o")
        compile_c("public-denial-compile", [PREFIX + "tests/test_public_denial.c"], "public.o")
        rc, _, _ = run("public-denial-link", [compiler, "../build/identity.o", "../build/provider.o", "../build/public.o", "-o", "../build/public-denial"])
        check("public-denial-link", rc == 0)
        symbols("public-symbols", "../build/public-denial", ORDINARY_READ_SYMBOLS, True)
        rc, data, _ = run("ordinary-public-denial", ["../build/public-denial"], expected=(0, 77))
        summary, _ = parse_summary("ordinary-public-denial", data)
        if rc == 77:
            report["ordinary_namespace"] = "NOT_RUN_ENV_GAP"
            report["ordinary_namespace_detail"] = summary
            check("ordinary-namespace-required", not args.require_ordinary_namespace, summary)
        else:
            check("ordinary-public-denial", rc == 0 and summary.get("administrative_reservations") == 0 and summary.get("policy_blocked", 0) > 0)
            report["ordinary_namespace"] = "PASS_ORDINARY_READ_AND_DENIAL_ONLY"
        model_flags = ["-DIDENTITY_MODEL_TEST_ONLY", "-DB3_NAMESPACE_MODEL_ONLY"]
        compile_c("model-identity-compile", [PREFIX + "identity.c"], "identity-model.o", model_flags)
        compile_c("model-provider-compile", [PREFIX + "tests/model_provider.c"], "provider-model.o", model_flags)
        compile_c("model-cases-compile", [PREFIX + "tests/test_identity_model.c"], "cases-model.o", model_flags)
        compile_c("namespace-model-compile", [PREFIX + "tests/namespace_model.c"], "namespace-model.o", ["-DB3_NAMESPACE_MODEL_ONLY"])
        objects = ["../build/" + f for f in ("identity-model.o", "provider-model.o", "cases-model.o", "namespace-model.o")]
        rc, _, _ = run("model-link", [compiler, *objects, *WRAP, "-o", "../build/identity-model"])
        check("model-link", rc == 0)
        symbols("model-symbols", "../build/identity-model", MEMORY_SYMBOLS)
        rc, data, _ = run("model-cases", ["../build/identity-model"])
        summary, rows = parse_summary("model-cases", data)
        cases = [x for x in rows if x.get("kind") == "case"]
        report["identity_model_summary"] = summary
        report["identity_model_cases"] = cases
        check("model-cases", rc == 0 and summary.get("failed") == 0 and summary.get("passed", 0) >= 40 and
              len({x["name"] for x in cases}) == len(cases), summary)
        compile_c("denial-model-compile", [PREFIX + "tests/test_public_denial.c"], "public-model.o", ["-DB3_NAMESPACE_MODEL_ONLY"])
        rc, _, _ = run("denial-model-link", [compiler, "../build/identity.o", "../build/provider.o", "../build/public-model.o", "../build/namespace-model.o", *WRAP, "-o", "../build/public-denial-model"])
        check("denial-model-link", rc == 0)
        symbols("denial-model-symbols", "../build/public-denial-model", MEMORY_SYMBOLS)
        rc, data, _ = run("denial-model-run", ["../build/public-denial-model"])
        summary, _ = parse_summary("denial-model-run", data)
        report["production_provider_model_summary"] = summary
        check("production-provider-denies", rc == 0 and summary.get("administrative_reservations") == 0 and summary.get("policy_blocked", 0) > 0)
        compile_c("adapter-native-compile-only", [PREFIX + "tests/test_adapter_compile.c"], "adapter-native.o", includes + ["-Wno-unused-function"])
        rc, native_symbols, _ = run("adapter-native-symbols", [nm, "-a", "../build/adapter-native.o"])
        check("adapter-native-no-entry-main", rc == 0 and not any(line.split()[-1:] == ["main"] for line in native_symbols.decode().splitlines()))
        report["adapter_native_object_execution"] = "NOT_RUN"
        compile_c("adapter-model-build", [PREFIX + "tests/test_adapter_model.c"], "adapter-model", includes + ["-DIDENTITY_MODEL_TEST_ONLY"], link=True)
        symbols("adapter-model-symbols", "../build/adapter-model", MEMORY_SYMBOLS)
        rc, data, _ = run("adapter-model-cases", ["../build/adapter-model"])
        summary, rows = parse_summary("adapter-model", data)
        report["adapter_model_summary"] = summary
        report["adapter_model_cases"] = [x for x in rows if x.get("kind") == "case"]
        check("adapter-model-cases", rc == 0 and summary.get("failed") == 0 and summary.get("passed", 0) >= 9, summary)
        rc, _, _ = run("negative-model-provider-in-production", [compiler, *flags, "-fsyntax-only", PREFIX + "tests/model_provider.c"], expected=(1,))
        check("test-provider-not-ordinary-build", rc == 1)
        rc, _, _ = run("negative-production-provider-in-model", [compiler, *flags, "-DIDENTITY_MODEL_TEST_ONLY", "-fsyntax-only", PREFIX + "identity_provider_unavailable.c"], expected=(1,))
        check("production-provider-not-positive-model", rc == 1)
        opaque = frozen / "opaque-negative.c"
        opaque.write_text('#include "source4/identity-slice/identity.h"\nid_reservation forbidden_public_constructor;\n')
        rc, _, _ = run("negative-opaque-constructor", [compiler, *flags, "-fsyntax-only", "opaque-negative.c"], expected=(1,))
        check("opaque-handle-no-data-constructor", rc == 1)
        unchanged = all(pin((source / rel).read_bytes()) == expected for rel, expected in
                        {**report["base_pins"], **report["addition_pins"]}.items())
        check("source-stable-during-run", unchanged)
        report["result"] = "PASS_SOURCE_MODEL_ONLY_WITH_ENV_BLOCKER" if report["ordinary_namespace"] == "NOT_RUN_ENV_GAP" else "PASS_SOURCE_MODEL_AND_ORDINARY_DENIAL_ONLY"
        return_code = 0
    except (OSError, ValueError, RuntimeError) as e:
        report["result"] = "FAIL"
        report["reason"] = str(e)
        return_code = 1
    report["finished_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
    report["build_pins"] = {p.name: pin(p.read_bytes()) for p in sorted(build.iterdir()) if p.is_file()}
    persist()
    print(json.dumps({"result": report["result"], "reason": report.get("reason"),
                      "ordinary_namespace": report["ordinary_namespace"],
                      "identity_model": report.get("identity_model_summary"),
                      "adapter_model": report.get("adapter_model_summary")}, ensure_ascii=False))
    return return_code


if __name__ == "__main__":
    raise SystemExit(main())
