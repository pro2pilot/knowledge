#define _GNU_SOURCE
#if !defined(IDENTITY_MODEL_TEST_ONLY)
#error "All positive acquisitions in this file are fictitious protocol MODEL ONLY"
#endif
#include "../identity_internal.h"
#include "model_provider.h"
#if defined(B3_NAMESPACE_MODEL_ONLY)
#include "namespace_model.h"
#endif
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

static int original_ns = -1;
static unsigned passed, failed;
#define REQUIRE(condition) do { if (!(condition)) { \
    printf("{\"kind\":\"assertion\",\"line\":%u,\"expression\":\"%s\"}\n", \
           (unsigned)__LINE__, #condition); return 0; } } while (0)

static struct id_request request(void) {
    struct id_request r;
    memset(&r, 0, sizeof r);
    r.authorized_uid = 1000; r.authorized_gid = 1001;
    r.ledger_first = 1000000000; r.ledger_last = 1800000000;
    r.candidate_uid = 2000000000; r.candidate_gid = 2000000001;
    memset(r.host_id, 0x11, sizeof r.host_id);
    memset(r.installation_id, 0x22, sizeof r.installation_id);
    r.original_userns_fd = original_ns;
    return r;
}
static int snapshot(id_reservation *h, struct id_snapshot *s) {
    return id_get_snapshot(h, s) == ID_OK;
}
static int has_pair_debt(id_reservation *h) {
    struct id_snapshot s;
    return snapshot(h, &s) && (s.retained_debt & (ID_DEBT_UID | ID_DEBT_GID)) ==
        (ID_DEBT_UID | ID_DEBT_GID);
}
static int acquisition(id_reservation **h) {
    struct id_request r = request();
    return id_acquire(&r, h) == ID_OK && *h;
}

static int numeric_exclusions(void) {
    const uint32_t rejected[] = {0, UINT32_MAX, 1000, 1001, 1000000000,
                                1400000000, 1800000000};
    for (unsigned component = 0; component < 2; ++component) {
        for (unsigned i = 0; i < sizeof rejected / sizeof rejected[0]; ++i) {
            struct id_request r = request(); id_reservation *h = NULL;
            if (component) r.candidate_gid = rejected[i]; else r.candidate_uid = rejected[i];
            REQUIRE(id_acquire(&r, &h) == ID_INVALID && !h);
        }
    }
    struct id_request r = request(); id_reservation *h = NULL;
    r.ledger_first = 8; r.ledger_last = 7;
    REQUIRE(id_acquire(&r, &h) == ID_INVALID && !h);
    r = request(); r.ledger_last = UINT32_MAX;
    REQUIRE(id_acquire(&r, &h) == ID_INVALID && !h);
    r = request(); r.authorized_uid = 0;
    REQUIRE(id_acquire(&r, &h) == ID_INVALID && !h);
    REQUIRE(model_calls(IDP_ALLOCATE) == 0);
    return 1;
}
static int policy_data_not_authority(void) {
    struct id_request r = request(); id_reservation *h = NULL;
    model_fault_once(IDP_ALLOCATE, MODEL_POLICY_MISSING);
    REQUIRE(id_acquire(&r, &h) == ID_POLICY_BLOCKED && !h);
    REQUIRE(model_calls(IDP_ACQUIRE_PAIR) == 0);
    REQUIRE(id_arm_birth(h) != ID_OK);
    REQUIRE(id_acquire(NULL, &h) == ID_INVALID);
    REQUIRE(id_acquire(&r, NULL) == ID_INVALID);
    return 1;
}
static int namespace_must_be_held_object(void) {
    struct id_request r = request(); id_reservation *h = NULL;
    int fd = open("/dev/null", O_RDONLY | O_CLOEXEC);
    REQUIRE(fd >= 0); r.original_userns_fd = fd;
    enum id_status s = id_acquire(&r, &h); close(fd);
    REQUIRE(s == ID_INVALID && !h);
    REQUIRE(model_calls(IDP_ALLOCATE) == 0);
    return 1;
}
static int request_and_snapshot_are_copies(void) {
    struct id_request r = request(); id_reservation *h = NULL; struct id_snapshot s;
    int borrowed = fcntl(original_ns, F_DUPFD_CLOEXEC, 32);
    REQUIRE(borrowed >= 0); r.original_userns_fd = borrowed;
    REQUIRE(id_acquire(&r, &h) == ID_OK && h);
    REQUIRE(close(borrowed) == 0);
    r.candidate_uid = 1000; r.ledger_first = 1; r.ledger_last = UINT32_MAX;
    memset(r.host_id, 0, sizeof r.host_id); r.original_userns_fd = -1;
    REQUIRE(snapshot(h, &s));
    s.uid = 0; s.birth_armed = 1; s.phase = ID_PHASE_RETIRED; s.retained_debt = 0;
    REQUIRE(id_poll_authority(h) == ID_OK);
    REQUIRE(snapshot(h, &s) && s.uid == 2000000000 && !s.birth_armed && s.phase == ID_PHASE_RESERVED);
    REQUIRE(has_pair_debt(h)); return 1;
}
static int independent_component_exclusion(void) {
    id_reservation *a = NULL, *b = NULL, *c = NULL, *d = NULL; struct id_request r = request();
    REQUIRE(acquisition(&a));
    r.installation_id[0] ^= 3; ++r.candidate_gid;
    REQUIRE(id_acquire(&r, &b) != ID_OK);
    if (b) REQUIRE(id_arm_birth(b) != ID_OK && has_pair_debt(b));
    r = request(); r.installation_id[0] ^= 4; ++r.candidate_uid;
    REQUIRE(id_acquire(&r, &c) != ID_OK);
    if (c) REQUIRE(id_arm_birth(c) != ID_OK);
    r = request(); r.installation_id[0] ^= 5; r.candidate_uid += 10; r.candidate_gid += 10;
    REQUIRE(id_acquire(&r, &d) == ID_OK);
    REQUIRE(id_poll_authority(a) == ID_OK && id_poll_authority(d) == ID_OK);
    return 1;
}
static int broken_provider_overlap(void) {
    id_reservation *a = NULL, *b = NULL; struct id_request r = request();
    REQUIRE(acquisition(&a)); r.candidate_gid += 10; r.installation_id[0] ^= 3;
    model_fault_once(IDP_ACQUIRE_PAIR, MODEL_ALLOW_OVERLAP);
    REQUIRE(id_acquire(&r, &b) != ID_OK && b && has_pair_debt(b));
    REQUIRE(id_arm_birth(b) != ID_OK && id_poll_authority(a) == ID_OK); return 1;
}
static int partial_pair(enum model_fault fault) {
    id_reservation *h = NULL; struct id_request r = request();
    model_fault_once(IDP_ACQUIRE_PAIR, fault);
    REQUIRE(id_acquire(&r, &h) != ID_OK && h && has_pair_debt(h));
    REQUIRE(id_arm_birth(h) != ID_OK && id_try_retire(h) != ID_RETIRED);
    REQUIRE(model_pair_excluded(r.candidate_uid, r.candidate_gid));
    id_reservation *other = NULL; r.installation_id[0] ^= 6;
    REQUIRE(id_acquire(&r, &other) != ID_OK);
    return 1;
}
static int uid_only_partial(void) { return partial_pair(MODEL_PARTIAL_UID); }
static int gid_only_partial(void) { return partial_pair(MODEL_PARTIAL_GID); }
static int lost_pair_ack(void) { return partial_pair(MODEL_UNKNOWN_AFTER_COMMIT); }

static int mismatched_reply(enum model_fault fault) {
    id_reservation *h = NULL; struct id_request r = request();
    model_fault_once(IDP_ACQUIRE_PAIR, fault);
    REQUIRE(id_acquire(&r, &h) != ID_OK && h && has_pair_debt(h));
    REQUIRE(id_arm_birth(h) != ID_OK && id_try_retire(h) != ID_RETIRED);
    REQUIRE(model_pair_excluded(r.candidate_uid, r.candidate_gid));
    return 1;
}
static int wrong_sequence(void) { return mismatched_reply(MODEL_WRONG_SEQUENCE); }
static int wrong_pair(void) { return mismatched_reply(MODEL_WRONG_PAIR); }
static int wrong_installation(void) { return mismatched_reply(MODEL_WRONG_INSTALLATION); }
static int wrong_namespace(void) { return mismatched_reply(MODEL_WRONG_NAMESPACE); }
static int wrong_host(void) { return mismatched_reply(MODEL_WRONG_HOST); }
static int wrong_ticket(void) { return mismatched_reply(MODEL_WRONG_TICKET); }
static int wrong_issuer(void) { return mismatched_reply(MODEL_WRONG_ISSUER); }
static int unknown_debt_bits(void) { return mismatched_reply(MODEL_BAD_DEBT); }
static int missing_pair_component(void) { return mismatched_reply(MODEL_MISSING_COMPONENT); }
static int wrong_outcome(void) { return mismatched_reply(MODEL_UNEXPECTED_OUTCOME); }
static int denial_with_effect(void) {
    id_reservation *h = NULL; struct id_request r = request();
    model_fault_once(IDP_ALLOCATE, MODEL_DENIAL_WITH_EFFECT);
    REQUIRE(id_acquire(&r, &h) != ID_OK && h && has_pair_debt(h));
    REQUIRE(model_calls(IDP_ACQUIRE_PAIR) == 0 && id_arm_birth(h) != ID_OK);
    return 1;
}
static int unknown_allocate(void) {
    id_reservation *h = NULL; struct id_request r = request();
    model_fault_once(IDP_ALLOCATE, MODEL_UNKNOWN_AFTER_COMMIT);
    REQUIRE(id_acquire(&r, &h) != ID_OK && h && has_pair_debt(h));
    REQUIRE(model_calls(IDP_ACQUIRE_PAIR) == 0 && id_try_retire(h) != ID_RETIRED);
    return 1;
}
static int zero_ticket(void) {
    id_reservation *h = NULL; struct id_request r = request();
    model_fault_once(IDP_ALLOCATE, MODEL_ZERO_TICKET);
    REQUIRE(id_acquire(&r, &h) != ID_OK && h && has_pair_debt(h));
    REQUIRE(model_calls(IDP_ACQUIRE_PAIR) == 0); return 1;
}
static int duplicate_ticket(void) {
    id_reservation *a = NULL, *b = NULL; struct id_request r = request();
    REQUIRE(acquisition(&a)); r.candidate_uid += 10; r.candidate_gid += 10;
    model_fault_once(IDP_ALLOCATE, MODEL_DUPLICATE_TICKET);
    unsigned before = model_calls(IDP_ACQUIRE_PAIR);
    REQUIRE(id_acquire(&r, &b) != ID_OK && b && has_pair_debt(b));
    REQUIRE(model_calls(IDP_ACQUIRE_PAIR) == before);
    REQUIRE(id_poll_authority(a) == ID_OK); return 1;
}
static int arm_is_durable_one_shot(void) {
    id_reservation *h = NULL; struct id_snapshot s;
    REQUIRE(acquisition(&h)); REQUIRE(id_arm_birth(h) == ID_OK);
    REQUIRE(snapshot(h, &s) && s.birth_armed && s.birth_unknown && s.retained_debt == ID_ALL_DEBT);
    REQUIRE(model_record_armed(s.transaction));
    REQUIRE(id_arm_birth(h) != ID_OK && model_calls(IDP_ARM) == 1);
    REQUIRE(id_try_retire(h) != ID_RETIRED); return 1;
}
static int lost_arm_ack(void) {
    id_reservation *h = NULL; struct id_snapshot s;
    REQUIRE(acquisition(&h)); model_fault_once(IDP_ARM, MODEL_UNKNOWN_AFTER_COMMIT);
    REQUIRE(id_arm_birth(h) != ID_OK); REQUIRE(snapshot(h, &s) && s.birth_unknown);
    REQUIRE(model_record_armed(s.transaction)); REQUIRE(id_arm_birth(h) != ID_OK);
    REQUIRE(id_try_retire(h) != ID_RETIRED && has_pair_debt(h)); return 1;
}
static int stale_epoch_retains(void) {
    id_reservation *h = NULL, *other = NULL; struct id_request r = request();
    REQUIRE(acquisition(&h)); model_advance_epoch();
    REQUIRE(id_poll_authority(h) != ID_OK && id_arm_birth(h) != ID_OK);
    REQUIRE(id_try_retire(h) != ID_RETIRED && has_pair_debt(h));
    r.installation_id[0] ^= 7; REQUIRE(id_acquire(&r, &other) != ID_OK);
    return 1;
}
static int revoke_before_arm(void) {
    id_reservation *h = NULL; struct id_snapshot s;
    REQUIRE(acquisition(&h)); REQUIRE(snapshot(h, &s)); model_revoke(s.transaction);
    REQUIRE(id_arm_birth(h) == ID_REVOKED); REQUIRE(has_pair_debt(h));
    REQUIRE(id_try_retire(h) != ID_RETIRED); return 1;
}
static int revoke_after_arm(void) {
    id_reservation *h = NULL; struct id_snapshot s;
    REQUIRE(acquisition(&h)); REQUIRE(id_arm_birth(h) == ID_OK);
    REQUIRE(snapshot(h, &s)); model_revoke(s.transaction);
    REQUIRE(id_poll_authority(h) == ID_REVOKED);
    REQUIRE(id_observe_original(h, ID_FACT_CHILD_BORN) == ID_RETAINED);
    REQUIRE(id_try_retire(h) != ID_RETIRED && has_pair_debt(h));
    REQUIRE(model_pair_excluded(s.uid, s.gid)); return 1;
}
static int c_expiry_is_sticky(void) {
    id_reservation *h = NULL; struct id_snapshot s;
    REQUIRE(acquisition(&h)); REQUIRE(id_arm_birth(h) == ID_OK);
    REQUIRE(id_observe_original(h, ID_FACT_CHILD_BORN) == ID_OK);
    REQUIRE(id_retain(h, ID_REASON_C_EXPIRED) == ID_RETAINED);
    REQUIRE(id_observe_original(h, ID_FACT_DIRECT_CHILD_REAPED) == ID_RETAINED);
    REQUIRE(id_observe_original(h, ID_FACT_STDOUT_EOF) == ID_RETAINED);
    REQUIRE(id_observe_original(h, ID_FACT_STDERR_EOF) == ID_RETAINED);
    REQUIRE(snapshot(h, &s) && s.cleanup_deadline_expired);
    REQUIRE(s.retained_debt & ID_DEBT_CHILD_TREE);
    REQUIRE(id_poll_authority(h) != ID_OK && id_arm_birth(h) != ID_OK);
    REQUIRE(id_try_retire(h) != ID_RETIRED); return 1;
}
static int direct_reap_eof_not_tree(void) {
    id_reservation *h = NULL; struct id_snapshot s;
    REQUIRE(acquisition(&h)); REQUIRE(id_arm_birth(h) == ID_OK);
    REQUIRE(id_observe_original(h, ID_FACT_CHILD_BORN) == ID_OK);
    REQUIRE(id_observe_original(h, ID_FACT_DIRECT_CHILD_REAPED) == ID_OK);
    REQUIRE(id_try_retire(h) != ID_RETIRED);
    REQUIRE(id_observe_original(h, ID_FACT_STDOUT_EOF) == ID_RETAINED);
    REQUIRE(id_observe_original(h, ID_FACT_STDERR_EOF) == ID_RETAINED);
    REQUIRE(snapshot(h, &s) && (s.retained_debt & ID_DEBT_CHILD_TREE));
    REQUIRE((s.retained_debt & ID_ADMIN_DEBT) == ID_ADMIN_DEBT);
    REQUIRE(id_try_retire(h) != ID_RETIRED && model_calls(IDP_RETIRE) == 0);
    return 1;
}
static int restart_with_live_child(void) {
    id_reservation *h = NULL, *replacement = NULL; struct id_request r = request();
    REQUIRE(acquisition(&h)); REQUIRE(id_arm_birth(h) == ID_OK);
    REQUIRE(id_observe_original(h, ID_FACT_CHILD_BORN) == ID_OK);
    /* Crash is a model loss of the caller's reference, NOT a real Main/H run.
     * The provider's durable model record survives and new owner is fenced. */
    h = NULL; model_advance_epoch(); r.installation_id[0] ^= 8;
    REQUIRE(id_acquire(&r, &replacement) != ID_OK);
    REQUIRE(model_pair_excluded(r.candidate_uid, r.candidate_gid)); return 1;
}
static int cancel_before_arm(void) {
    id_reservation *h = NULL; REQUIRE(acquisition(&h));
    REQUIRE(id_retain(h, ID_REASON_CANCEL) == ID_RETAINED);
    REQUIRE(id_arm_birth(h) != ID_OK && model_calls(IDP_ARM) == 0);
    REQUIRE(has_pair_debt(h)); return 1;
}
static int permanent_tombstone_no_reuse(void) {
    id_reservation *h = NULL, *other = NULL; struct id_snapshot s; struct id_request r = request();
    REQUIRE(acquisition(&h)); REQUIRE(id_try_retire(h) == ID_RETIRED);
    REQUIRE(snapshot(h, &s) && s.pair_permanently_tombstoned && s.retained_debt == ID_ADMIN_DEBT);
    REQUIRE(model_record_tombstoned(s.transaction) && model_record_debt(s.transaction) == ID_ADMIN_DEBT);
    REQUIRE(id_arm_birth(h) != ID_OK && id_try_retire(h) == ID_RETIRED);
    REQUIRE(id_acquire(&r, &other) != ID_OK && model_pair_excluded(s.uid, s.gid));
    return 1;
}
static int known_no_birth_tombstone(void) {
    id_reservation *h = NULL; struct id_snapshot s;
    REQUIRE(acquisition(&h)); REQUIRE(id_arm_birth(h) == ID_OK);
    REQUIRE(id_observe_original(h, ID_FACT_BIRTH_FAILED_KNOWN) == ID_OK);
    REQUIRE(id_try_retire(h) == ID_RETIRED);
    REQUIRE(snapshot(h, &s) && s.pair_permanently_tombstoned && !s.birth_unknown);
    REQUIRE(model_pair_excluded(s.uid, s.gid)); return 1;
}
static int contradictory_fact_cannot_clear_debt(void) {
    id_reservation *h = NULL; REQUIRE(acquisition(&h)); REQUIRE(id_arm_birth(h) == ID_OK);
    REQUIRE(id_observe_original(h, ID_FACT_CHILD_BORN) == ID_OK);
    REQUIRE(id_observe_original(h, ID_FACT_BIRTH_FAILED_KNOWN) != ID_OK);
    REQUIRE(id_observe_original(h, (enum id_original_fact)(ID_FACT_CHILD_BORN | ID_FACT_BIRTH_FAILED_KNOWN)) == ID_INVALID);
    REQUIRE(id_try_retire(h) != ID_RETIRED); return 1;
}
static int facts_before_arm_fail(void) {
    id_reservation *h = NULL; REQUIRE(acquisition(&h));
    REQUIRE(id_observe_original(h, ID_FACT_CHILD_BORN) != ID_OK);
    REQUIRE(id_observe_original(h, ID_FACT_BIRTH_FAILED_KNOWN) != ID_OK);
    REQUIRE(id_observe_original(h, ID_FACT_DIRECT_CHILD_REAPED) != ID_OK);
    return 1;
}
static int later_birth_conflict_is_sticky(void) {
    id_reservation *h = NULL; struct id_snapshot s;
    REQUIRE(acquisition(&h)); REQUIRE(id_arm_birth(h) == ID_OK);
    REQUIRE(id_observe_original(h, ID_FACT_BIRTH_FAILED_KNOWN) == ID_OK);
    REQUIRE(id_observe_original(h, ID_FACT_CHILD_BORN) != ID_OK);
    REQUIRE(id_observe_original(h, ID_FACT_BIRTH_FAILED_KNOWN) != ID_OK);
    REQUIRE(id_try_retire(h) != ID_RETIRED);
    REQUIRE(snapshot(h, &s) && s.birth_unknown && (s.retained_debt & ID_DEBT_CHILD_TREE));
    return 1;
}
static int later_unknown_conflict_is_sticky(void) {
    id_reservation *h = NULL; REQUIRE(acquisition(&h)); REQUIRE(id_arm_birth(h) == ID_OK);
    REQUIRE(id_observe_original(h, ID_FACT_BIRTH_FAILED_KNOWN) == ID_OK);
    REQUIRE(id_retain(h, ID_REASON_BIRTH_UNKNOWN) != ID_OK);
    REQUIRE(id_observe_original(h, ID_FACT_BIRTH_FAILED_KNOWN) != ID_OK);
    REQUIRE(id_try_retire(h) != ID_RETIRED); return 1;
}
static int output_handle_not_overwritten(void) {
    id_reservation *h = NULL; struct id_request r = request(); REQUIRE(acquisition(&h));
    id_reservation *old = h; r.candidate_uid += 10; r.candidate_gid += 10;
    REQUIRE(id_acquire(&r, &h) == ID_BAD_STATE && h == old);
    REQUIRE(id_poll_authority(h) == ID_OK); return 1;
}
#if defined(B3_NAMESPACE_MODEL_ONLY)
static int owner_change_refuses_operations(void) {
    id_reservation *h = NULL, *second = NULL; struct id_request r = request(); struct id_snapshot s;
    REQUIRE(acquisition(&h)); namespace_model_change_pid();
    REQUIRE(id_arm_birth(h) == ID_OWNER_MISMATCH && id_poll_authority(h) == ID_OWNER_MISMATCH);
    REQUIRE(id_try_retire(h) == ID_OWNER_MISMATCH && id_get_snapshot(h, &s) == ID_OWNER_MISMATCH);
    REQUIRE(id_acquire(&r, &second) == ID_OWNER_MISMATCH && !second);
    REQUIRE(model_calls(IDP_ARM) == 0); return 1;
}
static int namespace_drift_before_arm(void) {
    id_reservation *h = NULL; REQUIRE(acquisition(&h)); namespace_model_change_current();
    REQUIRE(id_arm_birth(h) != ID_OK && model_calls(IDP_ARM) == 0);
    REQUIRE(id_try_retire(h) != ID_RETIRED && has_pair_debt(h)); return 1;
}
static int namespace_drift_before_retire(void) {
    id_reservation *h = NULL; REQUIRE(acquisition(&h)); namespace_model_change_current();
    REQUIRE(id_try_retire(h) != ID_RETIRED && model_calls(IDP_RETIRE) == 0);
    REQUIRE(has_pair_debt(h)); return 1;
}
static int close_failure_during_capture(void) {
    id_reservation *h = NULL; struct id_request r = request(); struct id_snapshot s;
    namespace_model_fail_close(1);
    REQUIRE(id_acquire(&r, &h) != ID_OK && h);
    REQUIRE(snapshot(h, &s) && s.close_fault);
    REQUIRE(model_calls(IDP_ALLOCATE) == 0);
    REQUIRE(id_arm_birth(h) != ID_OK); return 1;
}
static int close_failure_after_tombstone(void) {
    id_reservation *h = NULL; struct id_snapshot s;
    REQUIRE(acquisition(&h));
    /* retire rechecks self namespace (one close), then closes held duplicate. */
    namespace_model_fail_close(2);
    REQUIRE(id_try_retire(h) != ID_RETIRED);
    REQUIRE(snapshot(h, &s) && s.close_fault && s.pair_permanently_tombstoned);
    unsigned observed = namespace_model_close_calls();
    REQUIRE(id_try_retire(h) != ID_RETIRED);
    REQUIRE(namespace_model_close_calls() == observed && has_pair_debt(h)); return 1;
}
#endif
static int close_fault_retains(void) {
    id_reservation *h = NULL; REQUIRE(acquisition(&h));
    REQUIRE(id_retain(h, ID_REASON_CLOSE_FAULT) == ID_RETAINED);
    REQUIRE(id_try_retire(h) != ID_RETIRED && has_pair_debt(h)); return 1;
}
static int stale_retire_reply(void) {
    id_reservation *h = NULL; struct id_snapshot s;
    REQUIRE(acquisition(&h)); model_fault_once(IDP_RETIRE, MODEL_WRONG_TICKET);
    REQUIRE(id_try_retire(h) != ID_RETIRED); REQUIRE(snapshot(h, &s) && has_pair_debt(h));
    REQUIRE(model_record_tombstoned(s.transaction) && model_pair_excluded(s.uid, s.gid));
    REQUIRE(id_arm_birth(h) != ID_OK); return 1;
}
static int invalid_handle_is_not_authority(void) {
    id_reservation *fake = (id_reservation *)(uintptr_t)1; struct id_snapshot s;
    REQUIRE(id_arm_birth(fake) == ID_INVALID && id_poll_authority(fake) == ID_INVALID);
    REQUIRE(id_get_snapshot(fake, &s) == ID_INVALID && id_try_retire(fake) == ID_INVALID);
    REQUIRE(id_retain(fake, ID_REASON_CANCEL) == ID_INVALID); return 1;
}
static int bounded_slots_no_aba(void) {
    id_reservation *first = NULL; struct id_snapshot old;
    for (unsigned i = 0; i < 64; ++i) {
        struct id_request r = request(); id_reservation *h = NULL;
        r.candidate_uid += i * 2; r.candidate_gid += i * 2;
        REQUIRE(id_acquire(&r, &h) == ID_OK && h);
        if (!i) { first = h; REQUIRE(snapshot(h, &old)); }
        REQUIRE(id_try_retire(h) == ID_RETIRED);
    }
    struct id_request r = request(); id_reservation *other = NULL;
    r.candidate_uid += 1000; r.candidate_gid += 1000;
    REQUIRE(id_acquire(&r, &other) == ID_CAPACITY && !other);
    struct id_snapshot s; REQUIRE(snapshot(first, &s) && s.transaction == old.transaction);
    REQUIRE(s.phase == ID_PHASE_RETIRED && id_arm_birth(first) != ID_OK); return 1;
}

struct test_case { const char *name; int (*run)(void); };
static const struct test_case cases[] = {
    {"numeric_exclusions", numeric_exclusions},
    {"policy_data_not_authority", policy_data_not_authority},
    {"namespace_must_be_held_object", namespace_must_be_held_object},
    {"request_and_snapshot_are_copies", request_and_snapshot_are_copies},
    {"independent_component_exclusion", independent_component_exclusion},
    {"broken_provider_overlap", broken_provider_overlap},
    {"uid_only_partial", uid_only_partial}, {"gid_only_partial", gid_only_partial},
    {"lost_pair_ack", lost_pair_ack}, {"wrong_sequence", wrong_sequence},
    {"wrong_pair", wrong_pair}, {"wrong_installation", wrong_installation},
    {"wrong_namespace", wrong_namespace}, {"wrong_host", wrong_host},
    {"wrong_ticket", wrong_ticket}, {"wrong_issuer", wrong_issuer},
    {"unknown_debt_bits", unknown_debt_bits}, {"missing_pair_component", missing_pair_component},
    {"wrong_outcome", wrong_outcome}, {"denial_with_effect", denial_with_effect},
    {"unknown_allocate", unknown_allocate}, {"zero_ticket", zero_ticket},
    {"duplicate_ticket", duplicate_ticket}, {"arm_is_durable_one_shot", arm_is_durable_one_shot},
    {"lost_arm_ack", lost_arm_ack}, {"stale_epoch_retains", stale_epoch_retains},
    {"revoke_before_arm", revoke_before_arm}, {"revoke_after_arm", revoke_after_arm},
    {"c_expiry_is_sticky", c_expiry_is_sticky}, {"direct_reap_eof_not_tree", direct_reap_eof_not_tree},
    {"restart_with_live_child", restart_with_live_child}, {"cancel_before_arm", cancel_before_arm},
    {"permanent_tombstone_no_reuse", permanent_tombstone_no_reuse},
    {"known_no_birth_tombstone", known_no_birth_tombstone},
    {"contradictory_fact_cannot_clear_debt", contradictory_fact_cannot_clear_debt},
    {"facts_before_arm_fail", facts_before_arm_fail}, {"close_fault_retains", close_fault_retains},
    {"later_birth_conflict_is_sticky", later_birth_conflict_is_sticky},
    {"later_unknown_conflict_is_sticky", later_unknown_conflict_is_sticky},
    {"output_handle_not_overwritten", output_handle_not_overwritten},
#if defined(B3_NAMESPACE_MODEL_ONLY)
    {"owner_change_refuses_operations", owner_change_refuses_operations},
    {"namespace_drift_before_arm", namespace_drift_before_arm},
    {"namespace_drift_before_retire", namespace_drift_before_retire},
    {"close_failure_during_capture", close_failure_during_capture},
    {"close_failure_after_tombstone", close_failure_after_tombstone},
#endif
    {"stale_retire_reply", stale_retire_reply}, {"invalid_handle_is_not_authority", invalid_handle_is_not_authority},
    {"bounded_slots_no_aba", bounded_slots_no_aba}
};
int main(int argc, char **argv) {
#if defined(B3_NAMESPACE_MODEL_ONLY)
    namespace_model_reset();
#endif
    original_ns = open("/proc/self/ns/user", O_RDONLY | O_CLOEXEC);
    if (original_ns < 0) {
        puts("{\"kind\":\"summary\",\"result\":\"NOT_RUN\",\"reason\":\"namespace unavailable\"}");
        return 77;
    }
    for (unsigned i = 0; i < sizeof cases / sizeof cases[0]; ++i) {
        if (argc == 2 && strcmp(argv[1], cases[i].name)) continue;
        id_model_reset(); model_reset();
#if defined(B3_NAMESPACE_MODEL_ONLY)
        close(original_ns); namespace_model_reset();
        original_ns = open("/proc/self/ns/user", O_RDONLY | O_CLOEXEC);
        if (original_ns < 0) return 2;
#endif
        int ok = cases[i].run();
        if (model_protocol_errors()) {
            printf("{\"kind\":\"protocol_errors\",\"count\":%u}\n", model_protocol_errors()); ok = 0;
        }
        if (ok) ++passed; else ++failed;
        printf("{\"kind\":\"case\",\"name\":\"%s\",\"result\":\"%s\",\"scope\":\"MODEL_ONLY\"}\n",
               cases[i].name, ok ? "PASS" : "FAIL");
    }
    id_model_reset(); close(original_ns);
    printf("{\"kind\":\"summary\",\"result\":\"%s\",\"passed\":%u,\"failed\":%u,"
           "\"administrative_native_proof\":\"NOT_RUN\"}\n",
           failed || !passed ? "FAIL" : "PASS_SOURCE_MODEL_ONLY", passed, failed);
    return failed || !passed ? 1 : 0;
}
