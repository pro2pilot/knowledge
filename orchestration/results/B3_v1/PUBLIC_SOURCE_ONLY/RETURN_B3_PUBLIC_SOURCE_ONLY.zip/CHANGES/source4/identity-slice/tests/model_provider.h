#ifndef B3_MODEL_PROVIDER_H
#define B3_MODEL_PROVIDER_H
#if !defined(IDENTITY_MODEL_TEST_ONLY)
#error "This administrative provider is an in-memory TEST MODEL ONLY"
#endif
#include "../identity_provider.h"

/* A deterministic transactional model. It does not allocate OS identities,
 * persist anything, authenticate any administrator, or grant real authority. */
enum model_fault {
    MODEL_NORMAL = 0,
    MODEL_POLICY_MISSING,
    MODEL_UNKNOWN_AFTER_COMMIT,
    MODEL_PARTIAL_UID,
    MODEL_PARTIAL_GID,
    MODEL_WRONG_SEQUENCE,
    MODEL_WRONG_PAIR,
    MODEL_WRONG_INSTALLATION,
    MODEL_WRONG_NAMESPACE,
    MODEL_WRONG_HOST,
    MODEL_WRONG_TICKET,
    MODEL_WRONG_ISSUER,
    MODEL_ZERO_TICKET,
    MODEL_BAD_DEBT,
    MODEL_MISSING_COMPONENT,
    MODEL_DENIAL_WITH_EFFECT,
    MODEL_ALLOW_OVERLAP,
    MODEL_NO_EFFECT,
    MODEL_UNEXPECTED_OUTCOME,
    MODEL_DUPLICATE_TICKET
};
void model_reset(void);
void model_fault_once(enum id_provider_operation operation, enum model_fault fault);
void model_advance_epoch(void);
void model_revoke(uint64_t transaction);
unsigned model_calls(enum id_provider_operation operation);
unsigned model_records(void);
unsigned model_pair_excluded(uint32_t uid, uint32_t gid);
unsigned model_record_armed(uint64_t transaction);
unsigned model_record_tombstoned(uint64_t transaction);
uint32_t model_record_debt(uint64_t transaction);
unsigned model_protocol_errors(void);
#endif
