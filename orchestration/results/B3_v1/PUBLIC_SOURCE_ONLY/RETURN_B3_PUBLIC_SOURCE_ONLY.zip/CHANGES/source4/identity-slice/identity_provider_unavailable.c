#include "identity_provider.h"
#include <string.h>
#if defined(IDENTITY_MODEL_TEST_ONLY)
#error "The production unavailable provider must not be a model success provider"
#endif

/* There is deliberately no success branch, weak symbol, callback registration,
 * configuration reserved flag, UID scan, environment toggle or JSON reader.
 * Defining a policy is external work, not something this source can infer. */
void id_provider_step(const struct id_provider_call *call,
                      struct id_provider_reply *reply)
{
    if (!reply) return;
    memset(reply, 0, sizeof *reply);
    if (call) {
        reply->sequence = call->sequence;
        reply->request = call->request;
        reply->ticket = call->ticket;
    }
    reply->outcome = IDP_POLICY_MISSING;
}
