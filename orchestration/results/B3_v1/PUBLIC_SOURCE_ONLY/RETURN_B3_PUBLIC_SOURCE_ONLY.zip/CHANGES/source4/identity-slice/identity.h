#ifndef KNOWLEDGE_IDENTITY_SLICE_H
#define KNOWLEDGE_IDENTITY_SLICE_H
/* PRIVATE B3 source interface. Numeric/configuration fields are DATA. Only a
 * trusted, statically selected administrative provider may mint a reservation.
 * The supplied production provider has no authority and always blocks. */
#include <stdint.h>

typedef struct id_reservation id_reservation;

enum id_status {
    ID_OK = 0,
    ID_POLICY_BLOCKED = 1,
    ID_INVALID = 2,
    ID_BUSY = 3,
    ID_RETAINED = 4,
    ID_STALE = 5,
    ID_REVOKED = 6,
    ID_OWNER_MISMATCH = 7,
    ID_BAD_STATE = 8,
    ID_CAPACITY = 9,
    ID_RETIRED = 10
};
enum id_phase {
    ID_PHASE_ALLOCATING = 1,
    ID_PHASE_ACQUIRING = 2,
    ID_PHASE_RESERVED = 3,
    ID_PHASE_ARMED = 4,
    ID_PHASE_CHILD_HELD = 5,
    ID_PHASE_RETAINED = 6,
    ID_PHASE_RETIRED = 7,
    ID_PHASE_BLOCKED = 8
};
enum id_reason {
    ID_REASON_CANCEL = 1,
    ID_REASON_C_EXPIRED = 2,
    ID_REASON_PROVIDER_LOST = 3,
    ID_REASON_BIRTH_UNKNOWN = 4,
    ID_REASON_CLOSE_FAULT = 5,
    ID_REASON_RECOVERY_REQUIRED = 6
};
enum id_debt {
    ID_DEBT_UID = 1u << 0,
    ID_DEBT_GID = 1u << 1,
    ID_DEBT_CHILD_TREE = 1u << 2,
    ID_DEBT_OUTPUT = 1u << 3,
    ID_DEBT_OWNED_OBJECTS = 1u << 4,
    ID_DEBT_GROUP_MEMBERSHIP = 1u << 5,
    ID_DEBT_SUBID = 1u << 6,
    ID_DEBT_DURABLE_RECORD = 1u << 7
};
#define ID_ADMIN_DEBT ((uint32_t)(ID_DEBT_UID | ID_DEBT_GID | \
    ID_DEBT_OWNED_OBJECTS | ID_DEBT_GROUP_MEMBERSHIP | ID_DEBT_SUBID | \
    ID_DEBT_DURABLE_RECORD))
#define ID_ALL_DEBT ((uint32_t)(ID_ADMIN_DEBT | ID_DEBT_CHILD_TREE | ID_DEBT_OUTPUT))

struct id_request {
    uint32_t authorized_uid, authorized_gid;
    uint32_t ledger_first, ledger_last;
    uint32_t candidate_uid, candidate_gid;
    unsigned char host_id[16], installation_id[16];
    /* Borrowed original Main capture. The slice duplicates and holds it,
     * compares against /proc/self/ns/user, and never reopens a numeric PID.
     * Matching fstat/ioctl alone is NOT administrative or Main authority. */
    int original_userns_fd;
};
struct id_snapshot {
    enum id_phase phase;
    enum id_status last_status;
    uint32_t uid, gid, retained_debt, observed_facts, retention_reasons;
    uint64_t provider_epoch, transaction, fence, sequence;
    int birth_armed, birth_unknown, revoked, cleanup_deadline_expired;
    int pair_permanently_tombstoned, close_fault;
};

/* Caller must initialize *out to NULL. A nonempty output is rejected with
 * ID_BAD_STATE and preserved, so a second acquire cannot erase owned custody.
 * On complete success returns ID_OK and a private live handle. On any
 * ambiguous/partial result returns a retained handle. POLICY_BLOCKED/BUSY
 * before pair effects returns no authority handle. Always inspect status;
 * a non-NULL diagnostic/custody handle is never permission to birth. */
enum id_status id_acquire(const struct id_request *request,
                          id_reservation **out);
enum id_status id_poll_authority(id_reservation *reservation);
/* Durable ARM must precede even attempting H birth. It is one-shot. Once
 * armed, revocation cannot make either ID reusable; unknown birth retains. */
enum id_status id_arm_birth(id_reservation *reservation);
enum id_status id_retain(id_reservation *reservation, enum id_reason reason);
/* RETIRED discharges a known never-born lease after a durable tombstone.
 * A born/unknown attempt CANNOT retire in v1: direct-child reap and two EOFs
 * do not prove full descendant-tree closure. IDs remain reserved forever;
 * residual administrative debt remains with the provider. No reuse API. */
enum id_status id_try_retire(id_reservation *reservation);
enum id_status id_get_snapshot(const id_reservation *reservation,
                               struct id_snapshot *out);
const char *id_status_name(enum id_status status);

#endif
