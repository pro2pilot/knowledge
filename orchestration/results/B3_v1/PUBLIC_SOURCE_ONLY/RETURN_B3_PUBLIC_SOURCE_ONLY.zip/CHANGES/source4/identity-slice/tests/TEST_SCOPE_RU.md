# Проверки B3 identity v1

## Команда

Из корня exact applied snapshot:

```sh
python3 source4/identity-slice/tests/run_checks.py --output-dir /path/to/new-evidence
```

Каталог output должен отсутствовать. Runner не переиспользует прежние результаты,
проверяет SHA pinned входного MANIFEST и все 59 исходных файлов, сохраняет точные
исходники, argv, stdout/stderr/rc, версии и source SHA. Исполняются только
ordinary denial fixture и явно обозначенные модели; translation-only объект
с actual core/intake/adapter не исполняется.

## Разные области доказательств

| Проверка | Что проверяется | Что не следует из результата |
|---|---|---|
| Strict GCC native object | C declarations/bodies, реальные headers, отсутствие ошибок/предупреждений | Native административная reservation, работа Main/H |
| Production unavailable provider + ordinary namespace | Чтение своего namespace, native descriptor checks и неизменный отказ provider | Наличие provisioning или допустимость рождения H |
| Production unavailable provider + namespace model | Поставленный provider не имеет positive authority path, даже когда namespace выглядит корректным | Реальная Linux namespace semantics |
| 48 consumer/protocol cases | Actual `identity.c` с transactional in-memory provider и namespace syscall model | Долговечность диска, kernel locking, конкурентные реальные Main, hostile administrator exclusion |
| 25 adapter cases | Actual adapter с явно моделированными Main/intake/identity ports | Actual accepted V, native Main lifecycle, полноценная offer |
| Negative compile guards | Model provider нельзя случайно собрать без test define; opaque public type не имеет layout | CFI или защита от произвольного изменения trusted binary |

Положительный provider существует только как модель. Model namespace functions
перехватываются linker `--wrap`; `nm` guard проверяет отсутствие реальных
`open/fcntl/fstat/ioctl/close/getpid` в consumer model executable. Отдельный
native denial executable не содержит этих test hooks. Если среда не допускает
`/proc/self/ns/user`, результат physical ordinary проверки — `NOT_RUN_ENV_GAP`,
а не PASS и не доказанная ошибка Linux source.

## Обязательные сценарии

- Identity: оба ledger endpoint и interior для обеих компонент; оба authorized
  ID включая cross comparisons; invalid sentinels/range; immutable request и
  diagnostic copy; held namespace type и drift.
- Provenance: missing policy; sequence, pair, host, install, namespace, issuer
  и ticket substitution; unknown/partial commit; contradictory no-effect
  reply; повтор ticket и отсутствие public handle constructor.
- Ownership: overlapping UID или GID при разных owner/install; broken provider
  overlap; one-shot ARM; overwrite живого output pointer; original-process
  mismatch; bounded nonrecycled handles и capacity without reset.
- Recovery: потерянный acquisition/ARM ACK; stale epoch; revocation до и после
  ARM; modeled crash с живым child; trusted C latch; incomplete reap/EOF/tree;
  namespace close failures; contradictory no-birth history; permanent tombstone.

Смена namespace и PID в тестах — входы syscall model. `restart_with_live_child`
моделирует потерю client reference и новую provider epoch при сохранённом
model record; он не запускает и не убивает настоящий Main/H. Реальная global
UID/GID map arbitration, coherent rollback protection, durable recovery и
physical crash qualification остаются задачами отсутствующего trusted provider.

`C_EXPIRED` — доверенное наблюдение fixed Main, не собственные часы identity
API. Тест проверяет sticky latch/retained debt; не измеряет deadline или I/O
latency. Born/unknown retirement в v1 запрещён даже после reap и двух EOF;
полный typed tree-custody recovery интерфейс ещё не предоставлен.

## Ограниченная внешняя проверка env gap

На обычном Linux x86_64 runner повторить ту же команду с
`--require-ordinary-namespace`. Это делает отсутствие реального namespace
read явным failure проверки среды. Не запускать Main, H, Node, bundle, sudo,
user/group utilities, setuid/setgid/cap/ACL mutation, Docker privileged или
общий release gate. Точная GitHub Actions заявка находится в packet
`ACTIONS_REQUEST.json`; самостоятельно workflow из этого source не запускается.
