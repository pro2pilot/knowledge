/* COMPILE ONLY. Actual pinned configuration/core/intake declarations and
 * bodies, then the new adapter. No main, no model macros and no execution.
 * Retained function pointers keep the source bodies visible at -O2. */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#if defined(IDENTITY_MODEL_TEST_ONLY)
#error "The adapter compile fixture must use the actual pinned native bodies"
#endif
#include "../../BASE_MAIN/verification-linux-service-configuration.h"
#include "../../intake-slice/tests/main_intake_compile.c"
#include "../main-identity-adapter.inc"

struct id_adapter_compile_references {
    int (*capture)(const struct kv_linux_service_configuration *);
    enum id_status (*reserve)(const struct kv_linux_service_configuration *,
                              uint32_t, uint32_t);
};
const struct id_adapter_compile_references id_adapter_compile_only_api = {
    id_main_capture_configuration_original, id_main_reserve_original
};
