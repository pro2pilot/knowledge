# B3 identity v1: private HUID/HGID reservation contract

## Статус и предмет

**Реализуемый объём — закрытый typed source interface, native lifecycle
consumer, отдельный отказной Main adapter и tests. Administrative provisioning
в этих входах отсутствует и остаётся BLOCKED.** Поставленный production
provider всегда возвращает `ID_POLICY_BLOCKED`; он не выдаёт успешную
резервацию. Явная test-only модель provider служит проверке native consumer и
его отказов. Её результаты не являются physical административной authority,
работой настоящего H или release PASS.

Изменения additive: только новые файлы `source4/identity-slice/`. Конфигурация
ABI1, core, intake, deps и чужие этапы неизменны. A2 предоставляет капсулу B1
наблюдений и не предоставляет полный offer. Source adapter не создаёт offer,
не вызывает clone/spawn, не разрешает release/exec и не запускает privileged
Main/H/Node/bundle. Никакие accounts, groups, host policy, capabilities или
ACL не создаются и не меняются.

## 1. Что означает административная резервация

H identity — полная пара `(HUID, HGID)` в той же actual user namespace, в
которой trusted Main намерен выполнять соответствующий credential transition.
Числа и scope configuration являются **DATA**, а не authority. Нужна
утверждённая административная политика, которая резервирует обе роли и
предотвращает их употребление другими login/service/project/worker principals,
другими Main/installations и subordinate UID/GID mappings на весь необходимый
срок. Нужны также trusted authority provenance и устойчивое после crash
состояние выдачи/ограждения поколения.

Пустой результат `getpwuid`, `getgrgid`, NSS scan или `/proc` scan доказывал бы
лишь отсутствие найденной записи в момент чтения. Он не блокирует другую
административную выдачу и не определяет существующие процессы, open objects,
files или namespace mappings. Этот source не использует такие scans как
reservation. `reserved=true`, root-owned JSON, совпавший UID, signature/hash
без утверждённого verifier, nonce или numeric FD/PID также не заменяют
provisioning authority.

### Обязательная numeric policy

Для обоих кандидатов `x = HUID` и `x = HGID` требуется:

- `x != 0` и `x != UINT32_MAX`; sentinel `-1` у credential syscalls непригоден.
- `x != authorized_uid` и `x != authorized_gid`, включая cross comparisons.
- `x < ledger_first || x > ledger_last`; оба конца диапазона включены.
- Authorized IDs и границы валидны; диапазон не пуст и не переполнен.

`HUID == HGID` допустимо: UID и GID являются разными kernel role namespaces,
но **обе** роли должны быть administratively reserved. Partial UID reservation
никогда не означает GID reservation. Две одновременные пары, имеющие общий UID
или общий GID, конфликтуют даже при разных вторых компонентах. Cross-exclusion
от authorized UID/GID — отдельное более строгое правило этого проекта.

Локальная consumer защита от overlap сравнивает уже удержанные UID и GID
в том же сохранённом user namespace. Разные user namespaces могут отображать
разные внутренние номера в один внешний kernel UID/GID; local `(dev,ino)` и
числовое сравнение эту коллизию не исключают. Trusted provider обязан
канонизировать/арбитрировать обе роли во всей mapped host collision domain,
включая subordinate mappings и другие installations. Этот mapped host
arbitration отсутствует в shipped implementation и остаётся policy/provider
обязательством.

Numeric policy ограничивает допустимый запрос. Прохождение этой проверки не
резервирует ни одну роль и не допускает H birth.

## 2. Закрытые типы и provenance

`identity.h` объявляет opaque `id_reservation`; caller не получает его layout.
Это private native interface для fixed trusted source, не wire protocol и не
library ABI для произвольного клиента. Нет constructor/import из snapshot,
JSON, массива bytes, переданного пользователем PID/FD, произвольного
provider callback или указателя на authority. Реализация выбирает provider
статически при сборке. Поставленный `identity_provider_unavailable.c` не имеет
успешной ветки.

| Тип/объект | Содержимое | Что им нельзя доказывать |
|---|---|---|
| `id_request` | Candidate UID/GID, immutable exclusions, host/installation labels, borrowed original userns FD | Reservation, trusted administrator, origin Main, существование child |
| `id_bound_request` | Копия request плюс identity удержанного namespace объекта | Trust/provenance по одним полям или `(dev,ino)` |
| `id_provider_ticket` | Issuer ID, epoch, transaction, fence | Authority без настоящего trusted provider происхождения |
| `id_reservation` | Private process-owned state, held namespace duplicate, protocol ticket, monotonic sequence, retained debt | Transfer/recovery по сериализованной копии или указателю |
| `id_snapshot` | Diagnostic phase/status/IDs/sequence/debt/facts | Permission to birth, closure, возможность реконструировать handle |
| `id_original_fact` | Private glue observation из exact native attempt | Wire assertion, caller cleanup bit, administrative residual clearance |

`host_id` и `installation_id` копируются из actual administrative config;
они не являются секретами аутентификации. Borrowed original userns FD
дублируется и удерживается consumer, проверяется тип и совпадение с текущим
Main namespace. Совпадение удержанного и текущего namespace повторно проверяется
перед ARM, CHECK и RETIRE; drift/ошибка не освобождают reservation и приводят к
retention. Это consistency относительно захваченного kernel объекта;
происхождение Main и авторизация principal остаются trusted-provider
обязательствами. Numeric peer/child PID не используется для reopening.

Native consumer имеет 64 bounded slots на original process. Slots не
переиспользуются, включая отказные и retired попытки: pointer ABA не создаёт
новую reservation. Exhaustion возвращает `ID_CAPACITY`, не сбрасывая прежние
claims. Test-only `id_model_reset` отсутствует в production build.

Процесс-владелец определяется original native process custody. Проверка
текущего PID служит отказу inherited/forked копии; PID сам по себе не mint-ит
полномочие. Provider должен привязать вызовы к authenticated native Main
session независимо от `local_owner` address и полей запроса. Все такие поля
отдельно проверяются на точное соответствие после trusted delivery.

Закрытый C interface не является CFI/memory-corruption защитой. Предпосылки:
fixed native program, отсутствие чужих mutators private state/FD table,
отсутствие потоков и untrusted callbacks в lifecycle, корректный installed
source и неизменный trust root. Нельзя подключать этот API как public socket
command.

## 3. Typed provider protocol

Provider implementation с административными полномочиями **не поставлена**.
`identity_provider.h` определяет проверяемое требование к будущей реализации;
подстановка successful mock вместо отсутствующего provisioning запрещена.

| Операция | Обязательное административное действие до положительного ответа |
|---|---|
| `IDP_ALLOCATE` | Durable transaction identity и binding request к authenticated Main/session до любых UID/GID effects. Ненулевой issuer/epoch/transaction/fence; restart не переиспользует старую идентичность. |
| `IDP_ACQUIRE_PAIR` | Serial exclusion обоих компонентов в host authority domain и durable full-pair claim под уже созданным ticket. Independent installations и concurrent Main координируются той же authority. |
| `IDP_CHECK` | Подтверждение именно этого current ticket и request, без reassignment; отрицательный/неизвестный ответ сохраняет obligations. |
| `IDP_ARM` | Durable запись «birth may exist» до разрешения первой попытки clone. После записи pair нельзя reclaim по потере Main, истечению lease/TTL или revocation. |
| `IDP_RETAIN` | Durable quarantine текущей транзакции/компонентов и соответствующих долгов. Не является rollback, release или успешной cleanup. |
| `IDP_RETIRE` | Только допустимый no-birth путь: durable permanent tombstone обоих IDs и сохранение administrative debt. Никогда не возвращает IDs в общий free pool. |

Native consumer дополнительно проверяет строго возрастающие transaction и
fence для одного issuer/epoch относительно уже виденных local tickets, а также
не допускает уменьшения issuer epoch. Это local rollback defense только в
этом original process. Она не доказывает host-wide monotonicity, устойчивость
после restart или отсутствие другой выдачи: все эти свойства обязан сохранять
trusted durable provider.

Каждый ответ связан с точными operation semantics, request, ticket и sequence.
Malformed/stale/mismatched response не переименовывает локальный owner и не
подменяет request. Повторный ответ другого поколения не закрывает текущий
lease. Sequence overflow, неизвестный исход операции и невозможность доказать
состояние переводят attempt в retention/refusal; автоматического reset нет.

Полная pair acquisition либо подтверждена целиком, либо остаётся неуспешной.
Если UID затронут, GID отказал или ack потерян после записи, retained obligations
не исчезают. Unknown означает conservative union обоих компонентов: локальная
сторона не предполагает, что второй ID свободен по диагностическому touched
mask. Future provider обязан quarantine exact transaction и не разрешать
конфликт другой installation, даже если первый Main умер.

ADMIN/Root и namespace filesystem являются trusted premises. Срез не может
победить администратора, который сознательно нарушает выбранную policy,
переписывает trusted state или обходит provisioning actor. Это конкретный
policy blocker, а не свойство, выводимое из checksum/lock.

## 4. Consumer lifecycle

| Переход/вызов | Разрешённый смысл | Отказное поведение |
|---|---|---|
| `id_acquire` | Validate request; сохранить namespace; allocate durable transaction; получить полную pair | При missing policy — `ID_POLICY_BLOCKED`; при partial/unknown возможно nonnull retained handle, который **не** разрешает birth |
| `id_poll_authority` | Повторно проверить current exact provenance/ticket | Stale/revoked/lost authority запрещает новую работу; reservation effects удерживаются |
| `id_arm_birth` | One-shot durable arm до clone | Повторный arm, stale/revoked/retained state и неизвестный ack не допускают birth |
| `id_observe_original` | Trusted private glue записывает конкретный исход original attempt | Противоречивые факты не становятся aggregate cleanup proof; нет public fact setter |
| `id_retain` | Sticky cancellation/deadline/provider-loss/unknown/close-fault retention | Даже сбой retention delivery не освобождает локальные obligations |
| `id_try_retire` | Только unarmed attempt либо native-подтверждённый failed birth без child, затем durable permanent tombstone | Любой born/unknown attempt остаётся retained, в том числе после reap и обоих EOF |
| `id_get_snapshot` | Скопировать diagnostic state для review | Snapshot не возвращается назад как authority и не разрешает H |

`id_acquire` требует заранее инициализированный `*out == NULL`. Непустой
output отвергается как `ID_BAD_STATE` и сохраняется без перезаписи, чтобы новая
попытка не стирала ранее полученную custody.

`id_acquire` имеет существенное различие между status и handle: partial
acquisition может вернуть handle для custody при отказном status. Проверка
`handle != NULL` недостаточна; она не заменяет `ID_OK`, current authority и
успешный one-shot `id_arm_birth`. В текущем shipped production path даже
`ID_OK` acquisition невозможен, потому что provider отсутствует.

Private lifecycle facts имеют точные будущие source prerequisites:

- `ID_FACT_BIRTH_FAILED_KNOWN`: actual original clone попытка достоверно не
  создала child; обычный core failure до birth также должен быть связан с
  exact armed attempt. Contradictory clone output / `birth_unknown` запрещает
  этот факт. Отсутствие записи «born» не является known failure.
- `ID_FACT_CHILD_BORN`: exact original attempt действительно сохранила actual
  child custody из результата atomic clone. Не synthetic PID/FD из receipt.
- `ID_FACT_DIRECT_CHILD_REAPED`: biological reap именно этой original child
  custody; `ESRCH`, kill success, timeout, `ECHILD` и `POLLHUP` не подходят.
- `ID_FACT_STDOUT_EOF`, `ID_FACT_STDERR_EOF`: отдельные actual read==0 на
  retained original output readers, при source-backed исключении writer
  aliases. Одна pipe, read>0 или close reader не заменяют оба EOF.

Даже допустимые direct-child reap + два EOF **не доказывают отсутствие всех
потомков**. Descendant может закрыть stdio и продолжить жить. Поэтому born и
unknown в v1 не достигают `ID_RETIRED`; `ID_DEBT_CHILD_TREE` сохраняется. Нет
`TREE_EMPTY=true`, `RESIDUALS_CLEARED` или административного cleanup bit,
которым можно обойти эту границу. Будущая full-tree custody/proof требует
отдельного source implementation и проверки.

## 5. Lifetime и ownership

Резервация охватывает период от первого возможного acquisition effect до
доказанного безопасного закрытия соответствующих obligations. Этот период не
ограничивается C и не ограничивается временем жизни Main. C — deadline
attempt protocol; это не expiration административного владения IDs.

**Точная граница времени:** identity API не получает S/W/C и не читает clock.
`id_retain(..., ID_REASON_C_EXPIRED)` принимает только trusted source event от
Main/lifecycle observer и ставит sticky `cleanup_deadline_expired` вместе с
`retention_reasons`; это latch события, не independent proof правильности C
или своевременности вызова. Source интеграция обязана проверять original
monotonic S/W/C до и после возможных delayed provider operations и не
пытаться birth после deadline. Tests этого latch не являются physical timing
proof. Отказной adapter не имеет положительной work ветки даже при late
provider response, поэтому лишь сохраняет effects и отменяет B1.

`id_provider_step` в v1 — синхронный вызов. Consumer не прерывает зависший
backend и не задаёт ему hard latency bound. Поставленный unavailable provider
возвращается немедленно, но это не qualification будущего реального backend.
Такой backend должен быть bounded/nonblocking state machine, встроенной в
B5 Main owner loop с original deadline checks до/после каждого шага и без
renewal. Без этой интеграции hung provider не доказан безопасным; physical
crash/I/O timing остаются отдельным blocker, а не закрываются latch-моделью.

| Ресурс/долг | Владелец | Когда может считаться завершённым |
|---|---|---|
| Borrowed original userns FD | Existing Main/intake | Их исходный lifecycle; identity consumer удерживает свою отдельную duplicate |
| Identity namespace duplicate и private handle | Original identity consumer | Только по разрешённому собственному пути; close failure записывается, number не используется повторно как custody |
| UID и GID claim, durable transaction/fence | Trusted provisioning authority | В v1 IDs не становятся свободными; no-birth retirement создаёт permanent tombstone |
| H actual pidfd, signal/wait/output FD custody | Existing core/будущая full integration | По реальным source obligations core; identity adapter эти FD не принимает во владение и не закрывает |
| Child tree obligation | Authority/recovery + source-backed lifecycle | Born/unknown в v1 не закрывается; direct child+stdio недостаточно |
| Owned objects, groups, subid mappings | Administrative authority | Сохраняется после local retirement; reclamation API отсутствует |
| Запись C/revocation/provider-loss | Consumer + durable authority | Необратимый запрет новой work, не разрешение освобождения |

`mh_finish_original()` закрывает отдельную core custody и не резервирует,
освобождает или очищает административные IDs. Дескрипторы singleton не
превращаются в identity lease. Освобождение memory/FD после process exit не
является administrative closure.

В supplied API нет rehydrate/import/reopen-by-PID. После Main crash новый Main
не конструирует старый lease из совпавших labels, numbers или JSON. Новый
process может просить новую transaction только если trusted provider
сохраняет и учитывает все старые claims/quarantine. Born/unknown старого Main
не разрешают выдачу конфликтующей pair.

## 6. Crash, stale generation, revocation и recovery

Требования к настоящему future provider:

1. **Crash после allocate/частичной acquisition.** Durable transaction
   существует до effects. Recovery видит минимум possible pair effects;
   неизвестность не преобразуется в no-effect. Нельзя молча reset/delete
   record, ни временной выдержкой, ни новым boot ID.
2. **Crash после ARM и до записи child result.** Durable ARM означает
   возможный child. Новый Main не может заключить «child не был рождён» по
   отсутствию local acknowledgment. Pair сохраняется indefinitely, пока
   отдельно утверждённый recovery не докажет все obligations; v1 не содержит
   такого positive recovery.
3. **Crash с живым child/descendant.** Смерть Main и потеря singleton lock не
   делают его IDs свободными. External trusted supervisor либо удерживает
   actual tree custody независимо от Main, либо authority оставляет pair
   навсегда quarantine. Pdeath signal не является observed reap/tree proof.
4. **Stale generation / rolling restart.** Old ticket не действует в new
   epoch, но old debts не исчезают при смене epoch. Fencing должно отвергать
   delayed old Main операции и одновременно не отдавать старую pair новому
   Main. Exhaustion/wrap не переводятся в generation zero или очистку ledger.
5. **Revocation после последней проверки.** Provider упорядочивает check/arm
   с revocation. После успешно durable ARM revocation не отменяет факт
   possible birth. Consumer прекращает новую work и сохраняет debt; actual
   cancellation/core progress остаётся отдельным downstream обязательством.
6. **Provider loss / rollback.** Consumer не переходит на free-UID scan,
   localhost file, второй provider или новый epoch самостоятельно. Потеря
   durable records/anti-rollback assurance — refusal и quarantine. Исчезновение
   receipt не доказывает исчезновение effect.

No-birth retirement завершает текущую попытку, но не уничтожает administrative
reservation: provider tombstone навсегда исключает pair из повторной выдачи.
Это сознательно консервативное implementable v1 решение. Потребление пула или
неограниченная retention — availability consequence отсутствующей процедуры
безопасного reuse; их нельзя исправлять автоматическим освобождением.

## 7. Конкретный provisioning blocker и допустимые решения

Входная ABI1 config не содержит H pair policy или issuer channel. Source имеет
numeric exclusions, но не назначает администратора, координирующего всех
потребителей UID/GID. Поэтому **B2 administrative authority не закрыта этим
этапом**. Нужен явный выбор и отдельная реализация одного из вариантов.

| Вариант | Что должен утвердить администратор/оркестратор | Остаточное ограничение |
|---|---|---|
| Постоянная dedicated pair / пул непереиспользуемых pairs | Host-wide exclusion от accounts, memberships, service assignments, subid mappings, других installations; fixed protected provisioning source; durable per-attempt claims и permanent tombstones | Минимальная поверхность reuse; bounded pool исчерпывается; любая unknown attempt потребляет pair навсегда до отдельного решения |
| Внешний durable reservation supervisor | Единственный trusted allocator обеих ролей; authenticated original Main sessions; durable transaction/arm/fencing; ownership child tree переживает Main; coordinated admin API | Больше компонентов; нужен отдельно проверенный native provider и physical negative qualification |
| Отказ от H birth до provisioning | Никаких новых authority claims; shipped default `ID_POLICY_BLOCKED` | Полный bootstrap остаётся BLOCKED; это текущий исполняемый отказной путь |

Reuse и возврат IDs в системный allocator не входят ни в один положительный
путь v1. Если policy позднее потребует reuse, нужен отдельный контракт,
доказывающий отсутствие всех descendant credentials, UID/GID-owned objects,
open references, supplementary memberships, namespace mappings, queued work
и сохранившихся административных claims во всей authority domain. Смена epoch,
удаление account entry, успешный reap и два EOF не достаточны.

## 8. Проверяемые границы и неочевидные сценарии

Полный independent critic report хранится в передаче отдельно. Ниже —
нормативные сценарии, которые контракт обязан сохранять при любой реализации.

| Проверка | Три вероятных неочевидных сценария | Требуемая реакция |
|---|---|---|
| Identity policy | HGID попадает ровно на ledger_last; HUID совпадает с authorized GID; две пары имеют общий GID при разных UID | Numeric refusal / component conflict; не только сравнение HUID с current ledger allocation |
| Provenance | Совпавшие host/install labels другого namespace; delayed success от old epoch после restart; forged `reserved=true` с корректными numbers | Нет authority из DATA; exact held namespace+provider binding; stale reply не принимает новое поколение |
| Ownership | Main A умирает после UID effect до GID ack; Main B получает другой second component; forked копия local handle пытается ARM | Retained/quarantine обоих possible components; owner mismatch; отсутствие aggregate reservation |
| Recovery | ARM durable, child result не записан; direct child reaped, detached descendant закрыл stdio; C истекла во время provider reply | Possible birth сохраняется; tree debt не закрывается; late/unknown work не разрешает reuse |
| Revocation и reuse | Revocation после успешного ARM; group membership живёт после child; файл с HUID переживает local lease | Sticky retention; нет numeric recycling; administrative debt остаётся даже после no-birth retirement |

Tests source consumer используют явно test-only provider и управляемые fault
responses; настоящая administrative uniqueness/durability этим не доказана.
Ordinary unprivileged namespace observations/compile не запускают Main/H и
не квалифицируют privileged transitions. Точные команды, версии, rc,
stdout/stderr, source hashes и сохранённые FAIL находятся в evidence передачи.

## 9. Независимые неустранённые блокеры

Этот identity stage не закрывает protected loader/runtime graph, новый native
Main-origin NNP1 entry/addon, complete offer/descriptor inventory, full event
loop/recovery и runtimeFS delegation. Нынешний core удерживает root-only child
и не вызывает свой отдельный credential-drop helper на этом пути. Отдельный
HUID не даёт доступа к private project; NNP1 не восстанавливает старый SUID
runtime. Положительный release/exec остаётся недоступен. Эти границы нельзя
понижать только потому, что модель reservation проходит тесты.
