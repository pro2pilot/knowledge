#ifndef KNOWLEDGE_IDENTITY_SLICE_INTERNAL_H
#define KNOWLEDGE_IDENTITY_SLICE_INTERNAL_H
#include "identity.h"
/* Trusted source glue ONLY, not a wire/public evidence constructor.
 * An adapter must derive facts from original private core custody, never
 * mutable snapshots/JSON. No administrative-residuals-cleared fact exists. */
enum id_original_fact {
    ID_FACT_BIRTH_FAILED_KNOWN = 1u << 0,
    ID_FACT_CHILD_BORN = 1u << 1,
    ID_FACT_DIRECT_CHILD_REAPED = 1u << 2,
    ID_FACT_STDOUT_EOF = 1u << 3,
    ID_FACT_STDERR_EOF = 1u << 4
};
enum id_status id_observe_original(id_reservation *reservation,
                                   enum id_original_fact fact);
#if defined(IDENTITY_MODEL_TEST_ONLY)
/* Test-only reset of private bounded slots; never compiled in production. */
void id_model_reset(void);
#endif
#endif
