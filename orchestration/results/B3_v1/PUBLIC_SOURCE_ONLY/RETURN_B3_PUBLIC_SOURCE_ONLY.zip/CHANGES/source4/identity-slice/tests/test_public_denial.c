#define _GNU_SOURCE
#include "../identity.h"
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main(void) {
    struct id_request r;
    memset(&r, 0, sizeof r);
    r.authorized_uid = 1000; r.authorized_gid = 1001;
    r.ledger_first = 1000000000; r.ledger_last = 1800000000;
    r.candidate_uid = 2000000000; r.candidate_gid = 2000000001;
    memset(r.host_id, 0x11, sizeof r.host_id);
    memset(r.installation_id, 0x22, sizeof r.installation_id);
    r.original_userns_fd = open("/proc/self/ns/user", O_RDONLY | O_CLOEXEC);
    if (r.original_userns_fd < 0) {
        printf("{\"kind\":\"summary\",\"result\":\"NOT_RUN\",\"reason\":\"userns read unavailable\",\"errno\":%d}\n", errno);
        return 77;
    }
    unsigned blocked = 0, other_denials = 0;
    for (unsigned i = 0; i < 70; ++i) {
        id_reservation *h = NULL;
        enum id_status status = id_acquire(&r, &h);
        if (status == ID_OK || h) {
            puts("{\"kind\":\"summary\",\"result\":\"FAIL\",\"reason\":\"production acquired authority\"}");
            return 1;
        }
        if (status == ID_POLICY_BLOCKED) ++blocked;
        else if (status == ID_CAPACITY) ++other_denials;
        else {
            printf("{\"kind\":\"summary\",\"result\":\"FAIL\",\"status\":%d}\n", status);
            return 1;
        }
    }
    close(r.original_userns_fd);
    if (!blocked || id_arm_birth(NULL) == ID_OK || id_try_retire(NULL) == ID_RETIRED) return 1;
    printf("{\"kind\":\"summary\",\"result\":\"PASS_ORDINARY_DENIAL_ONLY\","
           "\"policy_blocked\":%u,\"bounded_capacity_denials\":%u,\"births\":0,"
           "\"administrative_reservations\":0}\n", blocked, other_denials);
#if defined(B3_NAMESPACE_MODEL_ONLY)
    puts("{\"kind\":\"scope\",\"namespace\":\"MODEL_ONLY\",\"provider\":\"ACTUAL_UNAVAILABLE_SOURCE\"}");
#endif
    return 0;
}
