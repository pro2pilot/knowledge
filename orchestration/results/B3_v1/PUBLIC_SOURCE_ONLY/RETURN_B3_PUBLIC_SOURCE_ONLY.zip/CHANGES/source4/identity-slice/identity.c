#define _GNU_SOURCE
#include "identity_internal.h"
#include "identity_provider.h"
#include <fcntl.h>
#include <limits.h>
#include <linux/nsfs.h>
#include <linux/sched.h>
#include <stdint.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#if !defined(__linux__)
#error "This private source slice uses Linux user namespace descriptors"
#endif
#define ID_MAX_ATTEMPTS 64u
#define ID_KNOWN_FACTS ((uint32_t)(ID_FACT_BIRTH_FAILED_KNOWN | \
    ID_FACT_CHILD_BORN | ID_FACT_DIRECT_CHILD_REAPED | ID_FACT_STDOUT_EOF | \
    ID_FACT_STDERR_EOF))

/* Fixed single-threaded Main premise, matching the pinned native source.
 * Different Main processes arbitrate through ONE trusted provider domain.
 * This local table is neither an interprocess lock nor administrative proof.
 * Slots are never recycled, preventing stale-pointer ABA within this program.
 * No public memcpy/deserialization/allocation constructor exists. */
struct id_reservation {
    int used, userns_fd;
    pid_t owner;
    struct id_bound_request request;
    struct id_provider_ticket ticket;
    struct id_snapshot diagnostic;
    int ticket_valid, pair_complete, ever_retained, known_no_birth, birth_conflict;
};
static struct id_reservation id_slots[ID_MAX_ATTEMPTS];
static pid_t id_program_owner;

static int bytes_nonzero(const unsigned char *p, unsigned n)
{
    unsigned v = 0;
    for (unsigned i = 0; i < n; ++i) v |= p[i];
    return v != 0;
}

static int excluded(uint32_t n, const struct id_request *r)
{
    return n == 0 || n == UINT32_MAX || n == r->authorized_uid ||
           n == r->authorized_gid ||
           (n >= r->ledger_first && n <= r->ledger_last);
}

static int request_valid(const struct id_request *r)
{
    return r && r->authorized_uid && r->authorized_gid &&
           r->authorized_uid != UINT32_MAX && r->authorized_gid != UINT32_MAX &&
           r->ledger_first && r->ledger_last != UINT32_MAX &&
           r->ledger_first <= r->ledger_last &&
           !excluded(r->candidate_uid, r) && !excluded(r->candidate_gid, r) &&
           bytes_nonzero(r->host_id, 16) && bytes_nonzero(r->installation_id, 16) &&
           r->original_userns_fd >= 0;
}

static int same_request(const struct id_bound_request *a,
                        const struct id_bound_request *b)
{
    return a->authorized_uid == b->authorized_uid &&
           a->authorized_gid == b->authorized_gid &&
           a->ledger_first == b->ledger_first && a->ledger_last == b->ledger_last &&
           a->uid == b->uid && a->gid == b->gid &&
           a->userns_device == b->userns_device && a->userns_inode == b->userns_inode &&
           !memcmp(a->host_id, b->host_id, 16) &&
           !memcmp(a->installation_id, b->installation_id, 16);
}

static int valid_ticket(const struct id_provider_ticket *t)
{
    return bytes_nonzero(t->issuer_id, 16) && t->epoch && t->transaction && t->fence;
}

static int same_ticket(const struct id_provider_ticket *a,
                       const struct id_provider_ticket *b)
{
    return a->epoch == b->epoch && a->transaction == b->transaction &&
           a->fence == b->fence && !memcmp(a->issuer_id, b->issuer_id, 16);
}

static int empty_ticket(const struct id_provider_ticket *t)
{
    return !bytes_nonzero(t->issuer_id, 16) && !t->epoch &&
           !t->transaction && !t->fence;
}

static int new_ticket(const struct id_provider_ticket *ticket)
{
    if (!valid_ticket(ticket)) return 0;
    for (unsigned i = 0; i < ID_MAX_ATTEMPTS; ++i) {
        const struct id_reservation *other = &id_slots[i];
        if (!other->used || !other->ticket_valid ||
            memcmp(ticket->issuer_id, other->ticket.issuer_id, 16)) continue;
        /* Per-issuer epoch is global to its administrative collision domain.
         * Old local tombstones remain visible, so restart/ABA replies cannot
         * silently create another lease. Global rollback still needs the
         * trusted durable provider; this local check cannot prove that. */
        if (ticket->epoch < other->ticket.epoch ||
            (ticket->epoch == other->ticket.epoch &&
             (ticket->transaction <= other->ticket.transaction ||
              ticket->fence <= other->ticket.fence))) return 0;
    }
    return 1;
}

/* Compare membership before dereference: arbitrary pointer/NULL cannot mint
 * a handle. Same-process hostile memory writes remain outside C's guarantees. */
static struct id_reservation *find_handle(const id_reservation *h)
{
    for (unsigned i = 0; i < ID_MAX_ATTEMPTS; ++i)
        if (h == &id_slots[i] && id_slots[i].used) return &id_slots[i];
    return NULL;
}

static enum id_status guard(const id_reservation *h, struct id_reservation **out)
{
    struct id_reservation *r = find_handle(h);
    if (!r) return ID_INVALID;
    if (r->owner != getpid() || id_program_owner != getpid()) return ID_OWNER_MISMATCH;
    *out = r;
    return ID_OK;
}

static void close_namespace(struct id_reservation *r)
{
    if (r->userns_fd >= 0) {
        int fd = r->userns_fd;
        r->userns_fd = -1;
        /* Linux close is recorded once. Never retry a reused descriptor. */
        if (close(fd)) r->diagnostic.close_fault = 1;
    }
}

static enum id_status retain_status(struct id_reservation *r, enum id_status s)
{
    r->ever_retained = 1;
    r->diagnostic.phase = ID_PHASE_RETAINED;
    r->diagnostic.last_status = s;
    if (s == ID_REVOKED) r->diagnostic.revoked = 1;
    return s;
}

static enum id_status birth_conflict(struct id_reservation *r, enum id_status status)
{
    r->birth_conflict = 1;
    r->known_no_birth = 0;
    r->diagnostic.birth_unknown = 1;
    r->diagnostic.retained_debt |= ID_DEBT_CHILD_TREE | ID_DEBT_OUTPUT;
    r->diagnostic.retention_reasons |= 1u << (ID_REASON_BIRTH_UNKNOWN - 1);
    return retain_status(r, status);
}

static enum id_status outcome_failure(struct id_reservation *r,
                                      enum id_provider_outcome outcome)
{
    if (outcome == IDP_STALE) return retain_status(r, ID_STALE);
    if (outcome == IDP_REVOKED) return retain_status(r, ID_REVOKED);
    return retain_status(r, ID_RETAINED);
}

static int exchange(struct id_reservation *r, enum id_provider_operation operation,
                     struct id_provider_reply *reply)
{
    if (r->diagnostic.sequence == UINT64_MAX) {
        (void)retain_status(r, ID_RETAINED);
        return 0;
    }
    struct id_provider_call call;
    memset(&call, 0, sizeof call);
    call.local_owner = r;
    call.operation = operation;
    call.sequence = ++r->diagnostic.sequence;
    call.request = r->request;
    call.ticket = r->ticket;
    call.native_facts = r->diagnostic.observed_facts;
    call.retained_debt = r->diagnostic.retained_debt;
    call.retention_reasons = r->diagnostic.retention_reasons;
    memset(reply, 0, sizeof *reply);
    id_provider_step(&call, reply);
    /* Fields are consistency/fencing checks, not authentication. The fixed
     * provider must itself have authenticated provenance and durable state. */
    if (reply->sequence != call.sequence || !same_request(&reply->request, &r->request) ||
        (reply->touched_components & ~(uint32_t)(ID_DEBT_UID | ID_DEBT_GID)) ||
        (reply->retained_debt & ~ID_ALL_DEBT) ||
        (operation != IDP_ALLOCATE && !same_ticket(&reply->ticket, &r->ticket))) {
        (void)retain_status(r, ID_STALE);
        return 0;
    }
    return 1;
}

static int namespace_current(struct id_reservation *r)
{
    struct stat held, current;
    int self = open("/proc/self/ns/user", O_RDONLY | O_CLOEXEC);
    int good = r->userns_fd >= 0 && self >= 0 &&
               !fstat(r->userns_fd, &held) && !fstat(self, &current) &&
               (uint64_t)held.st_dev == r->request.userns_device &&
               (uint64_t)held.st_ino == r->request.userns_inode &&
               held.st_dev == current.st_dev && held.st_ino == current.st_ino &&
               ioctl(r->userns_fd, NS_GET_NSTYPE) == CLONE_NEWUSER &&
               ioctl(self, NS_GET_NSTYPE) == CLONE_NEWUSER;
    if (self >= 0 && close(self)) {
        r->diagnostic.close_fault = 1;
        good = 0;
    }
    return good;
}

static int local_pair_conflict(const struct id_reservation *r)
{
    for (unsigned i = 0; i < ID_MAX_ATTEMPTS; ++i) {
        const struct id_reservation *other = &id_slots[i];
        if (other == r || !other->used ||
            !(other->diagnostic.retained_debt & (uint32_t)(ID_DEBT_UID | ID_DEBT_GID)) ||
            other->request.userns_device != r->request.userns_device ||
            other->request.userns_inode != r->request.userns_inode) continue;
        if (other->request.uid == r->request.uid || other->request.gid == r->request.gid)
            return 1;
    }
    /* Different user namespaces may map to the same outer kernel IDs.
     * Only the global trusted provider can exclude that mapped collision. */
    return 0;
}

static int hold_namespace(const struct id_request *request,
                           struct id_reservation *r)
{
    struct stat held, current;
    int copy = fcntl(request->original_userns_fd, F_DUPFD_CLOEXEC, 16);
    if (copy < 0) return 0;
    r->userns_fd = copy;
    int self = open("/proc/self/ns/user", O_RDONLY | O_CLOEXEC);
    int good = self >= 0 && !fstat(copy, &held) && !fstat(self, &current) &&
               held.st_dev == current.st_dev && held.st_ino == current.st_ino &&
               ioctl(copy, NS_GET_NSTYPE) == CLONE_NEWUSER &&
               ioctl(self, NS_GET_NSTYPE) == CLONE_NEWUSER;
    if (self >= 0 && close(self)) {
        r->diagnostic.close_fault = 1;
        good = 0;
    }
    if (!good) {
        close_namespace(r);
        return 0;
    }
    r->request.userns_device = (uint64_t)held.st_dev;
    r->request.userns_inode = (uint64_t)held.st_ino;
    return 1;
}

enum id_status id_acquire(const struct id_request *request, id_reservation **out)
{
    if (!out) return ID_INVALID;
    if (*out) return ID_BAD_STATE;
    *out = NULL;
    if (!request_valid(request)) return ID_INVALID;
    pid_t owner = getpid();
    if (id_program_owner && id_program_owner != owner) return ID_OWNER_MISMATCH;
    if (!id_program_owner) id_program_owner = owner;
    struct id_reservation *r = NULL;
    for (unsigned i = 0; i < ID_MAX_ATTEMPTS; ++i) {
        if (!id_slots[i].used) {
            r = &id_slots[i];
            break;
        }
    }
    if (!r) return ID_CAPACITY;
    memset(r, 0, sizeof *r);
    r->used = 1;
    r->owner = owner;
    r->userns_fd = -1;
    r->request.authorized_uid = request->authorized_uid;
    r->request.authorized_gid = request->authorized_gid;
    r->request.ledger_first = request->ledger_first;
    r->request.ledger_last = request->ledger_last;
    r->request.uid = request->candidate_uid;
    r->request.gid = request->candidate_gid;
    memcpy(r->request.host_id, request->host_id, 16);
    memcpy(r->request.installation_id, request->installation_id, 16);
    r->diagnostic.uid = r->request.uid;
    r->diagnostic.gid = r->request.gid;
    r->diagnostic.phase = ID_PHASE_ALLOCATING;
    if (!hold_namespace(request, r)) {
        if (r->diagnostic.close_fault) {
            *out = r;
            return retain_status(r, ID_RETAINED);
        }
        r->diagnostic.phase = ID_PHASE_BLOCKED;
        r->diagnostic.last_status = ID_INVALID;
        return ID_INVALID;
    }
    struct id_provider_reply reply;
    if (!exchange(r, IDP_ALLOCATE, &reply)) {
        r->diagnostic.retained_debt = ID_ADMIN_DEBT;
        *out = r;
        return r->diagnostic.last_status;
    }
    if (reply.outcome == IDP_POLICY_MISSING || reply.outcome == IDP_BUSY ||
        reply.outcome == IDP_NO_EFFECT) {
        /* By protocol no pair mutation is allowed during ALLOCATE. These
         * are refusals, not successful reservation stubs. A contradictory
         * denial which also claims effects, debt or a ticket is quarantined. */
        if (reply.touched_components || reply.retained_debt ||
            !empty_ticket(&reply.ticket)) {
            r->diagnostic.retained_debt = ID_ADMIN_DEBT;
            *out = r;
            return retain_status(r, ID_RETAINED);
        }
        close_namespace(r);
        if (r->diagnostic.close_fault) {
            *out = r;
            return retain_status(r, ID_RETAINED);
        }
        r->diagnostic.phase = ID_PHASE_BLOCKED;
        r->diagnostic.last_status = reply.outcome == IDP_BUSY ? ID_BUSY : ID_POLICY_BLOCKED;
        return r->diagnostic.last_status;
    }
    if (reply.outcome != IDP_ALLOCATED || !new_ticket(&reply.ticket) ||
        reply.touched_components ||
        reply.retained_debt != ID_DEBT_DURABLE_RECORD) {
        r->diagnostic.retained_debt = ID_ADMIN_DEBT;
        *out = r;
        return outcome_failure(r, reply.outcome);
    }
    r->ticket = reply.ticket;
    r->ticket_valid = 1;
    r->diagnostic.provider_epoch = r->ticket.epoch;
    r->diagnostic.transaction = r->ticket.transaction;
    r->diagnostic.fence = r->ticket.fence;
    r->diagnostic.phase = ID_PHASE_ACQUIRING;
    /* Set UNION debt before the side-effecting provider call. Lost ACK,
     * partial acquisition or stale reply cannot turn it back into free IDs. */
    r->diagnostic.retained_debt = ID_ADMIN_DEBT;
    *out = r;
    if (!exchange(r, IDP_ACQUIRE_PAIR, &reply)) return r->diagnostic.last_status;
    if (reply.outcome != IDP_PAIR_HELD ||
        reply.touched_components != (uint32_t)(ID_DEBT_UID | ID_DEBT_GID) ||
        reply.retained_debt != ID_ADMIN_DEBT)
        return outcome_failure(r, reply.outcome);
    if (local_pair_conflict(r)) return retain_status(r, ID_RETAINED);
    r->pair_complete = 1;
    r->diagnostic.phase = ID_PHASE_RESERVED;
    r->diagnostic.last_status = ID_OK;
    return ID_OK;
}

enum id_status id_poll_authority(id_reservation *handle)
{
    struct id_reservation *r;
    enum id_status status = guard(handle, &r);
    if (status != ID_OK) return status;
    if (r->diagnostic.phase == ID_PHASE_RETIRED) return ID_RETIRED;
    if (!r->ticket_valid || !r->pair_complete) return retain_status(r, ID_RETAINED);
    if (!namespace_current(r)) return retain_status(r, ID_RETAINED);
    struct id_provider_reply reply;
    if (!exchange(r, IDP_CHECK, &reply)) return r->diagnostic.last_status;
    if (reply.outcome != IDP_CURRENT ||
        (reply.retained_debt & r->diagnostic.retained_debt) != r->diagnostic.retained_debt)
        return outcome_failure(r, reply.outcome);
    if (r->ever_retained) return retain_status(r, ID_RETAINED);
    r->diagnostic.last_status = ID_OK;
    return ID_OK;
}

enum id_status id_arm_birth(id_reservation *handle)
{
    struct id_reservation *r;
    enum id_status status = guard(handle, &r);
    if (status != ID_OK) return status;
    if (r->diagnostic.phase != ID_PHASE_RESERVED || r->ever_retained ||
        !r->pair_complete || !r->ticket_valid || r->diagnostic.birth_armed ||
        r->diagnostic.revoked || r->diagnostic.cleanup_deadline_expired)
        return ID_BAD_STATE;
    if (!namespace_current(r)) return retain_status(r, ID_RETAINED);
    /* Spent before ARM. A late/unknown ARM is never retried as a new attempt.
     * Durable provider ARM holds IDs across the following check/clone race. */
    r->diagnostic.birth_armed = 1;
    r->diagnostic.birth_unknown = 1;
    r->diagnostic.retained_debt |= ID_DEBT_CHILD_TREE | ID_DEBT_OUTPUT;
    struct id_provider_reply reply;
    if (!exchange(r, IDP_ARM, &reply)) return r->diagnostic.last_status;
    if (reply.outcome != IDP_ARMED || reply.retained_debt != ID_ALL_DEBT)
        return outcome_failure(r, reply.outcome);
    r->diagnostic.phase = ID_PHASE_ARMED;
    r->diagnostic.last_status = ID_OK;
    return ID_OK;
}

enum id_status id_retain(id_reservation *handle, enum id_reason reason)
{
    struct id_reservation *r;
    enum id_status status = guard(handle, &r);
    if (status != ID_OK) return status;
    if (reason < ID_REASON_CANCEL || reason > ID_REASON_RECOVERY_REQUIRED)
        return ID_INVALID;
    if (r->diagnostic.phase == ID_PHASE_RETIRED &&
        reason != ID_REASON_BIRTH_UNKNOWN && reason != ID_REASON_CLOSE_FAULT)
        return ID_RETIRED;
    r->diagnostic.retention_reasons |= 1u << (reason - 1);
    if (reason == ID_REASON_C_EXPIRED) r->diagnostic.cleanup_deadline_expired = 1;
    if (reason == ID_REASON_BIRTH_UNKNOWN) {
        (void)birth_conflict(r, ID_RETAINED);
    }
    if (reason == ID_REASON_CLOSE_FAULT) r->diagnostic.close_fault = 1;
    (void)retain_status(r, ID_RETAINED);
    if (r->ticket_valid) {
        struct id_provider_reply reply;
        if (!exchange(r, IDP_RETAIN, &reply)) return r->diagnostic.last_status;
        if (reply.outcome != IDP_QUARANTINED ||
            (reply.retained_debt & r->diagnostic.retained_debt) != r->diagnostic.retained_debt)
            return outcome_failure(r, reply.outcome);
    }
    return ID_RETAINED;
}

enum id_status id_observe_original(id_reservation *handle, enum id_original_fact fact)
{
    struct id_reservation *r;
    enum id_status status = guard(handle, &r);
    if (status != ID_OK) return status;
    uint32_t bit = (uint32_t)fact;
    if (!bit || (bit & (bit - 1u)) || (bit & ~ID_KNOWN_FACTS)) return ID_INVALID;
    if (!r->diagnostic.birth_armed || !r->pair_complete ||
        r->diagnostic.phase == ID_PHASE_RETIRED)
        return birth_conflict(r, ID_BAD_STATE);
    if (fact == ID_FACT_BIRTH_FAILED_KNOWN) {
        if (r->birth_conflict || (r->diagnostic.observed_facts & (uint32_t)(ID_FACT_CHILD_BORN |
            ID_FACT_DIRECT_CHILD_REAPED | ID_FACT_STDOUT_EOF | ID_FACT_STDERR_EOF))
            ) return birth_conflict(r, ID_BAD_STATE);
        r->known_no_birth = 1;
        r->diagnostic.birth_unknown = 0;
        r->diagnostic.retained_debt &= ~(uint32_t)(ID_DEBT_CHILD_TREE | ID_DEBT_OUTPUT);
    } else {
        if (r->known_no_birth) return birth_conflict(r, ID_BAD_STATE);
        if (fact != ID_FACT_CHILD_BORN &&
            !(r->diagnostic.observed_facts & ID_FACT_CHILD_BORN))
            return birth_conflict(r, ID_BAD_STATE);
        if (fact == ID_FACT_CHILD_BORN) {
            if (!r->birth_conflict) r->diagnostic.birth_unknown = 0;
            if (!r->ever_retained) r->diagnostic.phase = ID_PHASE_CHILD_HELD;
        }
    }
    r->diagnostic.observed_facts |= bit;
    if (!r->birth_conflict &&
        (r->diagnostic.observed_facts & (uint32_t)(ID_FACT_STDOUT_EOF | ID_FACT_STDERR_EOF)) ==
        (uint32_t)(ID_FACT_STDOUT_EOF | ID_FACT_STDERR_EOF))
        r->diagnostic.retained_debt &= ~(uint32_t)ID_DEBT_OUTPUT;
    /* Direct child reap NEVER clears CHILD_TREE, even with both EOFs. */
    return r->ever_retained ? ID_RETAINED : ID_OK;
}

enum id_status id_try_retire(id_reservation *handle)
{
    struct id_reservation *r;
    enum id_status status = guard(handle, &r);
    if (status != ID_OK) return status;
    if (r->diagnostic.phase == ID_PHASE_RETIRED) return ID_RETIRED;
    if (!r->ticket_valid || !r->pair_complete || r->diagnostic.close_fault ||
        r->birth_conflict ||
        r->diagnostic.birth_unknown ||
        (r->diagnostic.observed_facts & ID_FACT_CHILD_BORN) ||
        (r->diagnostic.birth_armed && !r->known_no_birth) ||
        (r->diagnostic.retained_debt & (uint32_t)(ID_DEBT_CHILD_TREE | ID_DEBT_OUTPUT)))
        return retain_status(r, ID_RETAINED);
    if (!namespace_current(r)) return retain_status(r, ID_RETAINED);
    struct id_provider_reply reply;
    if (!exchange(r, IDP_RETIRE, &reply)) return r->diagnostic.last_status;
    if (reply.outcome != IDP_TOMBSTONED || reply.retained_debt != ID_ADMIN_DEBT)
        return outcome_failure(r, reply.outcome);
    r->diagnostic.pair_permanently_tombstoned = 1;
    close_namespace(r);
    if (r->diagnostic.close_fault) return retain_status(r, ID_RETAINED);
    r->diagnostic.phase = ID_PHASE_RETIRED;
    r->diagnostic.last_status = ID_RETIRED;
    /* Provider owns permanent ID exclusion and all administrative residuals;
     * neither this transition nor process exit makes either number free. */
    r->diagnostic.retained_debt = ID_ADMIN_DEBT;
    return ID_RETIRED;
}

enum id_status id_get_snapshot(const id_reservation *handle, struct id_snapshot *out)
{
    struct id_reservation *r;
    if (!out) return ID_INVALID;
    enum id_status status = guard(handle, &r);
    if (status != ID_OK) return status;
    *out = r->diagnostic;
    return ID_OK;
}

const char *id_status_name(enum id_status status)
{
    switch (status) {
    case ID_OK: return "OK_SOURCE_PROTOCOL";
    case ID_POLICY_BLOCKED: return "POLICY_BLOCKED";
    case ID_INVALID: return "INVALID";
    case ID_BUSY: return "BUSY";
    case ID_RETAINED: return "RETAINED";
    case ID_STALE: return "STALE";
    case ID_REVOKED: return "REVOKED";
    case ID_OWNER_MISMATCH: return "OWNER_MISMATCH";
    case ID_BAD_STATE: return "BAD_STATE";
    case ID_CAPACITY: return "CAPACITY";
    case ID_RETIRED: return "RETIRED_TOMBSTONE_NO_REUSE";
    }
    return "UNKNOWN_STATUS";
}

#if defined(IDENTITY_MODEL_TEST_ONLY)
void id_model_reset(void)
{
    for (unsigned i = 0; i < ID_MAX_ATTEMPTS; ++i)
        if (id_slots[i].used) close_namespace(&id_slots[i]);
    memset(id_slots, 0, sizeof id_slots);
    id_program_owner = 0;
}
#endif
