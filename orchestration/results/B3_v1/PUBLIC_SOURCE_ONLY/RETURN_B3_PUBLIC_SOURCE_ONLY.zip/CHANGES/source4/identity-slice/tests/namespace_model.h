#ifndef B3_NAMESPACE_MODEL_H
#define B3_NAMESPACE_MODEL_H
#if !defined(B3_NAMESPACE_MODEL_ONLY)
#error "namespace_model is test-only; no kernel namespace evidence is produced"
#endif
void namespace_model_reset(void);
void namespace_model_change_current(void);
void namespace_model_change_pid(void);
void namespace_model_fail_close(unsigned calls_from_now);
unsigned namespace_model_open_count(void);
unsigned namespace_model_close_calls(void);
#endif
