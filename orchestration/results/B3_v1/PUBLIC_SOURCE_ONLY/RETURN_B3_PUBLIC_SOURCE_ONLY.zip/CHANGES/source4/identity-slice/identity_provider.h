#ifndef KNOWLEDGE_IDENTITY_SLICE_PROVIDER_H
#define KNOWLEDGE_IDENTITY_SLICE_PROVIDER_H
#include "identity.h"
/* PRIVATE fixed-link protocol. This is NOT a callback registration API, wire
 * decoder, authentication algorithm or proof that administrative policy exists.
 * Production links identity_provider_unavailable.c. A future trusted backend
 * requires independent policy/provenance review and implementation. */
enum id_provider_operation {
    IDP_ALLOCATE = 1, IDP_ACQUIRE_PAIR = 2, IDP_CHECK = 3,
    IDP_ARM = 4, IDP_RETAIN = 5, IDP_RETIRE = 6
};
enum id_provider_outcome {
    IDP_POLICY_MISSING = 1, IDP_ALLOCATED = 2, IDP_PAIR_HELD = 3,
    IDP_CURRENT = 4, IDP_ARMED = 5, IDP_QUARANTINED = 6,
    IDP_TOMBSTONED = 7, IDP_BUSY = 8, IDP_PARTIAL = 9,
    IDP_UNKNOWN = 10, IDP_STALE = 11, IDP_REVOKED = 12,
    IDP_NO_EFFECT = 13
};
struct id_bound_request {
    uint32_t authorized_uid, authorized_gid, ledger_first, ledger_last;
    uint32_t uid, gid;
    unsigned char host_id[16], installation_id[16];
    uint64_t userns_device, userns_inode;
};
struct id_provider_ticket {
    unsigned char issuer_id[16];
    uint64_t epoch, transaction, fence;
};
struct id_provider_call {
    /* Private native identity; a future backend binds this to an authenticated
     * original Main session and durable request, never its address as authority. */
    const void *local_owner;
    enum id_provider_operation operation;
    uint64_t sequence;
    struct id_bound_request request;
    struct id_provider_ticket ticket;
    uint32_t native_facts, retained_debt, retention_reasons;
};
struct id_provider_reply {
    enum id_provider_outcome outcome;
    uint64_t sequence;
    struct id_bound_request request;
    struct id_provider_ticket ticket;
    /* Components touched by an uncertain operation. UNKNOWN means UNION:
     * both uid and gid retained regardless of these diagnostic bits. */
    uint32_t touched_components;
    uint32_t retained_debt;
};
/* ALLOCATE must create/confirm a durable transaction BEFORE any UID/GID side
 * effect; ACQUIRE uses only that exact ticket. Atomic full-pair exclusion
 * includes either-component overlap and all administrator domains. ARM is
 * durable and non-reclaimable across revocation, Main death and epoch change.
 * ALLOCATED has exactly DURABLE_RECORD debt, zero touched components, and a
 * fresh nonzero ticket. Negative ALLOCATE has zero ticket, effects and debt;
 * contradictory denial is quarantined. Issuer epoch applies to its entire
 * administrative collision domain; transaction and fence increase monotonically
 * within an epoch, including after retirement. TOMBSTONED means no future
 * numeric reuse, and provider retains all debt.
 * A reply is trusted only through actual provider provenance, not its fields.
 * This v1 ships no such trusted provisioning implementation. */
void id_provider_step(const struct id_provider_call *call,
                      struct id_provider_reply *reply);
#endif
