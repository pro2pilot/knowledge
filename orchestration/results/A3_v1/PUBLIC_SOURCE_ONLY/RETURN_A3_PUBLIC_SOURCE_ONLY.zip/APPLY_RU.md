# Применение возврата Knowledge A3 v1

## Что применять

Вход закреплён commit `0684ffa0d132675233d7d9602121f02bb50ff6eb`.
Рабочая ветка: `codex/stage-a3-v1-20261103`.
Единственный разрешённый destination prefix: `orchestration/results/A3_v1/`.

Новый commit в этом чате **не создан**: GitHub create_tree вернул
`user rejected MCP tool call`. Ветка после отказа осталась на закреплённом
input commit. Не подставлять его вместо result commit.

Полный приватный ZIP содержит исходные raw, compiler artifacts, test fixtures
и `BASES/input/`. Для repository application использовать отдельный полный
публичный набор `publication/PUBLIC_RESULT/`. Он имеет собственный
`MANIFEST.json`; его пути уже относительны разрешённому result prefix.
Список публикации — `publication/PUBLISH_ALLOWLIST.json`.

## 1. Проверить архив и bases

Проверить SHA основного ZIP по сопровождающему `RETURN_A3_v1_POST_ZIP.zip` и
сообщению передачи. Во втором архиве лежат точный ZIP SHA, CRC result, проверка
всех manifest bytes, свежего применения и отказа при повторном применении,
включая raw argv/stdout/stderr/rc. Он создан после завершения основного ZIP.

Исходный input manifest имеет SHA-256:

```
8ac2c1b86170c70dcee36f5a4fe878688e32f9ca0b7f8032998316fd79a8eb55
```

В нём 59 payload files. `BASES/input/` — точная private копия этих файлов и
manifest. Число дополнительных headers равно 32; поправка оркестратора
сохранена отдельно, исходный PROMPT не редактировался.

## 2. Применить public additions к выбранной ветке

В существующем чистом checkout выбрать назначенную ветку и проверить HEAD.
Если HEAD другой, остановиться и сопоставить изменения: helper не выполняет
автоматическую смену bases или overwrite.

Ниже `A3_RETURN_ROOT` — абсолютный путь к распакованному
`orchestration/results/A3_v1`, `A3_CHECKOUT` — абсолютный путь к чистому checkout.
Эти task-specific variables задаёт оркестратор; HOME не изменяется.

```sh
git -C "$A3_CHECKOUT" switch codex/stage-a3-v1-20261103
git -C "$A3_CHECKOUT" rev-parse HEAD
python3 "$A3_RETURN_ROOT/qualification/apply_results.py" --bundle-root "$A3_RETURN_ROOT/publication/PUBLIC_RESULT" --target-root "$A3_CHECKOUT" --check-only
python3 "$A3_RETURN_ROOT/qualification/apply_results.py" --bundle-root "$A3_RETURN_ROOT/publication/PUBLIC_RESULT" --target-root "$A3_CHECKOUT"
```

Ожидаемый HEAD перед применением:
`0684ffa0d132675233d7d9602121f02bb50ff6eb`.

Helper сначала проверяет весь public bundle manifest, safe portable paths,
отсутствие aliases/symlinks, исходный input manifest и все 59 payload pins.
Все destination collisions проверяются **до первого mkdir/write**. Запись
только exclusive create; existing files не заменяются. При позднем I/O failure
квитанция перечисляет уже созданные paths, automatic deletion отсутствует.
Требуется exclusive cooperative quiescent target; race-proof filesystem
authority этим helper не заявляется.

При успешном применении проверить список additions перед commit:

```sh
git -C "$A3_CHECKOUT" status --short
git -C "$A3_CHECKOUT" add -- orchestration/results/A3_v1
git -C "$A3_CHECKOUT" diff --cached --name-status
```

Каждый staged path должен начинаться с `orchestration/results/A3_v1/` и
совпадать с public allowlist. В этой передаче все repository files являются
additions относительно закреплённого base; product/input edits не предусмотрены.

После независимой проверки оркестратор может создать и отправить commit
только в назначенную ветку:

```sh
git -C "$A3_CHECKOUT" commit -m "A3 v1: qualify full derivative compile and prepare pinned ordinary fixtures"
git -C "$A3_CHECKOUT" rev-parse HEAD
git -C "$A3_CHECKOUT" push origin HEAD:refs/heads/codex/stage-a3-v1-20261103
```

Полученный SHA — будущий result commit; его нельзя предсказать в этом чате.
Merge в main, tags/releases и публикация продукта не поручены. В Pro эти
git write команды не исполнялись и отказ connector не обходился.

## 3. Actions request

Открыть `ACTIONS_REQUEST.json` и `reviews/ACTIONS_SOURCE_REVIEW.json`.
Recipe находится в `qualification/ACTIONS_JOB_RECIPE.yml` как инертный
результат этапа. В `.github/workflows/` он здесь не установлен.

Оркестратор сначала подготавливает PRIVATE collection для raw. Затем он может
использовать recipe в собственном разрешённом execution workflow: стандартный
`ubuntu-24.04`, job cap 10 минут, `permissions: {}`, no secrets/sudo/native
subject. `private_collection_ready=true` означает наличие collector, а не
обещание, что этот recipe сам реализует upload. Public repository artifact
destination не подходит для оригинального private raw.

Recipe не требует new result commit для получения кода: reviewed source ZIP
встроен в него целиком, SHA-256:

```
a3d177ff029979ae21a8f7c04a59acc0796a4af3e671c8d32275ec41e12244fb
```

Он проверяет ZIP SHA/CRC, шесть members и file pins до исполнения. Input
скачивается только из commit `0684ffa0…` и проверяется по точному manifest.
Зависимость от moving branch HEAD отсутствует. Workflow installation и
dispatch выполняет оркестратор за пределами write scope текущего чата.

Самостоятельный ordinary argv из root подготовленного snapshot:

```sh
python3 orchestration/results/A3_v1/qualification/ordinary_run.py --input-dir orchestration/stages/A3_qualification_v1/input --output-dir "$RUNNER_TEMP/a3-ordinary" --review-json orchestration/results/A3_v1/qualification/ordinary_review.json
```

В текущем Pro это **не запускать повторно**: EUID/EGID0 уже зафиксирован.
Код 77 хранить как BLOCKED/partial blocker; отсутствие run никогда не PASS.

## 4. Scope повторной проверки

Нужны новые отсутствующие output directories. Compile/model commands находятся
в `compile_NOTES_RU.md` и `MODEL_NOTES_RU.md`; они не являются release gate.
Возможен replay из private `BASES/input/`. Полный offer/release остаётся
`EOPNOTSUPP`; core/intake identity policy не менять ради PASS.
