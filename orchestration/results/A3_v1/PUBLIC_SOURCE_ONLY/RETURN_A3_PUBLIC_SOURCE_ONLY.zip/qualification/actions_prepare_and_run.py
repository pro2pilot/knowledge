#!/usr/bin/env python3
"""Pinned, tokenless hosted-runner bootstrap. NOT executed in Pro.

Only the six embedded source-package members and 59 original manifest files
are materialized. No git history, repository checkout, credentials or native
subject is used. All bytes are verified before the ordinary Python entry.
"""
from __future__ import annotations

import argparse
import base64
import concurrent.futures
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import urllib.request
import zipfile


INPUT_COMMIT = "0684ffa0d132675233d7d9602121f02bb50ff6eb"
INPUT_MANIFEST_SHA256 = "8ac2c1b86170c70dcee36f5a4fe878688e32f9ca0b7f8032998316fd79a8eb55"
SOURCE_ZIP_SHA256 = "a3d177ff029979ae21a8f7c04a59acc0796a4af3e671c8d32275ec41e12244fb"
CODE_PINS_SHA256 = "c587873f8e7c5c43a74bf0c057ddf466e151cadb33547572a14c7742dafe2c08"
BASE_URL = "https://raw.githubusercontent.com/pro2pilot/knowledge/" + INPUT_COMMIT + "/orchestration/stages/A3_qualification_v1/input/"
EXPECTED_CODE_NAMES = {
    "qualification/ACTIONS_CODE_PINS.json", "qualification/ordinary_run.py",
    "qualification/ordinary_socket_fixtures.py", "qualification/ordinary_review.json",
    "qualification/public_evidence.py", "qualification/actions_entry.py",
}


def digest(data: bytes) -> dict:
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def safe_name(name: str) -> tuple[str, ...]:
    path = PurePosixPath(name)
    if path.is_absolute() or "\\" in name or ":" in name or str(path) != name or any(
            p in ("", ".", "..") for p in name.split("/")):
        raise ValueError("unsafe source member")
    return path.parts


def fetch(name: str, expected: dict | None = None) -> bytes:
    safe_name(name)
    with urllib.request.urlopen(BASE_URL + name, timeout=15) as response:
        data = response.read(1_048_577)
    if len(data) > 1_048_576:
        raise ValueError("input download exceeds bounded source-only size")
    if expected is not None and digest(data) != expected:
        raise ValueError("downloaded source pin mismatch: " + name)
    return data


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--payload-file", required=True, type=Path)
    parser.add_argument("--stage-root", required=True, type=Path)
    args = parser.parse_args()
    root = args.stage_root.resolve()
    if args.payload_file.resolve().is_relative_to(root):
        parser.error("payload-file must be outside the fresh stage root")
    evidence = root / "bootstrap-evidence"
    root_created = evidence_created = False
    report = {"schema": "knowledge-a3-v1-pinned-bootstrap.v1", "result": "IN_PROGRESS",
              "input_commit": INPUT_COMMIT, "native_Main_H_Node_bundle": "NOT_RUN",
              "tokenless_public_source_download": True, "code_commit": None,
              "code_provenance": "exact embedded source ZIP and file SHA pins; GitHub write was blocked"}
    try:
        root.mkdir(parents=True, exist_ok=False)
        root_created = True
        evidence.mkdir()
        evidence_created = True
        encoded = args.payload_file.read_bytes()
        if len(encoded) > 200_000:
            raise ValueError("embedded package exceeds size bound")
        package = base64.b64decode(encoded, validate=True)
        if hashlib.sha256(package).hexdigest() != SOURCE_ZIP_SHA256:
            raise ValueError("embedded source package digest mismatch")
        result_root = root / "orchestration/results/A3_v1"
        with zipfile.ZipFile(io.BytesIO(package)) as z:
            members = z.infolist()
            if len(members) != 6 or {x.filename for x in members} != EXPECTED_CODE_NAMES:
                raise ValueError("embedded source package member set mismatch")
            if z.testzip() is not None:
                raise ValueError("embedded source package CRC mismatch")
            pins_bytes = z.read("qualification/ACTIONS_CODE_PINS.json")
            if hashlib.sha256(pins_bytes).hexdigest() != CODE_PINS_SHA256:
                raise ValueError("code pins document digest mismatch")
            pins = json.loads(pins_bytes)["code_files"]
            if set(pins) != EXPECTED_CODE_NAMES - {"qualification/ACTIONS_CODE_PINS.json"}:
                raise ValueError("code file pin set mismatch")
            for item in members:
                if not stat.S_ISREG(item.external_attr >> 16) or item.file_size > 100_000:
                    raise ValueError("embedded member is not a bounded regular file")
                data = z.read(item)
                if item.filename in pins and digest(data) != pins[item.filename]:
                    raise ValueError("embedded code byte pin mismatch")
                destination = result_root.joinpath(*safe_name(item.filename))
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(data)
        manifest_bytes = fetch("MANIFEST.json", {"bytes": 10003, "sha256": INPUT_MANIFEST_SHA256})
        input_root = root / "orchestration/stages/A3_qualification_v1/input"
        input_root.mkdir(parents=True)
        (input_root / "MANIFEST.json").write_bytes(manifest_bytes)
        inputs = json.loads(manifest_bytes)["files"]
        if len(inputs) != 59 or sum(p["bytes"] for p in inputs.values()) != 502074:
            raise ValueError("pinned input inventory mismatch")
        def materialize(item):
            name, pin = item
            data = fetch(name, pin)
            destination = input_root.joinpath(*safe_name(name))
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
            return name
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            acquired = list(pool.map(materialize, inputs.items()))
        report["input_files_verified"] = len(acquired)
        report["source_archive"] = digest(package)
        output = root / "artifacts"
        argv = [sys.executable, "-I", "-B", str(result_root / "qualification/actions_entry.py"),
                "--input-dir", str(input_root), "--output-dir", str(output)]
        report["argv"] = argv
        report["timeout_seconds"] = 150
        try:
            completed = subprocess.run(argv, stdin=subprocess.DEVNULL, capture_output=True,
                env={"PATH": os.defpath, "LANG": "C", "LC_ALL": "C"}, timeout=150, check=False)
            rc, stdout, stderr = completed.returncode, completed.stdout, completed.stderr
        except subprocess.TimeoutExpired as exc:
            rc, stdout, stderr = 124, exc.stdout or b"", exc.stderr or b""
        except OSError as exc:
            rc, stdout, stderr = 125, b"", str(exc).encode()
        (evidence / "entry.stdout.raw").write_bytes(stdout)
        (evidence / "entry.stderr.raw").write_bytes(stderr)
        report.update(rc=rc, result="ORDINARY_REQUEST_COMPLETED" if rc == 0 else
                      "BLOCKED" if rc == 77 else "FAIL")
    except Exception as exc:
        rc = 1
        report.update(rc=rc, result="FAIL_BOOTSTRAP", error=type(exc).__name__ + ": " + str(exc))
    names = ["knowledge-a3-v1-ordinary-private-raw.zip", "knowledge-a3-v1-ordinary-public-redacted.zip"]
    report["artifact_presence"] = {}
    for name in names:
        path = root / "artifacts" / name
        exists = root_created and path.is_file()
        report["artifact_presence"][name] = {"created": exists}
        if exists:
            report["artifact_presence"][name].update(digest(path.read_bytes()))
    if evidence_created:
        (evidence / "RESULT.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"result": report["result"], "rc": rc,
          "source_zip_sha256": SOURCE_ZIP_SHA256,
          "expected_artifacts": names, "artifact_presence": report["artifact_presence"],
          "private_collection": "REQUIRED_BEFORE_RUNNER_TEARDOWN; no upload implemented"}))
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
