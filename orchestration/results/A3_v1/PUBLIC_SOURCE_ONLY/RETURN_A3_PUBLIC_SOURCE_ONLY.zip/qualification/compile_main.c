/* A3 QUALIFICATION ONLY: include the complete, byte-pinned private Main.
 * No executable entry, link, native invocation or production API is added.
 * Typed address references retain unchanged core/intake entry bodies at -O2.
 * They are private data, never an ownership/identity/offer constructor. */
#include "source4/intake-slice/private-main-intake.c"

struct a3_core_references {
    int (*spawn)(void);
    int (*release)(void);
    int (*cancel)(void);
    int (*progress)(void);
    int (*finish)(void);
    void (*stop)(void);
    int (*drop_checked)(const struct mh_slot *, int, int, int);
};
static const struct a3_core_references a3_core_keep
    __attribute__((used)) = {
        mh_spawn_original, mh_release_original, mh_cancel_original,
        mh_progress_original, mh_finish_original, mh_stop_original,
        mh_child_drop_checked
    };

struct a3_intake_references {
    int (*capture)(int, const struct mi_admin *);
    int (*accept_original)(void);
    int (*receive_original)(void);
    int (*cancel_original)(void);
    int (*finish_original)(void);
    int (*core_offer_original)(void);
    void (*stop_original)(void);
    int (*private_main)(int, char **);
};
static const struct a3_intake_references a3_intake_keep
    __attribute__((used)) = {
        mi_main_capture, mi_accept_original, mi_receive_original,
        mi_cancel_original, mi_finish_original, mi_core_offer_original,
        mi_stop_original, mi_private_main_source_only
    };
