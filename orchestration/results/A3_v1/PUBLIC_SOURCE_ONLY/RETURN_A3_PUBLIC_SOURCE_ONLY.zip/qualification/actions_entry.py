#!/usr/bin/env python3
"""One bounded hosted-runner request entry; ordinary fixtures only.

The orchestrator must provide the exact pinned source-only inputs and reviewed
qualification files. This script never installs/dispatches a workflow, uploads
anything, calls git, or runs Node/native Main/H/bundle. It prepares two explicitly
different archives for the orchestrator's private/public artifact routing.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile


RAW_NAME = "knowledge-a3-v1-ordinary-private-raw.zip"
PUBLIC_NAME = "knowledge-a3-v1-ordinary-public-redacted.zip"


def pin(path: Path) -> dict:
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def archive_tree(root: Path, archive: Path) -> None:
    with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(root.rglob("*")):
            if path.is_symlink():
                raise ValueError("symlink in fixture evidence")
            if path.is_file():
                z.write(path, path.relative_to(root))
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise ValueError("raw evidence ZIP CRC failure")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=False)
    raw = output / "private-raw"
    raw.mkdir()
    env = {"PATH": os.defpath, "LANG": "C", "LC_ALL": "C", "PYTHONDONTWRITEBYTECODE": "1"}
    argv = [sys.executable, "-B", str(here / "ordinary_run.py"),
            "--input-dir", str(args.input_dir.resolve()),
            "--output-dir", str(raw / "ordinary"),
            "--review-json", str(here / "ordinary_review.json")]
    started = time.monotonic_ns()
    try:
        completed = subprocess.run(argv, stdin=subprocess.DEVNULL, capture_output=True,
                                   env=env, timeout=90, check=False)
        rc, stdout, stderr = completed.returncode, completed.stdout, completed.stderr
    except subprocess.TimeoutExpired as exc:
        rc, stdout, stderr = 124, exc.stdout or b"", exc.stderr or b""
    except OSError as exc:
        rc, stdout, stderr = 125, b"", str(exc).encode("utf-8")
    (raw / "runner.stdout.raw").write_bytes(stdout)
    (raw / "runner.stderr.raw").write_bytes(stderr)
    (raw / "JOB_COMMAND.json").write_text(json.dumps({"schema": "a3-actions-command.v1",
        "argv": argv, "rc": rc, "timeout_seconds": 90,
        "duration_ns": time.monotonic_ns() - started,
        "finished_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "classification": "ORDINARY_FIXTURE_REQUEST_ONLY", "native_Main_H_Node_bundle": "NOT_RUN",
        "original_raw_visibility": "PRIVATE_COLLECTION_REQUIRED"}, indent=2) + "\n")
    raw_archive = output / RAW_NAME
    archive_tree(raw, raw_archive)
    public_archive = output / PUBLIC_NAME
    redact_argv = [sys.executable, "-B", str(here / "public_evidence.py"),
        "--source", str(raw), "--output", str(output / "public-redacted"),
        "--archive", str(public_archive), "--workspace-root", str(output.parent)]
    try:
        sanitized = subprocess.run(redact_argv, stdin=subprocess.DEVNULL, capture_output=True,
                                   env=env, timeout=45, check=False)
        redact_rc, redact_stdout, redact_stderr = sanitized.returncode, sanitized.stdout, sanitized.stderr
    except subprocess.TimeoutExpired as exc:
        redact_rc, redact_stdout, redact_stderr = 124, exc.stdout or b"", exc.stderr or b""
    except OSError as exc:
        redact_rc, redact_stdout, redact_stderr = 125, b"", str(exc).encode("utf-8")
    (output / "redaction.stdout.raw").write_bytes(redact_stdout)
    (output / "redaction.stderr.raw").write_bytes(redact_stderr)
    status = {"schema": "a3-actions-artifact-routing.v1", "ordinary_rc": rc,
              "redaction_rc": redact_rc, "scope": "this invocation; no inferred original WSL/profile proof",
              "private_archive": {"name": RAW_NAME, **pin(raw_archive),
                  "routing": "ORCHESTRATOR_PRIVATE_DESTINATION_ONLY; do not upload to a public repository"},
              "public_archive": None, "native_Main_H_Node_bundle": "NOT_RUN",
              "collection_status": "NOT_UPLOADED; orchestrator must collect before runner teardown"}
    if redact_rc == 0 and public_archive.is_file():
        status["public_archive"] = {"name": PUBLIC_NAME, **pin(public_archive),
                                     "routing": "EXPLICITLY_PUBLIC_REDACTED_COPY"}
    (output / "ARTIFACT_ROUTING.json").write_text(json.dumps(status, indent=2) + "\n")
    # Only names/digests/statuses in workflow logs; raw outputs remain files.
    print(json.dumps(status, sort_keys=True))
    return rc if redact_rc == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
