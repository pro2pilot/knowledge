#!/usr/bin/env python3
"""Validate and copy an A3 result bundle as NEW files under its fixed stage path.

This is an offline filesystem operation: no network, git mutation, build or
native execution. The caller chooses the assigned branch or a fresh snapshot.
Use a cooperative, quiescent source and target tree; pre-existing symlinks and
reparse points are refused, but concurrent namespace mutation is not attested.
All inputs/collisions are checked before the first write. Late errors report
every created file/directory; there is no overwrite and no automatic deletion.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import unicodedata

SCHEMA = "knowledge-a3-v1-return-manifest.v1"
INPUT_MANIFEST_SHA256 = "8ac2c1b86170c70dcee36f5a4fe878688e32f9ca0b7f8032998316fd79a8eb55"
INPUT_PREFIX = PurePosixPath("orchestration/stages/A3_qualification_v1/input")
RESULT_PREFIX = PurePosixPath("orchestration/results/A3_v1")
RESERVED = {"CON", "PRN", "AUX", "NUL", "CLOCK$", *[f"COM{i}" for i in range(1, 10)],
            *[f"LPT{i}" for i in range(1, 10)]}


def require(condition: bool, reason: str) -> None:
    if not condition:
        raise ValueError(reason)


def digest(data: bytes) -> dict:
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def unique_object(pairs: list[tuple]) -> dict:
    result = {}
    for name, value in pairs:
        require(name not in result, "duplicate JSON object key: " + str(name))
        result[name] = value
    return result


def json_object(raw: bytes) -> dict:
    obj = json.loads(raw, object_pairs_hook=unique_object)
    require(isinstance(obj, dict), "manifest must be a JSON object")
    return obj


def safe_name(name: str) -> tuple[str, ...]:
    require(isinstance(name, str) and bool(name), "empty/non-string member name")
    require(not name.startswith("/") and "\\" not in name and ":" not in name,
            "absolute, drive, backslash or colon member: " + name)
    parts = name.split("/")
    for p in parts:
        require(p not in ("", ".", "..") and p[-1] not in (" ", "."),
                "noncanonical or ambiguous member: " + name)
        require(not any(ord(c) < 32 or ord(c) == 127 for c in p), "control character in member")
        require(not any(c in '<>"|?*' for c in p), "nonportable member: " + name)
        require(p.split(".", 1)[0].upper() not in RESERVED, "reserved device member: " + name)
    require(str(PurePosixPath(name)) == name, "noncanonical member: " + name)
    return tuple(parts)


def validate_file_map(files: object, self_excluded: bool) -> dict:
    require(isinstance(files, dict) and bool(files), "manifest files must be a nonempty object")
    aliases = {}
    for name, info in files.items():
        parts = safe_name(name)
        if self_excluded:
            require(parts[0].casefold() != "manifest.json", "MANIFEST.json must exclude itself and cannot be a directory")
        require(isinstance(info, dict) and type(info.get("bytes")) is int
                and info["bytes"] >= 0 and isinstance(info.get("sha256"), str)
                and re.fullmatch(r"[0-9a-f]{64}", info["sha256"]) is not None,
                "invalid byte/digest pin: " + name)
        for i in range(1, len(parts)+1):
            original = "/".join(parts[:i])
            key = unicodedata.normalize("NFC", original).casefold()
            require(key not in aliases or aliases[key] == original,
                    "case-insensitive path alias: " + name)
            aliases[key] = original
        for i in range(1, len(parts)):
            require("/".join(parts[:i]) not in files, "file is also a parent directory: " + name)
    return files


def no_link(st: os.stat_result, label: str) -> None:
    require(not stat.S_ISLNK(st.st_mode), "symlink refused: " + label)
    reparse = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    require(not (getattr(st, "st_file_attributes", 0) & reparse), "reparse point refused: " + label)


def inspect_chain(path: Path, leaf: str, allow_missing: bool = False) -> bool:
    """Inspect each existing path component without resolving away symlinks."""
    chain = list(reversed(path.parents)) + [path]
    missing = False
    for component in chain:
        try:
            st = component.lstat()
        except FileNotFoundError:
            require(allow_missing, "missing path: " + str(component))
            missing = True
            continue
        require(not missing, "path appeared beneath missing parent: " + str(component))
        no_link(st, str(component))
        expected_directory = component != path or leaf == "directory"
        require(stat.S_ISDIR(st.st_mode) if expected_directory else stat.S_ISREG(st.st_mode),
                "unexpected file type: " + str(component))
    return not missing


def read_regular(path: Path) -> bytes:
    inspect_chain(path, "file")
    return path.read_bytes()


def read_bundle(root: Path) -> tuple[bytes, dict, dict[str, bytes]]:
    inspect_chain(root, "directory")
    raw = read_regular(root / "MANIFEST.json")
    manifest = json_object(raw)
    require(manifest.get("schema") == SCHEMA, "unexpected result manifest schema")
    files = validate_file_map(manifest.get("files"), True)
    observed = set()
    for current, dirs, names in os.walk(root, followlinks=False):
        current = Path(current)
        for name in dirs:
            inspect_chain(current / name, "directory")
        for name in names:
            path = current / name
            relative = path.relative_to(root).as_posix()
            safe_name(relative)
            inspect_chain(path, "file")
            observed.add(relative)
    require(observed == set(files) | {"MANIFEST.json"},
            "bundle file set differs from manifest: missing=" + repr(sorted(set(files) - observed))
            + "; extra=" + repr(sorted(observed - set(files) - {"MANIFEST.json"})))
    payloads = {}
    for name, info in files.items():
        data = read_regular(root.joinpath(*safe_name(name)))
        require(digest(data) == {"bytes": info["bytes"], "sha256": info["sha256"]},
                "result byte/digest mismatch: " + name)
        payloads[name] = data
    # Preserve the exact reviewed manifest bytes, without a self-referential pin.
    payloads["MANIFEST.json"] = raw
    return raw, files, payloads


def verify_input(target: Path) -> int:
    root = target.joinpath(*INPUT_PREFIX.parts)
    raw = read_regular(root / "MANIFEST.json")
    require(digest(raw)["sha256"] == INPUT_MANIFEST_SHA256, "target input manifest digest mismatch")
    files = validate_file_map(json_object(raw).get("files"), True)
    require(len(files) == 59, "target input manifest must contain 59 payload files")
    for name, info in files.items():
        actual = digest(read_regular(root.joinpath(*safe_name(name))))
        require(actual == {"bytes": info["bytes"], "sha256": info["sha256"]},
                "target input byte/digest mismatch: " + name)
    return len(files)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--bundle-root", type=Path, required=True)
    ap.add_argument("--target-root", type=Path, required=True)
    ap.add_argument("--check-only", action="store_true")
    args = ap.parse_args()
    # abspath normalizes caller roots without following symlinks; inspect_chain
    # then checks every actual component, including the supplied root itself.
    bundle = Path(os.path.abspath(args.bundle_root))
    target = Path(os.path.abspath(args.target_root))
    destination = target.joinpath(*RESULT_PREFIX.parts)
    report = {"schema": "knowledge-a3-v1-apply-receipt.v1", "check_only": args.check_only,
              "result_prefix": RESULT_PREFIX.as_posix(), "created_files": [], "created_directories": [],
              "native_execution": "NOT_RUN", "git_network_operations": "NOT_RUN",
              "branch_selection": "CALLER_ASSIGNED_BRANCH_OR_FRESH_SNAPSHOT",
              "target_namespace_premise": "EXCLUSIVE_COOPERATIVE_QUIESCENT_TREE"}
    try:
        inspect_chain(target, "directory")
        raw, files, payloads = read_bundle(bundle)
        report["bundle_manifest"] = digest(raw)
        report["target_input_files_verified"] = verify_input(target)
        report["result_payload_files"] = len(files)
        # Precheck the complete target set, including the manifest, before mkdir
        # or opening any output. A collision in the last member writes nothing.
        planned = []
        for name in sorted(payloads):
            path = destination.joinpath(*safe_name(name))
            inspect_chain(path.parent, "directory", allow_missing=True)
            try:
                path.lstat()
            except FileNotFoundError:
                pass
            else:
                raise ValueError("target collision; no overwrite: " + str(path))
            planned.append((name, path))
        if args.check_only:
            report["result"] = "PASS_CHECK_ONLY"
        else:
            # Files are held as verified bytes in memory, avoiding a second
            # source read after validation. Parents are rechecked before use.
            for name, path in planned:
                inspect_chain(path.parent, "directory", allow_missing=True)
                for directory in reversed(path.parent.parents):
                    if directory == target or directory.is_relative_to(target):
                        if not directory.exists():
                            directory.mkdir()
                            report["created_directories"].append(str(directory.relative_to(target)))
                if not path.parent.exists():
                    path.parent.mkdir()
                    report["created_directories"].append(str(path.parent.relative_to(target)))
                inspect_chain(path.parent, "directory")
                with path.open("xb") as out:
                    report["created_files"].append(name)
                    out.write(payloads[name])
                require(digest(read_regular(path)) == digest(payloads[name]),
                        "new destination verification failed: " + name)
            report["result"] = "APPLIED_NEW_FILES_ONLY"
        report["files_untouched_on_preflight_failure"] = True
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, TypeError, KeyError) as exc:
        report["result"] = "PARTIAL_APPLY" if report["created_files"] or report["created_directories"] else "BLOCKED_NO_WRITES"
        report["reason"] = str(exc)
        report["files_untouched_on_preflight_failure"] = not (report["created_files"] or report["created_directories"])
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
