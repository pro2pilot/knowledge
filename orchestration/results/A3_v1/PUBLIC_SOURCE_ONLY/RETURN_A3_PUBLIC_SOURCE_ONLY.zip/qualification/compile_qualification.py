#!/usr/bin/env python3
"""Compile the full pinned A2 derivative in a private A3 qualification overlay.

Only cc -c, preprocessing and read-only binary inspection are used. This runner
never links or executes native Main/H, any emitted object, Node or a bundle.
Each output directory is new. All subprocess stdout/stderr/return codes persist.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shlex
import shutil
import subprocess
import sys
import time

INPUT_COMMIT = "0684ffa0d132675233d7d9602121f02bb50ff6eb"
MANIFEST_SHA256 = "8ac2c1b86170c70dcee36f5a4fe878688e32f9ca0b7f8032998316fd79a8eb55"
CORE = ["mh_spawn_original", "mh_release_original", "mh_cancel_original",
        "mh_progress_original", "mh_finish_original", "mh_stop_original",
        "mh_child_drop_checked"]
INTAKE = ["mi_main_capture", "mi_accept_original", "mi_receive_original",
          "mi_cancel_original", "mi_finish_original", "mi_core_offer_original",
          "mi_stop_original", "mi_private_main_source_only"]
FLAGS = ["-std=c11", "-Wall", "-Wextra", "-Werror", "-Wpedantic", "-O2",
         "-fno-builtin", "-save-temps=obj"]


def pin(data: bytes) -> dict:
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def checked_input(source: Path) -> tuple[bytes, dict]:
    raw = (source / "MANIFEST.json").read_bytes()
    require(pin(raw)["sha256"] == MANIFEST_SHA256, "input manifest digest mismatch")
    files = json.loads(raw)["files"]
    for name, expected in files.items():
        p = source / name
        require(not Path(name).is_absolute() and ".." not in Path(name).parts,
                "unsafe manifest member")
        require(not p.is_symlink(), "symlink input: " + name)
        require(p.resolve().is_relative_to(source), "input escape: " + name)
        require(pin(p.read_bytes()) == expected, "input pin mismatch: " + name)
    dependency_pins = json.loads((source / "DEPENDENCY_PINS.json").read_bytes())["files"]
    require(all(files.get(name) == value for name, value in dependency_pins.items()),
            "dependency manifest disagrees with main manifest")
    return raw, files


def symbols_from_readelf(text: str) -> dict:
    records = {}
    for line in text.splitlines():
        cells = line.split()
        if len(cells) == 8 and cells[0].endswith(":") and cells[0][:-1].isdigit():
            records[cells[7]] = {"address": int(cells[1], 16), "bytes": int(cells[2]),
                                "type": cells[3], "binding": cells[4],
                                "visibility": cells[5], "section": cells[6]}
    return records


def check_native_symbols(records: dict, text_section: str) -> dict:
    for name in CORE + INTAKE:
        r = records.get(name, {})
        require(r.get("type") == "FUNC" and r.get("binding") == "LOCAL"
                and r.get("section") == text_section and r.get("bytes", 0) > 0,
                "native body is absent, nonlocal, undefined, non-text or empty: " + name)
    require("main" not in records and "_start" not in records,
            "executable entry exists")
    exported = [name for name, r in records.items()
                if r["section"] != "UND" and r["binding"] in ("GLOBAL", "WEAK")]
    require(not exported, "unexpected exported definition: " + repr(exported))
    return {name: records[name] for name in CORE + INTAKE}


def dependency_records(dep_text: str, frozen: Path, files: dict, wrapper_pin: dict,
                       system_roots: list[Path]) -> list[dict]:
    require(dep_text.startswith("a3_native_object:"), "unexpected dependency target")
    names = shlex.split(dep_text.split(":", 1)[1].replace("\\\n", ""))
    rows, seen = [], set()
    for name in names:
        p = (frozen / name).resolve()
        if p in seen:
            continue
        seen.add(p)
        actual = pin(p.read_bytes())
        if p.is_relative_to(frozen):
            relative = p.relative_to(frozen).as_posix()
            expected = wrapper_pin if relative == "qualification/compile_main.c" else files.get(relative)
            require(expected is not None and actual == expected,
                    "unpinned or altered project dependency: " + relative)
            rows.append({"kind": "qualification" if relative.startswith("qualification/") else "pinned-input",
                         "path": relative, **actual})
        else:
            require(any(p.is_relative_to(r) for r in system_roots),
                    "dependency outside frozen input and compiler system roots: " + str(p))
            rows.append({"kind": "compiler-system-header", "path": str(p), **actual})
    required = {"source4/intake-slice/private-main-intake.c",
                "source4/main-h-birth-core.inc", "source4/intake-slice/main-intake.inc",
                "source4/BASE_MAIN/verification-linux-service-configuration.h",
                "source4/BASE_MAIN/verification-linux-service-runtime-front.h",
                "source4/BASE_MAIN/verification-linux-service-daemon.h"}
    require(required <= {r["path"] for r in rows}, "incomplete full derivative dependency set")
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--compiler", default="cc")
    args = parser.parse_args()
    source, output = args.input.resolve(), args.output.resolve()
    require(not output.is_relative_to(source), "output must be outside immutable input")
    output.mkdir(parents=True, exist_ok=False)
    (output / "tmp").mkdir()
    (output / "build").mkdir()
    report = {"schema": "a3-full-derivative-compile.v1", "input_commit": INPUT_COMMIT,
              "input_manifest_sha256": MANIFEST_SHA256,
              "classification": "FULL_TRANSLATION_UNIT_COMPILE_ONLY",
              "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
              "python": sys.version, "system": platform.system(), "machine": platform.machine(),
              "native_Main_H": "NOT_RUN", "Node_bundle": "NOT_RUN",
              "native_link": "NOT_RUN", "physical_proof": False, "release_pass": False,
              "flags": FLAGS, "commands": [], "result": "IN_PROGRESS"}
    environment = {"PATH": os.environ.get("PATH", os.defpath), "LANG": "C", "LC_ALL": "C",
                   "TMPDIR": str(output / "tmp")}

    def persist() -> None:
        (output / "RESULT.json").write_text(json.dumps(report, indent=2) + "\n")

    def run(label: str, argv: list[str], cwd: Path, timeout: int = 45) -> tuple[int, bytes, bytes]:
        prefix = f"{len(report['commands']):02d}-{label}"
        row = {"label": label, "argv": argv, "cwd": str(cwd), "timeout_seconds": timeout,
               "stdout": prefix + ".stdout.bin", "stderr": prefix + ".stderr.bin",
               "started_utc": dt.datetime.now(dt.timezone.utc).isoformat()}
        start = time.monotonic_ns()
        try:
            p = subprocess.run(argv, cwd=cwd, env=environment, capture_output=True,
                               timeout=timeout, check=False)
            rc, stdout, stderr = p.returncode, p.stdout, p.stderr
        except subprocess.TimeoutExpired as exc:
            rc, stdout, stderr = 124, exc.stdout or b"", exc.stderr or b""
            row["timed_out"] = True
        except OSError as exc:
            rc, stdout, stderr = 125, b"", str(exc).encode()
            row["invocation_error"] = type(exc).__name__
        row.update(rc=rc, duration_ns=time.monotonic_ns()-start)
        (output / row["stdout"]).write_bytes(stdout)
        (output / row["stderr"]).write_bytes(stderr)
        report["commands"].append(row)
        persist()
        return rc, stdout, stderr

    try:
        require(platform.system() == "Linux" and platform.machine() in ("x86_64", "amd64"),
                "Linux x86_64 compiler/header environment required")
        raw, files = checked_input(source)
        frozen = output / "frozen"
        frozen.mkdir()
        for name in files:
            p = frozen / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes((source / name).read_bytes())
        (frozen / "MANIFEST.json").write_bytes(raw)
        wrapper = Path(__file__).with_name("compile_main.c")
        wrapper_bytes = wrapper.read_bytes()
        wrapper_pin = pin(wrapper_bytes)
        (frozen / "qualification").mkdir()
        (frozen / "qualification/compile_main.c").write_bytes(wrapper_bytes)
        report["qualification_pins"] = {"compile_main.c": wrapper_pin,
                                        Path(__file__).name: pin(Path(__file__).read_bytes())}
        report["input_file_count"] = len(files)
        report["deps_file_count"] = sum(name.startswith("deps/") for name in files)
        report["base_core_intake_changed"] = False
        programs = {"cc": shutil.which(args.compiler), "nm": shutil.which("nm"),
                    "readelf": shutil.which("readelf"), "objdump": shutil.which("objdump")}
        require(all(programs.values()), "compiler, nm, readelf and objdump required")
        for name, command in programs.items():
            require(run(name + "-version", [command, "--version"], frozen)[0] == 0,
                    name + " version failed")
        rc, _, search_raw = run("compiler-system-include-roots",
                                [programs["cc"], "-E", "-v", "-x", "c", "/dev/null"], frozen)
        require(rc == 0, "cannot inspect compiler include roots")
        search = search_raw.decode().split("#include <...> search starts here:", 1)
        require(len(search) == 2, "unrecognized compiler system include search report")
        roots = [Path(line.strip()).resolve() for line in search[1].split("End of search list.", 1)[0].splitlines()
                 if line.strip() and Path(line.strip()).is_dir()]
        require(bool(roots), "no compiler system include roots")
        require(not any(r.is_relative_to(source) or r.is_relative_to(output) for r in roots),
                "project directory appears as compiler system include root")
        report["compiler_system_include_roots"] = [str(r) for r in roots]
        require(run("exact-derivative-reproduction",
                    [sys.executable, "source4/intake-slice/derive_main.py", "--check"], frozen)[0] == 0,
                "original derivative/receipt byte reproduction failed")
        argv = [programs["cc"], *FLAGS, "-MD", "-MF", "../build/full.d", "-MT", "a3_native_object",
                "-I", ".", "-I", "source4/BASE_MAIN", "-I", "deps", "-c",
                "qualification/compile_main.c", "-o", "../build/full.o"]
        require(run("full-derivative-compile", argv, frozen)[0] == 0,
                "strict full derivative compile failed")
        deps = dependency_records((output / "build/full.d").read_text(), frozen, files, wrapper_pin, roots)
        (output / "DEPENDENCIES.json").write_text(json.dumps(deps, indent=2) + "\n")
        report["resolved_dependencies"] = {"total": len(deps),
             "pinned_input": sum(r["kind"] == "pinned-input" for r in deps),
             "compiler_system_headers": sum(r["kind"] == "compiler-system-header" for r in deps),
             "qualification": sum(r["kind"] == "qualification" for r in deps)}
        outputs = {}
        for label, argv in [
            ("nm-defined-and-undefined", [programs["nm"], "-a", "-S", "../build/full.o"]),
            ("elf-header", [programs["readelf"], "-hW", "../build/full.o"]),
            ("elf-sections", [programs["readelf"], "-SW", "../build/full.o"]),
            ("elf-symbols", [programs["readelf"], "-sW", "../build/full.o"]),
            ("elf-relocations", [programs["readelf"], "-rW", "../build/full.o"]),
            ("native-disassembly", [programs["objdump"], "-dr", "../build/full.o"]),
        ]:
            rc, out, _ = run(label, argv, frozen)
            require(rc == 0, "binary inspection failed: " + label)
            outputs[label] = out.decode()
        require("REL (Relocatable file)" in outputs["elf-header"] and "ELF64" in outputs["elf-header"],
                "native output is not an ELF64 relocatable object")
        match = re.search(r"\[\s*(\d+)\]\s+\.text\s+PROGBITS\s+\S+\s+\S+\s+\S+\s+\S+\s+AX\b", outputs["elf-sections"])
        require(match is not None, "native executable .text section missing")
        text_section = match.group(1)
        records = symbols_from_readelf(outputs["elf-symbols"])
        bodies = check_native_symbols(records, text_section)
        for name in bodies:
            require(re.search(r"^[0-9a-f]+ <" + re.escape(name) + r">:$",
                              outputs["native-disassembly"], re.MULTILINE) is not None,
                    "native disassembly body missing: " + name)
        sections = {}
        for m in re.finditer(r"\[\s*(\d+)\]\s+(\S+)\s+", outputs["elf-sections"]):
            sections[m.group(1)] = m.group(2)
        relocations, current_section = {}, None
        for line in outputs["elf-relocations"].splitlines():
            m = re.match(r"Relocation section '([^']+)'", line)
            if m:
                current_section = m.group(1)
                relocations[current_section] = {}
            m = re.match(r"\s*([0-9a-f]+)\s+\S+\s+R_X86_64_64\s+[0-9a-f]+\s+(\S+)\s+\+\s+([0-9a-f]+)$", line)
            if m and current_section:
                relocations[current_section][int(m.group(1), 16)] = (m.group(2), int(m.group(3), 16))
        retained = {}
        for table_name, names in [("a3_core_keep", CORE), ("a3_intake_keep", INTAKE)]:
            table = records[table_name]
            require(table["type"] == "OBJECT" and table["binding"] == "LOCAL"
                    and table["bytes"] == 8 * len(names), "invalid private typed retention table")
            table_relocs = relocations.get(".rela" + sections[table["section"]], {})
            for i, name in enumerate(names):
                relocation = table_relocs.get(table["address"] + 8*i)
                require(relocation in ((".text", records[name]["address"]), (name, 0)),
                        "retention pointer does not target native body: " + name)
            retained[table_name] = names
        report["native_bodies"] = bodies
        report["typed_native_body_relocations"] = retained
        report["no_executable_entry_or_exported_definitions"] = True
        # Negative guard checks prevent a future name-only nm gate.
        negatives = []
        for key, value in [("type", "OBJECT"), ("section", "UND"), ("bytes", 0)]:
            altered = {name: dict(value) for name, value in records.items()}
            altered[CORE[0]][key] = value
            try:
                check_native_symbols(altered, text_section)
            except ValueError as exc:
                negatives.append({"scenario": "same-symbol-name-" + key, "rejected": True, "reason": str(exc)})
            else:
                raise ValueError("native symbol guard accepted " + key)
        report["symbol_guard_negative_checks"] = negatives
        # A local unlisted quoted header must never become a pinned dependency.
        shadow = frozen / "qualification/unpinned-header.h"
        shadow.write_bytes(b"/* inert dependency-guard negative input; never compiled */\n")
        try:
            dependency_records("a3_native_object: qualification/unpinned-header.h\n",
                               frozen, files, wrapper_pin, roots)
        except ValueError as exc:
            report["dependency_guard_negative"] = {"rejected": True, "reason": str(exc), "sha256": pin(shadow.read_bytes())["sha256"]}
        else:
            raise ValueError("dependency guard accepted unpinned project header")
        checked_input(frozen)
        checked_input(source)
        report["build_artifacts"] = {p.name: pin(p.read_bytes()) for p in sorted((output / "build").iterdir()) if p.is_file()}
        report.update(result="PASS_COMPILE_ONLY", reason="Full unchanged derivative compiles; all 15 native entry bodies and typed retention relocations verified; object never linked or executed")
        code = 0
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as exc:
        report.update(result="FAIL", reason=str(exc))
        code = 1
    report["finished_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
    persist()
    print(json.dumps({"result": report["result"], "reason": report.get("reason"), "evidence": str(output)}))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
