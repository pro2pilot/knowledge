# Ordinary socket qualification A3 v1

## Граница и местный результат

Оснастка не импортирует и не исполняет `main-intake.inc`, core, derivative Main,
H, Node или bundle. Это отдельные обычные Linux-процессы Python с собственными
сокетами и pipes. Проверки Linux здесь не являются проверкой исходного WSL/profile,
birth authority, успешного offer, положительного exec или release.

В Pro доступен Linux x86_64, но фактически наблюдались `EUID=EGID=0`.
Пользователь разрешил ordinary fixtures только без привилегий. Поэтому
**BLOCKED_UNPRIVILEGED_PRECONDITION**: создание сокета, pipe, pidfd, fork и kcmp
для этой оснастки не выполнялось. Не делались смена пользователя, capabilities,
namespace, ACL или повторные обходные попытки. Это не утверждение, что Linux
socket API вернул EPERM: socket API здесь не вызывался.

Существующий metadata tool result сохранён в `evidence/ordinary/00-*`.
Проверка синтаксиса — только AST parse. Она не повышает runtime-статус.

## Запуск в стандартном runner

Из корня checkout, для закреплённых source-only входов:

```sh
python3 orchestration/results/A3_v1/qualification/ordinary_run.py \
  --input-dir orchestration/stages/A3_qualification_v1/input \
  --output-dir "$RUNNER_TEMP/a3-ordinary" \
  --review-json orchestration/results/A3_v1/qualification/ordinary_review.json
```

`ordinary_review.json` — отдельный receipt независимого критика, привязанный к
точным bytes/SHA обоих Python-файлов и SHA входного manifest. Runner не выдаёт
себе разрешение: stale/missing review останавливает запуск. Директория результата
должна быть новой; предыдущий FAIL не перезаписывается. Входной manifest проверяется
по SHA `8ac2c1b86170c70dcee36f5a4fe878688e32f9ca0b7f8032998316fd79a8eb55`,
после чего проверяются все 59 членов.

Runner разрешает только Linux x86_64 с ненулевыми одинаковыми real/effective/saved
UID и GID и нулевыми CapInh/CapPrm/CapEff/CapAmb. Он не изменяет эти свойства.
Программа получает минимальный environment без передачи секретов. Вызовы
`unshare`, `setns`, setuid/setgid/capset, sudo, install или сетевые внешние запросы
отсутствуют. Обычные дочерние процессы имеют собственный таймер 2.5 секунды,
родитель использует только ограниченный WNOHANG wait для своих unreaped children.
Внешний runner ограничивает весь fixture 60 секундами и в случае timeout
посылает SIGKILL только созданной им process group. Он записывает фактически
наблюдённый rc/reap leader; успешный signal не выдаётся за reap всех descendants.
Для Actions нужен job timeout ≤10 min.

## Три сценария на ключевую проверку

| Группа | Сценарий 1 | Сценарий 2 | Сценарий 3 |
|---|---|---|---|
| Sender | Унаследованный connected endpoint: same-UID child имеет другой SCM_CREDENTIALS PID, SO_PEERCRED остаётся исходным | Сначала queued packet исходного sender, затем packet child: нужны per-message credentials | EOF после закрытия endpoints при ещё живом исходном peer pidfd; EOF и смерть peer — разные факты |
| Death/PID | Исходный creator умер, ещё не reaped; переданный через SCM_RIGHTS endpoint жив, другой sender может послать packet | Retained socket-issued pidfd остаётся dead после reap; procdir не открывается повторно по числовому PID | Retained namespace handles переживают смерть task; финальный pidfd bracket должен отказать |
| Ancillary | MSG_TRUNC и MSG_CTRUNC с already-installed rights: закрыть видимые FDs до решения по payload | Zero-payload packet с rights не равен EOF; после него возможен живой packet, EOF наблюдается отдельно | Две переданные ссылки на один OFD устанавливают разные номера FDs; закрыть обе и auto SCM_PIDFD |
| Pipe/OFD | dup alias меняет O_NONBLOCK исходного reader; восстановить flags до любого read | Reader/writer одного pipe имеют одинаковый inode, разные OFDs; второй pipe имеет отдельный object | Дополнительный writer alias удерживает pipe от EOF после закрытия original writer |
| Namespace | User/time/pid прочитаны отдельными вызовами с отдельными временными интервалами; atomic snapshot не заявляется | ABA/смена namespace не выполняется и не исключается финальным равенством | Читаемые held handles не доказывают liveness; физическое наблюдение смерти — отдельный D3 |
| Time/cleanup | Повторный EAGAIN не перевыставляет исходные S/W/C в fixture policy | Намеренно уже начатый bounded receive возвращает rights после W и C; sweep остаётся обязательным, completion записывается как late | Локальная отмена прерывает ожидание без нового бюджета; Python exception не объявляется native C EINTR |

Все перечисленные runtime-сценарии **не выполнены в Pro** вследствие EUID/EGID
precondition. Они подготовлены для независимого запуска оркестратором.

## Непокрытые физические свойства

Физический reuse **того же числового PID** не форсируется: это потребовало бы
лишней нагрузки/настроек и не может подменяться созданием любого нового child.
Точное отрицательное свойство текущего intake проверяет отдельно модель `O09`.
Открытие `/proc/<peer>` в ordinary death fixture одно; после смерти используется
только удержанный procdir, без повторного lookup по числу.

Namespace hybrid/ABA transitions не выполняются, `unshare`/`setns` отсутствуют.
Два равных последовательных наблюдения не исключают промежуточный переход.
Существующие source-model `N04/N05` — drift negatives, не физическая ABA-проверка.
Native `recvmsg` EINTR и `close` EINTR/FD-number reuse покрываются отдельно
моделями `O11`, `A16`, `O15`; Python signal exception не заменяет эти доказательства.

Намеренно блокирующий receive в T2 служит только воспроизводимым примером позднего
возврата already-started syscall и последующего retirement. Native intake во время
этого теста не исполняется; fixture не доказывает физическую прерываемость его I/O.

`kcmp(KCMP_FILE)` проверяется один раз на собственном reader и его известном dup.
EPERM/неподдержка сохраняется как BLOCKED и не обходится. Отдельные pipe observations
через явно созданные dup и F_SETFL не выдаются за kcmp-проверку отсутствия всех aliases.

Обязательные primitives проверяются одной последовательностью. Отказ на одном
шаге консервативно оставляет все последующие группы `BLOCKED_NOT_RUN`, включая
группы с потенциально независимыми доступными prerequisites. Такой отказ не
доказывает, что каждый невызванный pipe/proc/namespace API тоже недоступен.
Отдельный необязательный kcmp probe сохраняет собственный BLOCKED; дальнейшие
наблюдения известных собственных dup не заменяют отсутствующее kcmp-доказательство.

## Коды и evidence

| RC | Значение |
|---|---|
| 0 | Выполненные ordinary observations завершились; общая квалификация остаётся `PARTIAL_ORDINARY_FIXTURES_ONLY` |
| 77 | BLOCKED prerequisite/ABI либо PARTIAL с недоступным kcmp; отсутствующие проверки не PASS |
| 1 | Assertion, cleanup, input pin или runner FAIL; все raw остаются |
| 78 | Exact-source review отсутствует или устарел; fixture не запускается |

Output содержит `RESULT.json`, `INPUT_CHECK.json`, `SOURCE_PINS.json`,
`SOURCE_REVIEW.json`, raw stdout/stderr и argv/timeout/rc. Fixture stdout содержит
отдельные events, per-check/per-group statuses, namespace intervals, actual
pidfd/socket readiness и фактические cleanup timestamps. Raw нужно проверить
перед публикацией; original/private и явно помеченная public-redacted копия
подготавливаются общим packager этапа.

Runner сохраняет exact-source copies обоих Python-файлов в новом `sources/` и
исполняет только frozen fixture через `python -I -B`. После выполнения он повторно
проверяет входы, manifest и исходные/frozen scripts. Для RC0 обязательны все 18
уникальных check IDs: 17 ordinary observations и отдельный `N2 NOT_RUN`, а также
шесть согласованных group outcomes. Timeout сохраняет raw обоих ограниченных
ожиданий и только фактически наблюдённый результат signal/reap.
