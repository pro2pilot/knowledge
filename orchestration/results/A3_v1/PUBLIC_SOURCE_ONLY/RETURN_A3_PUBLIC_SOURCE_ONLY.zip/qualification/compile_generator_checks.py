#!/usr/bin/env python3
"""Run exact original derive_main.py reproduction and fail-closed file tests.

Only the pinned Python generator runs, in fresh disposable copies. No compiler,
native subject, Node or bundle is invoked by this program. Original inputs are
verified before and after; every test fixture and raw subprocess result remain.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
from compile_qualification import checked_input, pin, require

PIN_INPUT_NAMES = [
    "source4/BASE_MAIN/verification-linux-service-main.c",
    "source4/BASE_MAIN/verification-linux-service-configuration.h",
    "source4/BASE_MAIN/verification-linux-service-daemon.h",
    "source4/BASE_MAIN/verification-linux-service-runtime-front.h",
    "source4/main-h-birth-core.inc",
    "source4/intake-slice/derive_main.py",
]
DERIVATIVE = "source4/intake-slice/private-main-intake.c"
RECEIPT = "source4/intake-slice/DERIVATIVE_PINS.json"


def snapshot(root: Path) -> dict:
    return {p.relative_to(root).as_posix(): pin(p.read_bytes())
            for p in sorted(root.rglob("*")) if p.is_file()}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    source, output = args.input.resolve(), args.output.resolve()
    require(not output.is_relative_to(source), "output must be outside immutable input")
    output.mkdir(parents=True, exist_ok=False)
    (output / "tmp").mkdir()
    report = {"schema": "a3-unchanged-generator-negative-checks.v1",
              "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
              "native_execution": "NOT_RUN", "generator_modified": False,
              "cases": [], "result": "IN_PROGRESS"}
    environment = {"PATH": os.environ.get("PATH", os.defpath), "LANG": "C", "LC_ALL": "C",
                   "TMPDIR": str(output / "tmp"), "PYTHONDONTWRITEBYTECODE": "1"}

    def persist() -> None:
        (output / "RESULT.json").write_text(json.dumps(report, indent=2) + "\n")

    def case(label: str, mode: str, initial: tuple[str, ...], mutate=None,
             expected_error: str | None = None, success: bool = False) -> None:
        fixture = output / "fixtures" / label
        for name in PIN_INPUT_NAMES + list(initial):
            target = fixture / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((source / name).read_bytes())
        mutations = []
        if mutate:
            name, transform = mutate
            p = fixture / name
            before = p.read_bytes()
            after = transform(before)
            p.write_bytes(after)
            mutations.append({"path": name, "before": pin(before), "after": pin(after)})
        before_run = snapshot(fixture)
        argv = [sys.executable, "source4/intake-slice/derive_main.py", mode]
        row = {"id": label, "argv": argv, "cwd": str(fixture), "timeout_seconds": 15,
               "mutations": mutations, "before": before_run, "expected_success": success,
               "expected_error": expected_error, "stdout": label + ".stdout.bin",
               "stderr": label + ".stderr.bin"}
        start = time.monotonic_ns()
        try:
            p = subprocess.run(argv, cwd=fixture, env=environment, capture_output=True,
                               timeout=15, check=False)
            rc, stdout, stderr = p.returncode, p.stdout, p.stderr
        except subprocess.TimeoutExpired as exc:
            rc, stdout, stderr = 124, exc.stdout or b"", exc.stderr or b""
            row["timed_out"] = True
        except OSError as exc:
            rc, stdout, stderr = 125, b"", str(exc).encode()
            row["invocation_error"] = type(exc).__name__
        (output / row["stdout"]).write_bytes(stdout)
        (output / row["stderr"]).write_bytes(stderr)
        after_run = snapshot(fixture)
        row.update(rc=rc, duration_ns=time.monotonic_ns()-start, after=after_run)
        if success:
            passed = rc == 0 and all((fixture / name).read_bytes() == (source / name).read_bytes()
                                    for name in (DERIVATIVE, RECEIPT))
            row["exact_output_reproduction"] = passed
            if mode == "--check":
                passed = passed and before_run == after_run
        else:
            passed = (rc == 1 and expected_error is not None and expected_error.encode() in stderr
                      and before_run == after_run)
            row["no_overwrite_or_partial_output"] = before_run == after_run
        row["passed"] = passed
        report["cases"].append(row)
        persist()

    try:
        checked_input(source)
        report["runner_pins"] = {Path(__file__).name: pin(Path(__file__).read_bytes()),
                                "compile_qualification.py": pin(Path(__file__).with_name("compile_qualification.py").read_bytes())}
        report["generator_pin"] = pin((source / "source4/intake-slice/derive_main.py").read_bytes())
        case("exact-read-only-reproduction", "--check", (DERIVATIVE, RECEIPT), success=True)
        case("fresh-write-byte-reproduction", "--write", (), success=True)
        refusal = "refusing to overwrite existing derivative/provenance"
        case("both-outputs-preexist", "--write", (DERIVATIVE, RECEIPT), expected_error=refusal)
        case("derivative-only-preexists", "--write", (DERIVATIVE,), expected_error=refusal)
        case("receipt-only-preexists", "--write", (RECEIPT,), expected_error=refusal)
        base = "source4/BASE_MAIN/verification-linux-service-main.c"
        core = "source4/main-h-birth-core.inc"
        case("base-single-byte-drift", "--write", (),
             (base, lambda b: b.replace(b"Fixed", b"fixed", 1)),
             "pinned input mismatch: BASE_MAIN/verification-linux-service-main.c")
        case("core-trailing-byte-drift", "--write", (), (core, lambda b: b + b"\n"),
             "pinned input mismatch: main-h-birth-core.inc")
        case("base-crlf-drift", "--write", (), (base, lambda b: b.replace(b"\n", b"\r\n")),
             "pinned input mismatch: BASE_MAIN/verification-linux-service-main.c")
        case("duplicate-anchor-rejected-by-pin", "--write", (),
             (base, lambda b: b + b'#include "verification-linux-service-configuration.h"\n'),
             "pinned input mismatch: BASE_MAIN/verification-linux-service-main.c")
        case("existing-derivative-content-drift", "--check", (DERIVATIVE, RECEIPT),
             (DERIVATIVE, lambda b: b + b"\n"), "derivative mismatch: private-main-intake.c")
        case("missing-receipt-read-only", "--check", (DERIVATIVE,),
             expected_error="FileNotFoundError")
        checked_input(source)
        report["passed"] = sum(row["passed"] for row in report["cases"])
        report["failed"] = len(report["cases"]) - report["passed"]
        report["result"] = "PASS_SOURCE_GENERATOR_ONLY" if not report["failed"] else "FAIL"
        code = bool(report["failed"])
    except (OSError, ValueError, KeyError) as exc:
        report.update(result="FAIL", reason=str(exc))
        code = 1
    report["finished_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
    persist()
    print(json.dumps({"result": report["result"], "passed": report.get("passed"),
                      "failed": report.get("failed"), "evidence": str(output)}))
    return int(code)


if __name__ == "__main__":
    raise SystemExit(main())
