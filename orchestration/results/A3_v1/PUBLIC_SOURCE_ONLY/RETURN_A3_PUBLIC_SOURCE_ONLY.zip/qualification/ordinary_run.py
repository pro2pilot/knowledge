#!/usr/bin/env python3
"""Pin reviewed A3 inputs, run only ordinary Python fixtures, preserve all raw.

Exit 0: executed ordinary fixture cases completed; physical scope still partial.
Exit 77: an environment/ABI prerequisite is BLOCKED, with no unchanged retry.
Exit 1: fixture assertion/cleanup/runner failure. Exit 78: missing/stale review.
No native Main/H/Node/bundle is linked, imported or executed by this runner.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

INPUT_MANIFEST_SHA256 = "8ac2c1b86170c70dcee36f5a4fe878688e32f9ca0b7f8032998316fd79a8eb55"
INPUT_COMMIT = "0684ffa0d132675233d7d9602121f02bb50ff6eb"
EXPECTED_IDS = {
    "S1_inherited_same_UID_sender", "S2_queued_creator_then_substitute",
    "S3_EOF_with_live_connection_creator", "D1_creator_dead_unreaped_endpoint_live",
    "D2_retained_dead_pidfd_and_proc", "D3_ns_handle_survives_death_not_liveness",
    "A1_TRUNC_CTRUNC_sweep_first", "A2_zero_packet_rights_then_actual_EOF",
    "A3_duplicate_OFD_rights_and_SCM_PIDFD", "P1_dup_alias_shares_O_NONBLOCK",
    "P2_opposite_endpoints_same_inode_different_OFD", "P3_writer_alias_delays_EOF",
    "N1_separate_readonly_namespace_observations", "N2_ABA_namespace_transition",
    "N3_live_self_readonly_baseline_only", "T1_EAGAIN_no_fresh_budget",
    "T2_late_receive_and_cleanup_retained_as_late", "T3_cancellation_keeps_original_bounds",
}
EXPECTED_GROUPS = {"sender", "death", "ancillary", "pipes", "namespaces", "deadlines"}


def pin(path: Path) -> dict:
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def no_symlinks(path: Path, boundary: Path) -> None:
    current = path
    while current != boundary:
        if current.is_symlink():
            raise ValueError("symlink is not permitted in pinned input/source: " + str(current))
        if current == current.parent:
            raise ValueError("path is outside pin boundary")
        current = current.parent


def partial_bytes(value) -> bytes:
    return value if isinstance(value, bytes) else (value or "").encode()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--review-json", type=Path, required=True)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    source = args.input_dir.resolve()
    output = args.output_dir.resolve()
    if output == source or output.is_relative_to(source):
        parser.error("output directory must not be inside the immutable input")
    output.mkdir(parents=True, exist_ok=False)
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    report = {"schema": "a3-ordinary-run.v1", "argv": sys.argv, "started_utc": started,
        "input_commit": INPUT_COMMIT, "native_Main_H_Node_bundle": "NOT_RUN",
        "ordinary_fixture_scope": "unprivileged Linux mechanics; no subject execution",
        "source_model_compiler_is_physical_proof": False,
        "result": "IN_PROGRESS", "actions": []}

    def finish(result: str, reason: str, rc: int) -> int:
        report.update(result=result, reason=reason, rc=rc,
                      finished_utc=dt.datetime.now(dt.timezone.utc).isoformat())
        (output / "RESULT.json").write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps({"result": result, "rc": rc, "reason": reason,
                          "evidence": str(output)}))
        return rc

    try:
        manifest_path = source / "MANIFEST.json"
        no_symlinks(manifest_path, source)
        manifest_pin = pin(manifest_path)
        if manifest_pin["sha256"] != INPUT_MANIFEST_SHA256:
            return finish("FAIL_INPUT_PIN", "input manifest differs from pinned commit", 1)
        manifest = json.loads(manifest_path.read_bytes())
        checked = {}
        for name, expected in manifest["files"].items():
            path = source / name
            if not path.resolve().is_relative_to(source):
                return finish("FAIL_INPUT_PATH", "manifest path escapes immutable input", 1)
            no_symlinks(path, source)
            checked[name] = pin(path)
            if checked[name] != expected:
                return finish("FAIL_INPUT_PIN", "input bytes differ: " + name, 1)
        report["input_manifest"] = manifest_pin
        report["verified_input_files"] = len(checked)
        (output / "INPUT_CHECK.json").write_text(json.dumps({"status": "VERIFIED",
            "manifest": manifest_pin, "files": checked}, indent=2) + "\n")
        fixture = here / "ordinary_socket_fixtures.py"
        original_sources = (Path(__file__).resolve(), fixture)
        for path in original_sources:
            no_symlinks(path, here)
        source_pins = {path.name: pin(path) for path in original_sources}
        report["source_pins"] = source_pins
        (output / "SOURCE_PINS.json").write_text(json.dumps(source_pins, indent=2) + "\n")
        try:
            review_bytes = args.review_json.read_bytes()
            review = json.loads(review_bytes)
        except (OSError, ValueError) as exc:
            return finish("NOT_RUN_REVIEW_GATE", "independent exact-source review unavailable: " + str(exc), 78)
        (output / "SOURCE_REVIEW.json").write_bytes(review_bytes)
        report["review_pin"] = {"bytes": len(review_bytes),
                                 "sha256": hashlib.sha256(review_bytes).hexdigest()}
        if not (isinstance(review, dict) and review.get("allow_ordinary_fixtures") is True
                and review.get("input_manifest_sha256") == INPUT_MANIFEST_SHA256
                and review.get("source_pins") == source_pins):
            return finish("NOT_RUN_REVIEW_GATE", "independent exact-source review missing or stale", 78)
        frozen = output / "sources"
        frozen.mkdir()
        for path in original_sources:
            target = frozen / path.name
            target.write_bytes(path.read_bytes())
            if pin(target) != source_pins[path.name]:
                return finish("FAIL_SOURCE_CHANGED", "source changed while freezing: " + path.name, 1)
        # Never forward user secrets/environment. subprocess and all its local
        # forked fixture children share a new process group for bounded teardown.
        argv = [sys.executable, "-I", "-B", str(frozen / fixture.name)]
        action = {"argv": argv, "cwd": str(frozen), "timeout_seconds": 60,
                  "stdout": "ordinary.stdout.raw", "stderr": "ordinary.stderr.raw",
                  "started_utc": dt.datetime.now(dt.timezone.utc).isoformat()}
        report["actions"].append(action)
        began = time.monotonic_ns()
        proc = subprocess.Popen(argv, cwd=frozen, stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, close_fds=True,
            start_new_session=True, env={"PATH": os.defpath, "LANG": "C", "LC_ALL": "C"})
        try:
            stdout, stderr = proc.communicate(timeout=60)
            rc = proc.returncode
            action["timeout"] = False
        except subprocess.TimeoutExpired as first:
            action["timeout"] = True
            stdout, stderr = partial_bytes(first.output), partial_bytes(first.stderr)
            (output / "ordinary.timeout1.stdout.raw").write_bytes(stdout)
            (output / "ordinary.timeout1.stderr.raw").write_bytes(stderr)
            action["first_timeout_raw"] = ["ordinary.timeout1.stdout.raw", "ordinary.timeout1.stderr.raw"]
            action["group_cleanup"] = {"signal": "SIGKILL", "owned_process_group": proc.pid,
                                       "attempted": True, "leader_reaped": False,
                                       "all_descendants_reaped": None}
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                action["group_cleanup"]["signal_result"] = "ESRCH"
            except OSError as exc:
                action["group_cleanup"].update(signal_result="ERROR", errno=exc.errno)
            else:
                action["group_cleanup"]["signal_result"] = "sent; termination not yet observed"
            try:
                stdout, stderr = proc.communicate(timeout=3)
            except subprocess.TimeoutExpired as second:
                stdout = partial_bytes(second.output) if second.output is not None else stdout
                stderr = partial_bytes(second.stderr) if second.stderr is not None else stderr
                (output / "ordinary.timeout2.stdout.raw").write_bytes(stdout)
                (output / "ordinary.timeout2.stderr.raw").write_bytes(stderr)
                action["second_timeout_raw"] = ["ordinary.timeout2.stdout.raw", "ordinary.timeout2.stderr.raw"]
                action["group_cleanup"]["teardown_incomplete"] = True
                # Close local read endpoints without an unbounded wait. The
                # absence of a reap result remains explicit in the receipt.
                proc.stdout.close()
                proc.stderr.close()
            observed_rc = proc.poll()
            action["group_cleanup"].update(observed_process_rc=observed_rc,
                                             leader_reaped=observed_rc is not None)
            rc = 124
        action.update(rc=rc, duration_ns=time.monotonic_ns() - began)
        (output / action["stdout"]).write_bytes(stdout)
        (output / action["stderr"]).write_bytes(stderr)
        final_inputs = {name: pin(source / name) for name in checked}
        final_manifest = pin(manifest_path)
        final_sources = {path.name: pin(path) for path in original_sources}
        final_frozen = {path.name: pin(frozen / path.name) for path in original_sources}
        report["final_pin_check"] = {"input_files": final_inputs == checked,
            "manifest": final_manifest == manifest_pin, "source_files": final_sources == source_pins,
            "frozen_files": final_frozen == source_pins}
        if not all(report["final_pin_check"].values()):
            return finish("FAIL_SOURCE_CHANGED", "input or qualification bytes changed during run", 1)
        if action["timeout"]:
            return finish("FAIL_TIMEOUT", "fixture timeout; all partial raw and observed teardown retained", 1)
        try:
            fixture_result = json.loads(stdout)
        except (ValueError, UnicodeError):
            return finish("FAIL", "fixture output is not complete JSON; raw preserved", 1)
        if not isinstance(fixture_result, dict):
            return finish("FAIL", "fixture JSON must be an object; raw preserved", 1)
        rows = fixture_result.get("checks")
        groups = fixture_result.get("case_groups")
        if not (isinstance(rows, list)
                and all(isinstance(row, dict) and isinstance(row.get("id"), str)
                        and isinstance(row.get("status"), str) for row in rows)
                and isinstance(groups, dict)
                and all(isinstance(key, str) and isinstance(value, str)
                        for key, value in groups.items())
                and isinstance(fixture_result.get("primitive_probe"), dict)
                and isinstance(fixture_result.get("kcmp_probe", {}), dict)
                and type(fixture_result.get("rc")) is int):
            return finish("FAIL", "fixture JSON has malformed checks/groups/probe/rc; raw preserved", 1)
        report["fixture_result"] = fixture_result.get("result")
        report["fixture_rc"] = fixture_result.get("rc")
        report["fixture_checks"] = fixture_result.get("checks", [])
        report["fixture_children_created"] = fixture_result.get("fixture_children_created")
        if fixture_result.get("rc") != rc:
            return finish("FAIL", "raw process rc and fixture report rc disagree", 1)
        if rc == 77:
            if any(row["status"].startswith("FAIL") for row in rows) or any(
                    value.startswith("FAIL") for value in groups.values()):
                return finish("FAIL", "fixture blocked result contains an earlier FAIL; raw preserved", 1)
            return finish("BLOCKED_OR_PARTIAL_BLOCKED", fixture_result.get("reason", "required capability blocked"), 77)
        if rc:
            return finish("FAIL", "ordinary fixture failed; all raw retained", 1)
        if fixture_result.get("result") != "PARTIAL_ORDINARY_FIXTURES_ONLY":
            return finish("FAIL", "unexpected fixture result classification", 1)
        ids = [row.get("id") for row in rows]
        expected_statuses = all(row.get("status") == (
            "NOT_RUN" if row.get("id") == "N2_ABA_namespace_transition"
            else "PASS_ORDINARY_FIXTURE_ONLY") for row in rows)
        complete = (len(ids) == len(EXPECTED_IDS) and len(set(ids)) == len(ids)
            and set(ids) == EXPECTED_IDS and expected_statuses
            and set(groups) == EXPECTED_GROUPS
            and set(groups.values()) == {"ORDINARY_OBSERVATIONS_RECORDED"}
            and fixture_result.get("primitive_probe", {}).get("status") == "PASS_REQUIRED_ORDINARY_PRIMITIVES"
            and fixture_result.get("kcmp_probe", {}).get("status") == "PASS_ORDINARY_FIXTURE_ONLY")
        boundaries = (fixture_result.get("native_Main_H_Node_bundle") == "NOT_RUN"
            and fixture_result.get("intake_source_execution") == "NOT_RUN"
            and fixture_result.get("physical_birth_proof") is False
            and fixture_result.get("WSL_original_profile_proof") is False
            and fixture_result.get("offer_release_exec") == "EOPNOTSUPP_UNCHANGED")
        report["complete_result_validation"] = {"exact_unique_check_ids_statuses_groups": complete,
                                                "no_native_claim_boundaries": boundaries}
        if not complete or not boundaries:
            return finish("FAIL", "fixture JSON missing/duplicate/wrong checks or scope classification", 1)
        return finish("PARTIAL_ORDINARY_FIXTURES_ONLY",
            "executed ordinary checks completed; no actual PID reuse/ns-transition, WSL, Main/H or release proof", 0)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        return finish("FAIL_RUNNER", type(exc).__name__ + ": " + str(exc), 1)


if __name__ == "__main__":
    raise SystemExit(main())
