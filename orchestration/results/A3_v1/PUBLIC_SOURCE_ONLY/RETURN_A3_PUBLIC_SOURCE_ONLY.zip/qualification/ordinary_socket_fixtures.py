#!/usr/bin/env python3
"""Bounded, unprivileged Linux transport fixtures; no product code is imported.

This is a measurement of ordinary sockets, processes, proc handles and pipes.
It does not execute Main, H, Node, a bundle, or the intake implementation. No
identity/namespace/capability transition, host setup, or external I/O occurs.
Physical PID-number reuse and namespace transitions are explicitly NOT_RUN.
Run through ordinary_run.py, which pins inputs and the independent review.
"""
from __future__ import annotations

import array
import ctypes
import errno
import fcntl
import json
import math
import os
import platform
import select
import signal
import socket
import struct
import sys
import time
import traceback

SO_PASSPIDFD = 76
SO_PEERPIDFD = 77
SCM_PIDFD = 4
NS_GET_NSTYPE = 0xB703
NAMESPACES = (("user", 0x10000000), ("time", 0x80), ("pid", 0x20000000))
BLOCKING_ERRNOS = {errno.EPERM, errno.EACCES, errno.ENOSYS, errno.ENOPROTOOPT,
                   errno.EOPNOTSUPP, errno.EAFNOSUPPORT, errno.EPROTONOSUPPORT}


class Blocked(Exception):
    pass


class Cancelled(Exception):
    pass


def check(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def now() -> int:
    return time.monotonic_ns()


def poll_one(fd: int, events: int, deadline: int) -> int:
    poller = select.poll()
    poller.register(fd, events)
    left = deadline - now()
    if left <= 0:
        raise TimeoutError("original fixture deadline expired")
    result = poller.poll(max(1, math.ceil(left / 1_000_000)))
    if not result:
        raise TimeoutError("original fixture deadline expired")
    return result[0][1]


def ready(fd: int, events: int = select.POLLIN) -> int:
    poller = select.poll()
    poller.register(fd, events)
    result = poller.poll(0)
    return result[0][1] if result else 0


class Owner:
    """Exact fixture-owned resources. Invalidate before closing, never retry."""
    def __init__(self, report: dict, label: str, seconds: float = 3.0):
        self.report = report
        self.label = label
        self.deadline = now() + int(seconds * 1_000_000_000)
        self.sockets: list[socket.socket] = []
        self.fds: set[int] = set()
        self.children: set[int] = set()

    def event(self, label: str, **data: object) -> None:
        self.report["events"].append({"case": self.label, "label": label,
                                     "monotonic_ns": now(), **data})

    def fd(self, fd: int) -> int:
        check(fd >= 0 and fd not in self.fds, "duplicate owned descriptor number")
        self.fds.add(fd)
        return fd

    def sock(self, sock: socket.socket) -> socket.socket:
        sock.setblocking(False)
        self.sockets.append(sock)
        return sock

    def pipe(self) -> tuple[int, int]:
        pair = os.pipe2(os.O_CLOEXEC | os.O_NONBLOCK)
        for fd in pair:
            self.fd(fd)
        return pair

    def close_fd(self, fd: int) -> None:
        self.fds.remove(fd)
        try:
            os.close(fd)
        except OSError as exc:
            self.event("close", fd=fd, rc=-1, errno=exc.errno, retry=False)
            raise
        self.event("close", fd=fd, rc=0, retry=False)

    def close_sock(self, sock: socket.socket) -> None:
        self.sockets.remove(sock)
        fd = sock.fileno()
        try:
            sock.close()
        except OSError as exc:
            self.event("socket_close", fd=fd, rc=-1, errno=exc.errno, retry=False)
            raise
        self.event("socket_close", fd=fd, rc=0, retry=False)

    def fork(self, fn) -> int:
        pid = os.fork()
        if pid == 0:
            # Every fixture child has its own finite lifetime, even if the
            # controller disappears. No process group or host policy changes.
            signal.signal(signal.SIGALRM, signal.SIG_DFL)
            signal.setitimer(signal.ITIMER_REAL, 2.5)
            try:
                fn()
            except BaseException:
                traceback.print_exc(file=sys.stderr)
                os._exit(101)
            os._exit(0)
        self.children.add(pid)
        self.report["fixture_children_created"] += 1
        self.event("ordinary_child_created", pid=pid)
        return pid

    def reap(self, pid: int, deadline: int | None = None) -> int:
        check(pid in self.children, "wait attempted for an unowned/reaped child")
        bound = self.deadline if deadline is None else deadline
        while True:
            got, status = os.waitpid(pid, os.WNOHANG)
            if got:
                self.children.remove(pid)
                self.event("ordinary_child_reaped", pid=got, wait_status=status)
                return status
            if now() >= bound:
                raise TimeoutError("bounded exact-child reap timed out")
            time.sleep(0.002)

    def clean(self) -> None:
        errors = []
        # A child remains an unreaped child until waitpid succeeds; no new
        # lookup by PID or signal to a reaped/reused number is performed.
        for pid in list(self.children):
            try:
                got, status = os.waitpid(pid, os.WNOHANG)
                if got:
                    self.children.remove(pid)
                    self.event("cleanup_reaped", pid=got, wait_status=status)
                    continue
                os.kill(pid, signal.SIGKILL)
                self.event("cleanup_kill_own_unreaped_child", pid=pid)
                self.reap(pid, now() + 1_000_000_000)
            except BaseException as exc:
                errors.append(type(exc).__name__ + ": " + str(exc))
        for sock in list(reversed(self.sockets)):
            try:
                self.close_sock(sock)
            except BaseException as exc:
                errors.append(type(exc).__name__ + ": " + str(exc))
        for fd in sorted(self.fds, reverse=True):
            try:
                self.close_fd(fd)
            except BaseException as exc:
                errors.append(type(exc).__name__ + ": " + str(exc))
        if errors:
            self.event("cleanup_errors", errors=errors,
                       still_unreaped_children=sorted(self.children))
            raise AssertionError("fixture cleanup failed: " + repr(errors))


def connected(o: Owner, passpidfd: bool = True):
    listener = o.sock(socket.socket(socket.AF_UNIX,
                      socket.SOCK_SEQPACKET | socket.SOCK_CLOEXEC))
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_PASSCRED, 1)
    # Abstract name is local routing data only, never an authority token.
    address = b"\0knowledge-a3-ordinary-" + str(os.getpid()).encode() + b"-" + str(now()).encode()
    listener.bind(address)
    listener.listen(2)
    client = o.sock(socket.socket(socket.AF_UNIX,
                    socket.SOCK_SEQPACKET | socket.SOCK_CLOEXEC))
    client.connect(address)
    poll_one(listener.fileno(), select.POLLIN, o.deadline)
    accepted = o.sock(listener.accept()[0])
    accepted.setsockopt(socket.SOL_SOCKET, socket.SO_PASSCRED, 1)
    if passpidfd:
        accepted.setsockopt(socket.SOL_SOCKET, SO_PASSPIDFD, 1)
    return listener, client, accepted


def peer_pidfd(o: Owner, accepted: socket.socket) -> tuple[tuple[int, int, int], int]:
    cred = struct.unpack("3i", accepted.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))
    raw = accepted.getsockopt(socket.SOL_SOCKET, SO_PEERPIDFD, 4)
    check(len(raw) == 4, "SO_PEERPIDFD returned a short length")
    fd = o.fd(struct.unpack("i", raw)[0])
    check(fcntl.fcntl(fd, fcntl.F_GETFD) & fcntl.FD_CLOEXEC != 0,
          "SO_PEERPIDFD missing CLOEXEC")
    o.event("SO_PEERCRED_SO_PEERPIDFD", peer=list(cred), pidfd=fd,
            readiness=ready(fd), parent_authority=False)
    return cred, fd


def ancillary_retire(o: Owner, records) -> list[dict]:
    """Sweep every visible installed fd even when a later assertion fails."""
    observations = []
    installed: list[int] = []
    faults = []
    for level, kind, raw in records:
        item = {"level": level, "type": kind, "bytes": len(raw)}
        if level == socket.SOL_SOCKET and kind in (socket.SCM_RIGHTS, SCM_PIDFD):
            values = array.array("i")
            values.frombytes(raw[:len(raw) - len(raw) % values.itemsize])
            item["fds"] = []
            if len(raw) % values.itemsize:
                faults.append("partial descriptor integer")
            for fd in values:
                if fd < 0 or fd in o.fds or fd in installed:
                    faults.append("invalid/colliding installed descriptor")
                    continue
                o.fd(fd)
                installed.append(fd)
                try:
                    cloexec = bool(fcntl.fcntl(fd, fcntl.F_GETFD) & fcntl.FD_CLOEXEC)
                    st = os.fstat(fd)
                    item["fds"].append({"fd": fd, "cloexec": cloexec,
                                        "dev": st.st_dev, "ino": st.st_ino})
                    if not cloexec:
                        faults.append("installed descriptor missing CLOEXEC")
                except OSError as exc:
                    faults.append("installed descriptor inspection: " + str(exc.errno))
        elif level == socket.SOL_SOCKET and kind == socket.SCM_CREDENTIALS:
            if len(raw) != 12:
                faults.append("malformed SCM_CREDENTIALS")
            else:
                item["credentials"] = list(struct.unpack("3i", raw))
        observations.append(item)
    for fd in installed:
        try:
            o.close_fd(fd)
        except OSError as exc:
            faults.append("close returned errno " + str(exc.errno))
    # No intervening operation allocates a descriptor before these EBADF checks.
    for fd in installed:
        try:
            fcntl.fcntl(fd, fcntl.F_GETFD)
        except OSError as exc:
            if exc.errno != errno.EBADF:
                faults.append("closed descriptor probe: " + str(exc.errno))
        else:
            faults.append("installed descriptor was not retired")
    o.event("ancillary_sweep_before_payload_decision", records=observations,
            installed=len(installed), retired=len(installed), faults=faults)
    check(not faults, "ancillary retirement fault: " + repr(faults))
    return observations


def receive(o: Owner, sock: socket.socket, data_size: int = 64, control_size: int = 4096):
    poll_one(sock.fileno(), select.POLLIN, o.deadline)
    payload, ancillary, flags, _ = sock.recvmsg(data_size, control_size,
                                  socket.MSG_DONTWAIT | socket.MSG_CMSG_CLOEXEC)
    observed = ancillary_retire(o, ancillary)
    o.event("recvmsg", payload_bytes=len(payload), flags=flags,
            zero_payload_alone_is_EOF_proof=False)
    return payload, observed, flags


def credentials(observed) -> list[list[int]]:
    return [r["credentials"] for r in observed if "credentials" in r]


def rights(observed) -> list[dict]:
    return [fd for r in observed if r["level"] == socket.SOL_SOCKET
            and r["type"] == socket.SCM_RIGHTS for fd in r.get("fds", [])]


def send(sock: socket.socket, payload: bytes, fds: list[int] | None = None) -> int:
    ancillary = [] if fds is None else [(socket.SOL_SOCKET, socket.SCM_RIGHTS,
                                        array.array("i", fds))]
    count = sock.sendmsg([payload], ancillary, socket.MSG_DONTWAIT | socket.MSG_NOSIGNAL)
    check(count == len(payload), "unexpected short seqpacket send")
    return count


def note_case(report: dict, ident: str, **fields: object) -> None:
    report["checks"].append({"id": ident, "status": "PASS_ORDINARY_FIXTURE_ONLY", **fields})


def namespaces(o: Owner, proc: int, keep: bool = False) -> list[dict]:
    observations = []
    for name, expected_type in NAMESPACES:
        before = now()
        fd = o.fd(os.open("ns/" + name, os.O_RDONLY | os.O_CLOEXEC, dir_fd=proc))
        st = os.fstat(fd)
        ns_type = fcntl.ioctl(fd, NS_GET_NSTYPE)
        after = now()
        check(ns_type == expected_type, "namespace ioctl type mismatch")
        observations.append({"name": name, "dev": st.st_dev, "ino": st.st_ino,
                             "type": ns_type, "before_ns": before,
                             "after_ns": after, "held_fd": fd if keep else None})
        if not keep:
            o.close_fd(fd)
    o.event("sequential_namespace_observations", observations=observations,
            atomic_snapshot=False, intervening_transition_excluded=False)
    return observations


def prerequisites(o: Owner, report: dict) -> None:
    report["primitive_probe"] = {"status": "IN_PROGRESS", "attempts": 1,
                                 "step": "required_ABI_constants"}
    if struct.calcsize("i") != 4 or not hasattr(socket, "MSG_CMSG_CLOEXEC"):
        raise Blocked("required Linux int/MSG_CMSG_CLOEXEC ABI unavailable")
    report["primitive_probe"]["step"] = "AF_UNIX_SEQPACKET_listener_connect_accept"
    _, client, accepted = connected(o)
    report["primitive_probe"]["step"] = "SO_PEERCRED_SO_PEERPIDFD"
    cred, pidfd = peer_pidfd(o, accepted)
    check(cred == (os.getpid(), os.geteuid(), os.getegid()), "unexpected self peer credentials")
    check(not ready(pidfd), "live self peer pidfd unexpectedly ready")
    report["primitive_probe"]["step"] = "SCM_CREDENTIALS_SCM_PIDFD_receive"
    send(client, b"primitive")
    data, records, flags = receive(o, accepted)
    check(data == b"primitive" and not flags & (socket.MSG_TRUNC | socket.MSG_CTRUNC),
          "primitive packet was truncated")
    check(credentials(records) == [list(cred)], "primitive credential record mismatch")
    check(sum(r["type"] == SCM_PIDFD for r in records) == 1,
          "SO_PASSPIDFD did not deliver one SCM_PIDFD")
    report["primitive_probe"]["step"] = "read_only_proc_namespace_handles"
    proc = o.fd(os.open("/proc/self", os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC))
    namespaces(o, proc)
    report["primitive_probe"]["step"] = "pipe_dup_and_optional_kcmp"
    pair = o.pipe()
    alias = o.fd(os.dup(pair[0]))
    # kcmp is optional evidence, attempted exactly once. A denial is retained
    # and never retried or worked around with a different identity/profile.
    libc = ctypes.CDLL(None, use_errno=True)
    libc.syscall.restype = ctypes.c_long
    ctypes.set_errno(0)
    rc = libc.syscall(ctypes.c_long(312), ctypes.c_long(os.getpid()),
                      ctypes.c_long(os.getpid()), ctypes.c_long(0),
                      ctypes.c_ulong(pair[0]), ctypes.c_ulong(alias))
    saved = ctypes.get_errno()
    report["kcmp_probe"] = {"attempts": 1, "nr": 312, "rc": rc,
                            "errno": saved if rc < 0 else 0,
                            "scope": "self-owned pipe read end and dup alias"}
    if rc < 0 and saved in BLOCKING_ERRNOS:
        report["kcmp_probe"]["status"] = "BLOCKED"
        report["limitations"].append("kcmp denied/unsupported; no kcmp-dependent identity claim")
    else:
        check(rc == 0, "kcmp did not recognize its known dup alias")
        report["kcmp_probe"]["status"] = "PASS_ORDINARY_FIXTURE_ONLY"
    report["primitive_probe"]["step"] = "ordinary_fork_reap"
    child = o.fork(lambda: None)
    check(o.reap(child) == 0, "ordinary fork/reap primitive failed")
    report["primitive_probe"] = {"status": "PASS_REQUIRED_ORDINARY_PRIMITIVES", "attempts": 1,
        "features": ["AF_UNIX SOCK_SEQPACKET listener/connect/accept", "SO_PASSCRED",
                     "SO_PEERCRED", "SO_PEERPIDFD", "SO_PASSPIDFD/SCM_PIDFD",
                     "MSG_CMSG_CLOEXEC", "read-only proc/ns handles", "pipe2/dup", "fork/waitpid"]}


def sender_substitution(o: Owner, report: dict) -> None:
    listener, client, accepted = connected(o)
    original, pidfd = peer_pidfd(o, accepted)
    command = o.pipe()
    send(client, b"creator-queued-first")

    def child_body():
        listener.close()
        accepted.close()
        os.close(pidfd)
        os.close(command[1])
        poll_one(command[0], select.POLLIN, now() + 1_000_000_000)
        check(os.read(command[0], 1) == b"S", "missing child start command")
        send(client, b"inherited-same-uid-sender")
        client.close()

    child = o.fork(child_body)
    o.close_fd(command[0])
    o.close_sock(client)
    check(not ready(accepted.fileno(), select.POLLHUP) & select.POLLHUP,
          "endpoint reached EOF while inherited writer still held")
    os.write(command[1], b"S")
    first, first_records, _ = receive(o, accepted)
    second, second_records, _ = receive(o, accepted)
    current = struct.unpack("3i", accepted.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))
    check(first == b"creator-queued-first" and credentials(first_records) == [list(original)],
          "first queued sender credentials were not original creator")
    check(second == b"inherited-same-uid-sender" and
          credentials(second_records) == [[child, original[1], original[2]]],
          "inherited sender substitution was not observed per message")
    check(current == original and child != original[0], "connection credential snapshot changed")
    check(o.reap(child) == 0, "inherited sender child failed")
    payload, records, flags = receive(o, accepted)
    hup = ready(accepted.fileno(), select.POLLIN | select.POLLHUP | select.POLLRDHUP)
    check(payload == b"" and not rights(records) and hup & (select.POLLHUP | select.POLLRDHUP),
          "expected actual endpoint closure after queued records")
    check(not ready(pidfd), "creator still alive yet original pidfd ready")
    note_case(report, "S1_inherited_same_UID_sender", connection_peer=list(original),
              message_sender=[child, original[1], original[2]], same_uid_is_authority=False)
    note_case(report, "S2_queued_creator_then_substitute", first_sender=credentials(first_records),
              second_sender=credentials(second_records), per_message_check_required=True)
    note_case(report, "S3_EOF_with_live_connection_creator", eof_flags=flags,
              socket_poll=hup, original_pidfd_ready=False, EOF_is_peer_death=False)


def peer_death(o: Owner, report: dict) -> None:
    listener = o.sock(socket.socket(socket.AF_UNIX, socket.SOCK_SEQPACKET | socket.SOCK_CLOEXEC))
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_PASSCRED, 1)
    address = b"\0knowledge-a3-death-" + str(os.getpid()).encode() + b"-" + str(now()).encode()
    listener.bind(address)
    listener.listen(1)
    transfer_parent, transfer_child = (o.sock(s) for s in socket.socketpair(
        socket.AF_UNIX, socket.SOCK_SEQPACKET | socket.SOCK_CLOEXEC))
    command = o.pipe()

    def child_body():
        transfer_parent.close()
        listener.close()
        os.close(command[1])
        client = socket.socket(socket.AF_UNIX, socket.SOCK_SEQPACKET | socket.SOCK_CLOEXEC)
        client.setblocking(False)
        client.connect(address)
        send(transfer_child, b"client-handle", [client.fileno()])
        poll_one(command[0], select.POLLIN, now() + 1_000_000_000)
        check(os.read(command[0], 1) == b"D", "missing creator-death command")
        client.close()
        transfer_child.close()

    child = o.fork(child_body)
    o.close_sock(transfer_child)
    o.close_fd(command[0])
    poll_one(listener.fileno(), select.POLLIN, o.deadline)
    accepted = o.sock(listener.accept()[0])
    accepted.setsockopt(socket.SOL_SOCKET, socket.SO_PASSCRED, 1)
    accepted.setsockopt(socket.SOL_SOCKET, SO_PASSPIDFD, 1)
    original, pidfd = peer_pidfd(o, accepted)
    check(original == (child, os.geteuid(), os.getegid()), "creator credentials mismatch")
    # One initial proc lookup, bracketed by the exact socket-issued pidfd.
    check(not ready(pidfd), "creator died before proc capture")
    proc = o.fd(os.open("/proc/" + str(original[0]), os.O_RDONLY | os.O_DIRECTORY |
                        os.O_NOFOLLOW | os.O_CLOEXEC))
    check(not ready(pidfd), "creator died during initial proc capture")
    held_ns = namespaces(o, proc, keep=True)
    poll_one(transfer_parent.fileno(), select.POLLIN, o.deadline)
    payload, ancillary, flags, _ = transfer_parent.recvmsg(64, 4096,
                                     socket.MSG_DONTWAIT | socket.MSG_CMSG_CLOEXEC)
    received = []
    for level, kind, raw in ancillary:
        if level == socket.SOL_SOCKET and kind in (socket.SCM_RIGHTS, SCM_PIDFD):
            values = array.array("i")
            values.frombytes(raw[:len(raw) - len(raw) % values.itemsize])
            for fd in values:
                o.fd(fd)
                received.append(fd)
    check(payload == b"client-handle" and not flags & (socket.MSG_TRUNC | socket.MSG_CTRUNC)
          and len(ancillary) == 1
          and ancillary[0][:2] == (socket.SOL_SOCKET, socket.SCM_RIGHTS)
          and len(received) == 1, "malformed fixture-local handle transfer")
    transferred_fd = received[0]
    check(fcntl.fcntl(transferred_fd, fcntl.F_GETFD) & fcntl.FD_CLOEXEC != 0,
          "transferred endpoint missing CLOEXEC")
    delegated = socket.socket(fileno=transferred_fd)
    o.fds.remove(transferred_fd)
    o.sock(delegated)
    os.write(command[1], b"D")
    death_ready = poll_one(pidfd, select.POLLIN, o.deadline)
    check(death_ready & select.POLLIN, "creator pidfd did not report death")
    # Deliberately do not reap yet. The delegated endpoint remains live.
    socket_before_reap = ready(accepted.fileno(), select.POLLIN | select.POLLHUP | select.POLLRDHUP)
    check(not socket_before_reap & (select.POLLHUP | select.POLLRDHUP),
          "creator exit unexpectedly closed its delegated endpoint")
    send(delegated, b"after-creator-exit")
    data, records, _ = receive(o, accepted)
    check(data == b"after-creator-exit" and
          credentials(records) == [[os.getpid(), os.geteuid(), os.getegid()]],
          "delegated message sender was not the current sender")
    current = struct.unpack("3i", accepted.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))
    check(current == original, "dead creator connection snapshot changed")
    survived = []
    for obs in held_ns:
        st = os.fstat(obs["held_fd"])
        survived.append([st.st_dev, st.st_ino])
        check((st.st_dev, st.st_ino) == (obs["dev"], obs["ino"]), "held ns object changed")
    check(o.reap(child) == 0, "creator child failed")
    after_reap = ready(pidfd)
    check(after_reap & select.POLLIN, "original pidfd lost dead state after reap")
    try:
        status = o.fd(os.open("status", os.O_RDONLY | os.O_CLOEXEC | os.O_NONBLOCK,
                              dir_fd=proc))
    except OSError as exc:
        held_proc_result = {"rc": -1, "errno": exc.errno}
    else:
        raw = os.read(status, 4096)
        held_proc_result = {"rc": 0, "bytes": len(raw)}
        o.close_fd(status)
    o.close_sock(delegated)
    eof, eof_records, eof_flags = receive(o, accepted)
    hup = ready(accepted.fileno(), select.POLLIN | select.POLLHUP | select.POLLRDHUP)
    check(eof == b"" and not rights(eof_records) and hup & (select.POLLHUP | select.POLLRDHUP),
          "delegated endpoint closure did not produce separate EOF")
    note_case(report, "D1_creator_dead_unreaped_endpoint_live", pidfd_poll=death_ready,
              socket_poll_before_reap=socket_before_reap, socket_credential=list(current),
              later_message_sender=credentials(records), reaped_after_measurement=True)
    note_case(report, "D2_retained_dead_pidfd_and_proc", pidfd_poll_after_reap=after_reap,
              held_proc_after_reap=held_proc_result, numeric_proc_lookups=1,
              numeric_proc_reopens=0, actual_PID_number_reuse="NOT_RUN")
    note_case(report, "D3_ns_handle_survives_death_not_liveness", held_namespace_objects=survived,
              final_liveness_guard_would_refuse=True, ns_transition="NOT_RUN",
              endpoint_EOF_observed_separately=True, eof_flags=eof_flags)


def valid_fds() -> set[int]:
    # Exclude the transient fd used by listdir itself, which is closed on return.
    values = set()
    for name in os.listdir("/proc/self/fd"):
        fd = int(name)
        try:
            fcntl.fcntl(fd, fcntl.F_GETFD)
        except OSError as exc:
            if exc.errno != errno.EBADF:
                raise
        else:
            values.add(fd)
    return values


def ancillary_cases(o: Owner, report: dict) -> None:
    _, client, accepted = connected(o)
    pair = o.pipe()
    baseline = valid_fds()
    send(client, b"X" * 128, [pair[0], pair[0]])
    payload, records, flags = receive(o, accepted, 16)
    duplicated = rights(records)
    check(flags & socket.MSG_TRUNC and len(payload) == 16,
          "MSG_TRUNC scenario was not exercised")
    check(len(duplicated) == 2 and duplicated[0]["fd"] != duplicated[1]["fd"]
          and (duplicated[0]["dev"], duplicated[0]["ino"]) ==
              (duplicated[1]["dev"], duplicated[1]["ino"]),
          "duplicate rights did not install distinct alias descriptors")
    check(valid_fds() == baseline, "descriptor leak after payload truncation")
    send(client, b"C", [pair[0]] * 8)
    payload, ctr_records, ctr_flags = receive(o, accepted, 64,
                      socket.CMSG_SPACE(12) + socket.CMSG_SPACE(8))
    check(payload == b"C" and ctr_flags & socket.MSG_CTRUNC,
          "MSG_CTRUNC scenario was not exercised")
    check(valid_fds() == baseline, "descriptor leak after control truncation")
    note_case(report, "A1_TRUNC_CTRUNC_sweep_first", payload_truncated_flags=flags,
              control_truncated_flags=ctr_flags, visible_truncated_rights=len(rights(ctr_records)),
              no_descriptor_leak=True, ancillary_retired_before_decision=True)
    send(client, b"", [pair[0]])
    zero, zero_records, zero_flags = receive(o, accepted)
    check(zero == b"" and len(rights(zero_records)) == 1,
          "zero-payload rights packet not exercised")
    send(client, b"still-live")
    follow, _, _ = receive(o, accepted)
    check(follow == b"still-live", "zero payload was incorrectly treated as EOF")
    o.close_sock(client)
    eof, eof_records, eof_flags = receive(o, accepted)
    hup = ready(accepted.fileno(), select.POLLIN | select.POLLHUP | select.POLLRDHUP)
    check(eof == b"" and not rights(eof_records) and hup & (select.POLLHUP | select.POLLRDHUP),
          "actual EOF was not observed separately")
    note_case(report, "A2_zero_packet_rights_then_actual_EOF", zero_packet_flags=zero_flags,
              actual_EOF_flags=eof_flags, actual_EOF_poll=hup,
              zero_payload_alone_means_EOF=False)
    check(sum(r["type"] == SCM_PIDFD for r in records) == 1,
          "unexpected SCM_PIDFD retirement was not exercised")
    note_case(report, "A3_duplicate_OFD_rights_and_SCM_PIDFD", duplicate_rights=duplicated,
              all_visible_descriptors_closed=True, auto_pidfd_retired=True,
              malformed_duplicate_credentials="MODEL_ONLY")


def pipe_cases(o: Owner, report: dict) -> None:
    out = o.pipe()
    err = o.pipe()
    identity = lambda fd: (os.fstat(fd).st_dev, os.fstat(fd).st_ino)
    check(identity(out[0]) == identity(out[1]) and identity(err[0]) == identity(err[1])
          and identity(out[0]) != identity(err[0]), "pipe object identity mismatch")
    alias = o.fd(os.dup(out[0]))
    old = fcntl.fcntl(out[0], fcntl.F_GETFL)
    writer_old = fcntl.fcntl(out[1], fcntl.F_GETFL)
    other_old = fcntl.fcntl(err[0], fcntl.F_GETFL)
    try:
        fcntl.fcntl(alias, fcntl.F_SETFL, old & ~os.O_NONBLOCK)
        check(not fcntl.fcntl(out[0], fcntl.F_GETFL) & os.O_NONBLOCK,
              "known dup alias did not share reader status flags")
        check(fcntl.fcntl(out[1], fcntl.F_GETFL) == writer_old and
              fcntl.fcntl(err[0], fcntl.F_GETFL) == other_old,
              "reader OFD flags leaked into another OFD")
    finally:
        fcntl.fcntl(alias, fcntl.F_SETFL, old)
    check(fcntl.fcntl(out[0], fcntl.F_GETFL) == old, "reader flags not restored")
    writer_alias = o.fd(os.dup(out[1]))
    o.close_fd(out[1])
    try:
        os.read(out[0], 1)
    except BlockingIOError as exc:
        check(exc.errno == errno.EAGAIN, "unexpected live writer read result")
    else:
        raise AssertionError("writer alias did not retain pipe liveness")
    o.close_fd(writer_alias)
    check(os.read(out[0], 1) == b"", "EOF absent after last writer alias retired")
    note_case(report, "P1_dup_alias_shares_O_NONBLOCK", shared_reader_flags=True,
              numeric_descriptor_identity_sufficient=False, flags_restored=True)
    note_case(report, "P2_opposite_endpoints_same_inode_different_OFD", out_inode=list(identity(out[0])),
              err_inode=list(identity(err[0])), opposite_access_modes=True,
              writer_status_flags_independent=True)
    note_case(report, "P3_writer_alias_delays_EOF", original_writer_closed=True,
              EOF_only_after_last_writer=True, distinct_objects_prove_exclusive_custody=False)


def namespace_cases(o: Owner, report: dict) -> None:
    proc = o.fd(os.open("/proc/self", os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC))
    first = namespaces(o, proc)
    second = namespaces(o, proc)
    before_ids = [(x["dev"], x["ino"]) for x in first]
    after_ids = [(x["dev"], x["ino"]) for x in second]
    check(before_ids == after_ids, "namespace changed during fixture baseline")
    note_case(report, "N1_separate_readonly_namespace_observations", reads=first,
              atomic_snapshot=False, hybrid_transition="NOT_RUN")
    # An observation of equality has no evidence about the open interval. Do
    # not pretend to execute unshare/setns or relabel a logical trace as native.
    report["checks"].append({"id": "N2_ABA_namespace_transition", "status": "NOT_RUN",
        "reason": "No namespace transitions are authorized in these ordinary fixtures",
        "observed_final_equality": True, "ABA_excluded": False,
        "source_model_cross_reference": "intake model N04/N05 are drift negatives, not physical ABA proof"})
    note_case(report, "N3_live_self_readonly_baseline_only", observations=second,
              held_handle_is_liveness=False,
              peer_death_observation_case="D3_ns_handle_survives_death_not_liveness")


def deadline_cases(o: Owner, report: dict) -> None:
    _, client, accepted = connected(o)
    origin = now()
    work_end = origin + 30_000_000
    cleanup_end = work_end + 30_000_000
    attempts = 0
    attempt_bounds = []
    while now() < work_end:
        before = now()
        if before >= work_end:
            break
        try:
            unexpected = accepted.recvmsg(64, 4096,
                            socket.MSG_DONTWAIT | socket.MSG_CMSG_CLOEXEC)
        except BlockingIOError:
            attempts += 1
            attempt_bounds.append({"before_ns": before, "after_ns": now(), "errno": errno.EAGAIN})
        else:
            ancillary_retire(o, unexpected[1])
            raise AssertionError("unexpected packet in EAGAIN deadline fixture")
        time.sleep(0.002)
    check(attempts > 0, "scheduler prevented the EAGAIN scenario from executing")
    check(work_end == origin + 30_000_000 and cleanup_end == origin + 60_000_000,
          "fixture refreshed original deadline")
    note_case(report, "T1_EAGAIN_no_fresh_budget", original_S=origin, original_W=work_end,
              original_C=cleanup_end, EAGAIN_attempts=attempts,
              attempt_bounds=attempt_bounds, post_expiry_retry_authorized=False,
              kernel_entry_time_measured=False, implementation_under_test="fixture_policy_only")

    command = o.pipe()
    sent_pipe = o.pipe()
    listener2, client2, accepted2 = connected(o)

    def late_child():
        listener2.close()
        accepted2.close()
        os.close(command[1])
        poll_one(command[0], select.POLLIN, now() + 1_000_000_000)
        check(os.read(command[0], 1) == b"L", "missing late send command")
        time.sleep(0.25)
        send(client2, b"late-rights", [sent_pipe[0]])

    child = o.fork(late_child)
    o.close_fd(command[0])
    o.close_sock(client2)
    late_origin = now()
    late_w = late_origin + 100_000_000
    late_c = late_origin + 150_000_000
    os.write(command[1], b"L")
    # Deliberate fixture blocking receive illustrates an already-started
    # operation finishing late. Production intake is not invoked here.
    accepted2.settimeout(0.8)
    began = now()
    payload, records, flags, _ = accepted2.recvmsg(64, 4096, socket.MSG_CMSG_CLOEXEC)
    returned = now()
    observations = ancillary_retire(o, records)
    retired = now()
    accepted2.setblocking(False)
    check(began < late_w and returned >= late_c and retired >= late_c,
          "late completion schedule was not observed")
    check(payload == b"late-rights" and len(rights(observations)) == 1
          and not flags & (socket.MSG_TRUNC | socket.MSG_CTRUNC),
          "late rights message malformed")
    check(o.reap(child) == 0, "late sender child failed")
    note_case(report, "T2_late_receive_and_cleanup_retained_as_late", original_S=late_origin,
              original_W=late_w, original_C=late_c, receive_userspace_before_ns=began,
              receive_returned_ns=returned, rights_retired_ns=retired,
              timely_completion=False, deadline_rearmed=False,
              exact_kernel_entry_time_measured=False, subject_deadline_interruptibility_proven=False)

    cancelled_start = now()
    cancelled_w = cancelled_start + 100_000_000
    cancelled_c = cancelled_w + 100_000_000

    def cancel_handler(signum, frame):
        raise Cancelled("fixture-local cancellation")

    previous = signal.signal(signal.SIGALRM, cancel_handler)
    try:
        signal.setitimer(signal.ITIMER_REAL, 0.02)
        try:
            poll_one(accepted.fileno(), select.POLLIN, cancelled_w)
        except Cancelled:
            cancelled_at = now()
        else:
            raise AssertionError("fixture cancellation did not interrupt wait")
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous)
    check(cancelled_at < cancelled_w, "cancellation schedule missed original W")
    note_case(report, "T3_cancellation_keeps_original_bounds", original_W=cancelled_w,
              original_C=cancelled_c, cancelled_at_ns=cancelled_at, new_wait_budget=False,
              native_recv_EINTR="MODEL_ONLY_O11", native_close_EINTR="MODEL_ONLY_A16_O15",
              Python_signal_exception_is_native_EINTR_proof=False)


CASES = (("sender", sender_substitution), ("death", peer_death),
         ("ancillary", ancillary_cases), ("pipes", pipe_cases),
         ("namespaces", namespace_cases), ("deadlines", deadline_cases))


def main() -> int:
    report = {"schema": "a3-ordinary-socket-fixtures.v1", "argv": sys.argv,
        "python": sys.version, "kernel_release": platform.release(),
        "machine": platform.machine(), "uid": os.getuid(), "euid": os.geteuid(),
        "gid": os.getgid(), "egid": os.getegid(), "events": [], "checks": [],
        "fixture_children_created": 0, "native_Main_H_Node_bundle": "NOT_RUN",
        "case_groups": {label: "NOT_RUN" for label, _ in CASES},
        "intake_source_execution": "NOT_RUN", "physical_birth_proof": False,
        "WSL_original_profile_proof": False, "offer_release_exec": "EOPNOTSUPP_UNCHANGED",
        "limitations": ["Ordinary Linux mechanics only, not original WSL/profile proof",
            "No actual PID-number reuse forced or claimed; source model O09 is separate",
            "No namespace transition, hybrid snapshot or ABA physical proof",
            "No production deadline interruptibility or successful offer/release/exec proof"],
        "primitive_probe": {"status": "NOT_RUN", "attempts": 0}, "result": "IN_PROGRESS"}
    result = 0
    try:
        if sys.platform != "linux" or platform.machine() not in ("x86_64", "amd64"):
            raise Blocked("requires exact Linux x86_64 ABI; no alternative syscall numbers guessed")
        if 0 in (os.getuid(), os.geteuid(), os.getgid(), os.getegid()):
            raise Blocked("unprivileged fixture required; uid/gid zero; no identity changes attempted")
        selected = {}
        credential_fields = {}
        with open("/proc/self/status", encoding="ascii") as stream:
            for line in stream:
                key, _, value = line.partition(":")
                if key in ("CapInh", "CapPrm", "CapEff", "CapAmb"):
                    selected[key] = int(value.strip(), 16)
                elif key in ("Uid", "Gid"):
                    credential_fields[key] = [int(x) for x in value.split()]
        report["own_active_capability_sets"] = selected
        report["own_credential_fields"] = credential_fields
        if len(selected) != 4 or any(selected.values()):
            raise Blocked("requires zero inherited/permitted/effective/ambient capabilities")
        if len(set(os.getresuid())) != 1 or len(set(os.getresgid())) != 1:
            raise Blocked("requires equal real/effective/saved nonzero credentials")
        if credential_fields != {"Uid": [os.getuid()] * 4, "Gid": [os.getgid()] * 4}:
            raise Blocked("requires equal nonzero real/effective/saved/filesystem Uid/Gid")
        owner = Owner(report, "single_primitive_probe")
        try:
            prerequisites(owner, report)
        finally:
            owner.clean()
        for label, fn in CASES:
            owner = Owner(report, label)
            report["case_groups"][label] = "IN_PROGRESS"
            try:
                fn(owner, report)
                report["case_groups"][label] = "ORDINARY_OBSERVATIONS_RECORDED"
            except OSError as exc:
                if exc.errno in BLOCKING_ERRNOS:
                    report["case_groups"][label] = "BLOCKED"
                    report["checks"].append({"id": label, "status": "BLOCKED", "errno": exc.errno,
                                             "reason": str(exc), "no_unchanged_retry": True})
                    raise Blocked(label + " prerequisite refused; remaining dependent fixtures NOT_RUN")
                report["case_groups"][label] = "FAIL"
                report["checks"].append({"id": label, "status": "FAIL", "errno": exc.errno,
                                         "error": str(exc)})
                raise
            except BaseException as exc:
                report["case_groups"][label] = "FAIL"
                report["checks"].append({"id": label, "status": "FAIL",
                                         "error": type(exc).__name__ + ": " + str(exc)})
                traceback.print_exc(file=sys.stderr)
                result = 1
            finally:
                owner.clean()
        report["result"] = "FAIL" if result else "PARTIAL_ORDINARY_FIXTURES_ONLY"
        if not result and report.get("kcmp_probe", {}).get("status") == "BLOCKED":
            report["result"] = "PARTIAL_ORDINARY_FIXTURES_KCMP_BLOCKED"
            result = 77
    except Blocked as exc:
        report.update(result="FAIL_WITH_LATER_BLOCKER" if result else "BLOCKED",
                      reason=str(exc), no_unchanged_retry=True,
                      missing_runs_are_PASS=False)
        result = 1 if result else 77
    except OSError as exc:
        missing_proc_abi = (report["primitive_probe"].get("status") == "IN_PROGRESS"
            and report["primitive_probe"].get("step") == "read_only_proc_namespace_handles"
            and exc.errno in (errno.ENOENT, errno.ENOTDIR, errno.ENOTTY))
        if exc.errno in BLOCKING_ERRNOS or missing_proc_abi:
            report.update(result="FAIL_WITH_LATER_BLOCKER" if result else "BLOCKED",
                          reason=str(exc), errno=exc.errno,
                          no_unchanged_retry=True)
            result = 1 if result else 77
        else:
            report.update(result="FAIL", reason=type(exc).__name__ + ": " + str(exc))
            traceback.print_exc(file=sys.stderr)
            result = 1
    except BaseException as exc:
        report.update(result="FAIL", reason=type(exc).__name__ + ": " + str(exc))
        traceback.print_exc(file=sys.stderr)
        result = 1
    finally:
        if report["primitive_probe"]["status"] == "IN_PROGRESS":
            report["primitive_probe"]["status"] = report["result"]
        if result == 77 or report["result"] == "FAIL_WITH_LATER_BLOCKER":
            for label, state in report["case_groups"].items():
                if state in ("NOT_RUN", "IN_PROGRESS"):
                    report["case_groups"][label] = "BLOCKED_NOT_RUN"
        report["rc"] = result
        report["finished_monotonic_ns"] = now()
        print(json.dumps(report, indent=2, sort_keys=True))
    return result


if __name__ == "__main__":
    raise SystemExit(main())
