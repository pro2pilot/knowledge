#!/usr/bin/env python3
"""A3 replay of pinned syscall models, with external evidence validation.

Only the existing source-reviewed syscall-replaced models are executable.
Native compile objects are never linked or executed. Negative source mutations
are isolated copies and must stop before model link or execution.
"""
from __future__ import annotations

import argparse
import collections
import copy
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time


MANIFEST_SHA256 = "8ac2c1b86170c70dcee36f5a4fe878688e32f9ca0b7f8032998316fd79a8eb55"
EXPECTATIONS_SHA256 = "873f77ca89ead2107812a05ce8a3d8d7f2462ca07d86399482ce9351c3933be9"
CORE_MODEL = "tests/main_h_core_model.c"
INTAKE_MODEL = "intake-slice/tests/main_intake_model.c"
EXPECTED_FAULT_COUNTS = {"open": 1, "openat": 51, "fcntl": 66, "fstat": 49,
                         "fstatfs": 1, "ioctl": 43, "getsockopt": 16,
                         "accept4": 1, "poll": 38, "recvmsg": 1, "read": 6,
                         "pipe2": 2, "clock": 455}


def sha(data: bytes) -> dict:
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def no_duplicate_keys(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError("duplicate JSON key: " + key)
        value[key] = item
    return value


def parse_jsonl(data: bytes) -> list[dict]:
    if not data.endswith(b"\n"):
        raise ValueError("truncated JSONL: final newline absent")
    lines = data.decode("utf-8").splitlines()
    if not lines or any(not line for line in lines):
        raise ValueError("empty JSONL or blank record")
    rows = [json.loads(line, object_pairs_hook=no_duplicate_keys) for line in lines]
    if any(not isinstance(r, dict) for r in rows):
        raise ValueError("records must be JSON objects")
    return rows


def source_inventory(source: Path, kind: str, rows: list[dict]) -> set[str]:
    """Inventory comes from pinned source literals and its explicit loops.

    The intake partial-failure loops use F00 acquisition counts frozen after
    independent source/trace review and recorded in model_expectations.json.
    F00's trace must match them; co-tampering the trace and case list is rejected.
    This is evidence integrity, not an independent behavioral oracle.
    """
    code = (source / (CORE_MODEL if kind == "core" else INTAKE_MODEL)).read_text()
    names = re.findall(r'"([A-Z][0-9]{2}_[A-Za-z0-9_]+)"', code)
    if len(names) != len(set(names)):
        raise ValueError("source literal case identifiers are not unique")
    expected = set(names)
    if kind == "intake":
        expected.update(f"N06_status_{name}_position_{i}" for name in
                        ("Uid", "Gid", "capability") for i in range(1, 5))
        expected.update(f"N07_malformed_status_mode_{i}" for i in (2, 4, 5, 6, 7, 9, 10))
        bases = [r for r in rows if r.get("id") == "F00_baseline_acquisition_counts"]
        if len(bases) != 1:
            raise ValueError("missing/duplicate F00 acquisition trace")
        events = bases[0].get("trace", [])
        acquisition = []
        # ix_end invokes mi_finish_original. Its initial getpid observes phase
        # B1_READY, then cancellation sets MI_TERMINAL before close operations.
        # None of those extra getpid events belongs to the faulted op list.
        for event in events:
            if event.get("phase", -1) >= 6:  # MI_TERMINAL or MI_FINISHED
                break
            acquisition.append(event)
        counts = collections.Counter(e["op"] for e in acquisition)
        if any(counts[op] != count for op, count in EXPECTED_FAULT_COUNTS.items()):
            raise ValueError("F00 counts differ from independently reviewed frozen expectations")
        ops = ("open", "openat", "fcntl", "fstat", "fstatfs", "ioctl", "getsockopt",
               "accept4", "poll", "recvmsg", "read", "pipe2")
        if any(counts[op] < 1 for op in ops) or counts["clock"] < 2:
            raise ValueError("incomplete F00 acquisition operations")
        for op in ops:
            expected.update(f"F01_partial_{op}_call_{i}" for i in range(1, EXPECTED_FAULT_COUNTS[op] + 1))
        expected.update(f"F02_clock_error_at_{i}" for i in
                        (1, EXPECTED_FAULT_COUNTS["clock"] // 2, EXPECTED_FAULT_COUNTS["clock"]))
    if len(expected) != (130 if kind == "core" else 380):
        raise ValueError("source inventory differs from independently reviewed frozen case count")
    return expected


def validate_records(rows: list[dict], expected: set[str], kind: str) -> dict:
    if not rows or any(not isinstance(r, dict) for r in rows):
        raise ValueError("records must be JSON objects")
    if any(r.get("kind") not in ("case", "summary") for r in rows):
        raise ValueError("unknown record kind")
    summaries = [r for r in rows if r.get("kind") == "summary"]
    cases = [r for r in rows if r.get("kind") == "case"]
    if len(summaries) != 1 or rows[-1] is not summaries[0]:
        raise ValueError("exactly one final summary required")
    ids = [r.get("id") for r in cases]
    if any(not isinstance(i, str) for i in ids) or len(ids) != len(set(ids)):
        raise ValueError("missing/duplicate/nonstring case id")
    if set(ids) != expected:
        raise ValueError("case inventory mismatch: missing=" + str(sorted(expected - set(ids))) +
                         " extra=" + str(sorted(set(ids) - expected)))
    if any(type(r.get("passed")) is not bool or not isinstance(r.get("errors"), list) for r in cases):
        raise ValueError("case boolean/errors schema invalid")
    passed = sum(r["passed"] for r in cases)
    failed = len(cases) - passed
    summary = summaries[0]
    if (type(summary.get("passed")) is not int or type(summary.get("failed")) is not int or
            summary["passed"] != passed or summary["failed"] != failed):
        raise ValueError("summary/case count mismatch")
    if failed or any(r["errors"] for r in cases):
        raise ValueError("failed case or nonempty assertion errors")
    for row in cases:
        mode = ("ACTUAL_INTAKE_SYSCALL_MODEL_NOT_NATIVE_PROOF" if kind == "intake" else
                "SYSCALL_MODEL_NOT_NATIVE_PROOF")
        if row.get("mode") != mode:
            raise ValueError("case classification mismatch")
        receipt = row.get("receipt", {})
        zero_keys = ("births", "release_bytes", "exec_attempts") if kind == "intake" else (
            "released", "exec_attempted", "gate_bytes_sent")
        if any(receipt.get(k) != 0 for k in zero_keys):
            raise ValueError("forbidden model authority/exec/release observation")
    if kind == "intake" and (summary.get("native_Main_H") != "NOT_RUN" or
                             summary.get("physical_proof") is not False or
                             summary.get("stage_A_cases_executed") != 0):
        raise ValueError("intake classification mismatch")
    if kind == "core" and summary.get("mode") != "MODEL_NOT_NATIVE_PROOF":
        raise ValueError("core summary classification mismatch")
    return {"passed": passed, "failed": failed, "unique_cases": len(expected),
            "case_ids": sorted(expected), "classification": "SOURCE_MODEL_ONLY"}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input-dir", type=Path, required=True)
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--review-json", type=Path, required=True)
    args = ap.parse_args()
    source = args.input_dir.resolve() / "source4"
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=False)
    report = {"schema": "a3-model-qualification.v1", "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
              "actions": [], "checks": [], "result": "IN_PROGRESS", "native_Main_H": "NOT_RUN",
              "Node_bundle": "NOT_RUN", "release": "NOT_QUALIFIED", "script": sha(Path(__file__).read_bytes())}
    env = {"PATH": os.defpath, "LANG": "C", "LC_ALL": "C", "PYTHONDONTWRITEBYTECODE": "1"}

    def persist():
        (output / "RESULT.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")

    def check(name, good, detail):
        report["checks"].append({"name": name, "passed": bool(good), "detail": detail})
        persist()
        if not good:
            raise ValueError(name + ": " + str(detail))

    def run(name, argv, timeout=90):
        prefix = f"{len(report['actions']):02d}-{name}"
        action = {"label": name, "argv": [str(x) for x in argv], "cwd": str(source),
                  "timeout_seconds": timeout, "stdout": prefix + ".stdout.bin", "stderr": prefix + ".stderr.bin"}
        started = time.monotonic_ns()
        try:
            completed = subprocess.run(action["argv"], cwd=source, env=env, capture_output=True,
                                       timeout=timeout, check=False)
            rc, stdout, stderr = completed.returncode, completed.stdout, completed.stderr
        except subprocess.TimeoutExpired as exc:
            rc, stdout, stderr = 124, exc.stdout or b"", exc.stderr or b""
            action["timeout"] = True
        except OSError as exc:
            rc, stdout, stderr = 125, b"", str(exc).encode()
        (output / action["stdout"]).write_bytes(stdout)
        (output / action["stderr"]).write_bytes(stderr)
        action.update(rc=rc, duration_ns=time.monotonic_ns() - started)
        report["actions"].append(action)
        persist()
        return rc

    try:
        manifest_bytes = (args.input_dir / "MANIFEST.json").read_bytes()
        check("pinned_input_manifest", hashlib.sha256(manifest_bytes).hexdigest() == MANIFEST_SHA256,
              sha(manifest_bytes))
        manifest = json.loads(manifest_bytes)["files"]
        for name, pin in manifest.items():
            if sha((args.input_dir / name).read_bytes()) != pin:
                raise ValueError("input byte pin mismatch: " + name)
        check("input_payload", True, {"verified_files": len(manifest)})
        expectations_bytes = Path(__file__).with_name("model_expectations.json").read_bytes()
        expectations = json.loads(expectations_bytes)
        check("reviewed_expectations_document", hashlib.sha256(expectations_bytes).hexdigest() == EXPECTATIONS_SHA256 and
              expectations.get("input_manifest_sha256") == MANIFEST_SHA256 and
              expectations.get("case_counts") == {"core": 130, "intake": 380} and
              expectations.get("intake_preterminal_fault_operation_counts") == EXPECTED_FAULT_COUNTS,
              sha(expectations_bytes))
        review = json.loads(args.review_json.read_bytes())
        check("review_allows_exact_source_model", review.get("allow_compile_model") is True,
              sha(args.review_json.read_bytes()))
        for name, pin in review.get("source_pins", {}).items():
            if sha((source / name).read_bytes()) != pin:
                raise ValueError("review source mismatch: " + name)
        check("review_pin_count", len(review.get("source_pins", {})) == 14, "14 reviewed inputs")
        validated = {}
        frozen_expected = {}
        for kind, runner in (("core", source / "tests/run_checks.py"),
                             ("intake", source / "intake-slice/tests/run_checks.py")):
            destination = output / kind
            argv = [sys.executable, runner, "--output-dir", destination]
            if kind == "intake":
                argv += ["--review-json", args.review_json.resolve()]
            rc = run(kind + "-pinned-runner", argv)
            detail = json.loads((destination / "RESULT.json").read_bytes())
            check(kind + "_runner", rc == 0 and detail.get("result") == "PASS_SOURCE_MODEL_ONLY", detail.get("reason"))
            check(kind + "_symbol_guard", detail.get("model_symbol_guard", {}).get("pass") is True,
                  detail.get("model_symbol_guard"))
            actions = [a for a in detail["actions"] if a["label"] == "model-execution"]
            check(kind + "_one_model_execution", len(actions) == 1 and actions[0]["rc"] == 0, len(actions))
            raw = (destination / actions[0]["stdout"]).read_bytes()
            rows = parse_jsonl(raw)
            expected = source_inventory(source, kind, rows)
            validated[kind] = validate_records(rows, expected, kind)
            frozen_expected[kind] = expected
            check(kind + "_external_jsonl_inventory", True, {k: v for k, v in validated[kind].items() if k != "case_ids"})
            (output / (kind + "-case-inventory.json")).write_text(json.dumps(validated[kind], indent=2) + "\n")
            # In-memory forged evidence only. Original raw log remains intact.
            variants = {}
            bad = copy.deepcopy(rows); bad[0]["passed"] = False; bad[0]["errors"] = ["synthetic hidden failure"]
            variants["hidden_failed_case_success_summary"] = bad
            bad = copy.deepcopy(rows); bad.insert(1, copy.deepcopy(bad[0])); variants["duplicate_case"] = bad
            bad = copy.deepcopy(rows); del bad[0]; bad[-1]["passed"] -= 1; variants["missing_case_recounted_summary"] = bad
            bad = copy.deepcopy(rows); bad.append(copy.deepcopy(bad[-1])); variants["duplicate_summary"] = bad
            bad = copy.deepcopy(rows); bad[-1]["passed"] += 1; variants["count_mismatch"] = bad
            bad = copy.deepcopy(rows); bad[0]["passed"] = 1; variants["truthy_nonboolean_pass"] = bad
            bad = copy.deepcopy(rows); bad[0]["kind"] = "other"; variants["unknown_record"] = bad
            bad = copy.deepcopy(rows); bad[0]["mode"] = "NATIVE_PROOF"; variants["false_case_classification"] = bad
            negatives = []
            for label, altered in variants.items():
                try:
                    validate_records(altered, expected, kind)
                except (ValueError, KeyError, TypeError) as exc:
                    negatives.append({"scenario": label, "rejected": True, "reason": str(exc)})
                else:
                    negatives.append({"scenario": label, "rejected": False})
            for label, altered in (("truncated_record", raw[:-4]),
                                   ("duplicate_json_key", b'{"kind":"case","kind":"summary"}\n'),
                                   ("scalar_record", b'42\n')):
                try:
                    parse_jsonl(altered)
                except (ValueError, UnicodeDecodeError) as exc:
                    negatives.append({"scenario": label, "rejected": True, "reason": str(exc)})
                else:
                    negatives.append({"scenario": label, "rejected": False})
            if kind == "intake":
                altered = copy.deepcopy(rows)
                base = next(r for r in altered if r.get("id") == "F00_baseline_acquisition_counts")
                at = next(i for i, e in enumerate(base["trace"]) if e["op"] == "openat")
                del base["trace"][at]
                altered = [r for r in altered if r.get("id") != "F01_partial_openat_call_51"]
                altered[-1]["passed"] -= 1
                try:
                    source_inventory(source, kind, altered)
                except ValueError as exc:
                    negatives.append({"scenario": "co_tampered_F00_trace_and_case_inventory", "rejected": True, "reason": str(exc)})
                else:
                    negatives.append({"scenario": "co_tampered_F00_trace_and_case_inventory", "rejected": False})
            (output / (kind + "-evidence-negative-checks.json")).write_text(json.dumps(negatives, indent=2) + "\n")
            check(kind + "_forged_evidence_rejected", all(n["rejected"] for n in negatives), negatives)

        # M1: valid receipt structure with one stale reviewed model digest.
        stale = copy.deepcopy(review)
        stale["source_pins"][INTAKE_MODEL]["sha256"] = "0" * 64
        stale_path = output / "negative-stale-review.json"
        stale_path.write_text(json.dumps(stale, indent=2) + "\n")
        stale_dir = output / "negative-stale-review-run"
        rc = run("negative-stale-review", [sys.executable, source / "intake-slice/tests/run_checks.py",
                 "--output-dir", stale_dir, "--review-json", stale_path])
        detail = json.loads((stale_dir / "RESULT.json").read_bytes())
        check("stale_review_refuses_before_compiler", rc == 2 and not detail["actions"] and
              detail.get("exact_review_gate", {}).get("pass") is False, detail.get("reason"))

        # M2: an inert function retained in a disposable MODEL source has an
        # actual OS symbol. The original symbol guard must refuse before link.
        # It is never called or authorized to execute; no production edits.
        mutant = output / "negative-symbol-input"
        shutil.copytree(source, mutant)
        injected = b'\n/* A3 negative guard sentinel: NEVER EXECUTE. */\nstatic __attribute__((used)) uid_t a3_guard_os_symbol(void){return getuid();}\n'
        model = mutant / CORE_MODEL
        before = model.read_bytes()
        model.write_bytes(before + injected)
        report["negative_symbol_mutation"] = {"path": CORE_MODEL, "before": sha(before), "after": sha(model.read_bytes()),
                                               "injected_utf8": injected.decode(), "execution": "FORBIDDEN"}
        mutant_dir = output / "negative-symbol-run"
        rc = run("negative-unapproved-symbol", [sys.executable, mutant / "tests/run_checks.py", "--output-dir", mutant_dir])
        detail = json.loads((mutant_dir / "RESULT.json").read_bytes())
        labels = [a["label"] for a in detail["actions"]]
        check("subject_symbol_refuses_before_link_execution", rc == 1 and
              detail.get("model_symbol_guard", {}).get("unexpected") == ["getuid"] and
              "model-link" not in labels and "model-execution" not in labels and
              not (mutant_dir / "syscall-model").exists(), detail.get("model_symbol_guard"))
        for name, pin in manifest.items():
            if sha((args.input_dir / name).read_bytes()) != pin:
                raise ValueError("input mutated during qualification: " + name)
        check("inputs_unchanged_after_run", True, len(manifest))
        report["models"] = {k: {key: val for key, val in v.items() if key != "case_ids"} for k, v in validated.items()}
        report["result"] = "DONE_SOURCE_MODEL_ONLY"
        rc = 0
    except (OSError, ValueError, KeyError, TypeError) as exc:
        report["result"] = "FAIL"
        report["failure"] = str(exc)
        rc = 1
    report["finished_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
    persist()
    print(json.dumps({"result": report["result"], "models": report.get("models", {}),
                      "failure": report.get("failure"), "evidence": str(output)}, ensure_ascii=False))
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
