# A3 v1: полный derivative Main — compile-only

## Результат и граница

`PASS_COMPILE_ONLY`: весь неизменённый `private-main-intake.c` с реальными
закреплёнными заголовками компилируется внутри отдельной qualification translation
unit. Получен ELF64 relocatable object. Проверены 15 непустых локальных функций
в исполняемой секции `.text`, их disassembly и relocations всех 15 типизированных
удерживающих указателей. Никакой native object не линковался и не исполнялся.

Проверка не является производственной сборкой, проверкой линковки, runtime ABI,
физическим подтверждением Main/H, положительным offer/exec или release PASS.
Вызовы загрузчика configuration остаются внешними зависимостями объекта; их
реализации здесь не линковались. Полный offer и release продолжают возвращать
`EOPNOTSUPP` по неизменённым исходникам и отдельно проверяемой модели.

## Почему используется qualification wrapper

Первичная строгая компиляция самого derivative с `-I BASE_MAIN -I deps`
прошла preprocessing, но завершилась `rc=1`: шесть private-функций core не
используются terminal-only derivative, и `-Werror=unused-function` это отвергает.
Полный исходный stderr сохранён в `evidence/compile/baseline/`; FAIL не удалён и
не переименован в PASS.

Новый `compile_main.c` включает целиком тот же derivative и добавляет две
`static const __attribute__((used))` таблицы с точными сигнатурами. Такой способ
уже использован в исходных compile-only fixtures. Таблицы удерживают native
тела при `-O2`, не меняя core/intake и не экспортируя API. В полном объекте нет
`main`, `_start` или иных определённых GLOBAL/WEAK symbols. Предварительный
wrapper-проход сохранён отдельно в `evidence/compile/wrapper_probe/`.

Строгие флаги итоговой проверки:

```
-std=c11 -Wall -Wextra -Werror -Wpedantic -O2 -fno-builtin -save-temps=obj
```

`_GNU_SOURCE` задаёт сам неизменённый Main до первого include; повторный `-D`
для него не нужен. Флагов `-Wno-*`, stub headers и model-макросов нет.

## Точные входы и preprocess closure

Вход закреплён commit `0684ffa0d132675233d7d9602121f02bb50ff6eb` и SHA-256
`MANIFEST.json`:

```
8ac2c1b86170c70dcee36f5a4fe878688e32f9ca0b7f8032998316fd79a8eb55
```

Runner проверяет все 59 файлов по bytes/SHA-256, сверяет `DEPENDENCY_PINS.json`
и копирует только перечисленные входы в новый overlay. Входы проверяются снова
после работы. Реальная dependency map компилятора `-MD` содержит 229 уникальных
файлов: 28 закреплённых проектных файлов, 200 system headers и один новый
qualification wrapper. Для каждого сохранён SHA-256; для проектных зависимостей
проверено совпадение с входными pins. Компилятор: Ubuntu GCC 13.3.0; binutils
2.42. Полные версии и команды находятся в evidence.

Manifest содержит **32** файла `deps/`, а вместе с восьмью файлами BASE_MAIN —
40 файлов, что согласуется с `CONTEXT.json`. Фраза PROMPT о «34 extra» была отдельно исправлена оркестратором как описательная
ошибка: см. `reviews/ORCHESTRATOR_AMENDMENT_RU.md`. Дополнительные два файла не
требуются; immutable вход сохранён. Реальный
preprocessing полного derivative замкнут предоставленными файлами; отдельного
upstream commit для `deps` в `DEPENDENCY_PINS.json` нет. Подтверждена точность
именно данного закреплённого A3 input и совместимость declarations при этой
компиляции. Историческая upstream provenance независимо не установлена.

## Три сценария критика для compile closure

| Сценарий | Проверка и решение |
|---|---|
| Quoted include незаметно выбирает локальный старый header вместо deps | Frozen allowlist, реальный `-MD`, разрешённые compiler system roots и SHA всех project includes. Искусственный unpinned project header отвергнут dependency guard. |
| Одно имя в `nm` является U-symbol, OBJECT или нулевым телом | `readelf` требует `FUNC LOCAL`, конкретную `.text`, size > 0. Три отрицательные проверки изменённых parser-records отвергнуты. Это тест gate/parser, а не исполнение native-negative objects. |
| Таблица есть, но нужные entry bodies оптимизированы или pointer указывает не туда | Для всех 15 entry bodies проверены определения, disassembly labels и relocation каждого конкретного slot в таблицах. Инлайненные внутренние helpers допустимы; утверждение ограничено перечисленными private entry bodies и полным TU. |

## Генератор: изменений нет

Оригинальный `derive_main.py` дважды воспроизводит derivative и его receipt
байт-в-байт: read-only `--check` и `--write` в новом пустом fixture. Итоговый
runner `compile_generator_checks.py` даёт **11/11** source-generator проверок:

- Exact read-only reproduction и fresh write reproduction.
- Отказ `--write`, если оба файла, только derivative или только receipt уже
  существуют; полное дерево до/после совпадает.
- Отказ до создания outputs при изменении байта BASE_MAIN, core, переводе BASE
  в CRLF или добавлении duplicate anchor; срабатывает исходный pin guard.
- Отказ read-only check при изменённом derivative или отсутствующем receipt;
  никакой автоматической перезаписи/восстановления.

Все ожидаемые `rc=1` и traceback отсутствующего receipt сохранены. Это успешные
отрицательные проверки отказа, а не скрытые успешные вызовы генератора.
`generator_attempt1` предшествует добавлению `sys.dont_write_bytecode=True` в
новый qualification runner; `generator_attempt2` проверяет окончательные bytes
runner. Сам исходный генератор в обоих случаях идентичен входу.

## Повторение из корня checkout/распакованного результата

Выбрать новые, ещё не существующие output directories:

```sh
python3 orchestration/results/A3_v1/qualification/compile_qualification.py --input orchestration/stages/A3_qualification_v1/input --output a3-compile-replay
python3 orchestration/results/A3_v1/qualification/compile_generator_checks.py --input orchestration/stages/A3_qualification_v1/input --output a3-generator-replay
```

Для полученного отдельного source input заменить только значение `--input` на
его каталог. Runner не меняет input и откажется переиспользовать output.
Местные завершённые прогоны: `evidence/compile/qualification_attempt1` и
`evidence/compile/generator_attempt2`. Ни одна команда не запускает native
Main/H/Node/bundle и не проверяет privileged профиль исходного WSL окружения.
