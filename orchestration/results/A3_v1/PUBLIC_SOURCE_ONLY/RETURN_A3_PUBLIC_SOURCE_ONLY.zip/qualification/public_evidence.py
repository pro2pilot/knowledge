#!/usr/bin/env python3
"""Create an explicitly redacted text-evidence copy; never publish raw binaries.

Original evidence is read-only. No network, environment dump, upload, Git or
subject execution. Known local paths/host names are removed from public copies.
Literal secret/email detections stop packaging for human review. Pattern review
is limited evidence, not a guarantee against every possible secret encoding.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import zipfile


SKIP_COMPONENTS = {"sources", "frozen", "fixtures", "negative-symbol-input", "__pycache__"}
SECRET_PATTERNS = {
    "private_key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    "github_token": re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b"),
    "aws_access_key": re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b"),
    "openai_token": re.compile(r"\bsk-(?:proj-)?[A-Za-z0-9_-]{40,}\b"),
    "bearer_credential": re.compile(r"(?i)\bAuthorization\s*[:=]\s*[\"']?Bearer\s+[A-Za-z0-9._~+/-]{16,}"),
    "credential_in_url": re.compile(r"https?://[^\s/:@]+:[^\s/@]+@"),
    "email_address": re.compile(r"\b[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+\b"),
}


def pin(data: bytes) -> dict:
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def findings(text: str) -> dict[str, int]:
    return {label: len(pattern.findall(text)) for label, pattern in SECRET_PATTERNS.items()
            if pattern.search(text)}


def redact(text: str, workspace: str, hostname: str) -> tuple[str, dict]:
    changes = {}
    # The orchestrator allows versions and UID/GID/capability facts, not an
    # environment dump. Historical runner whitelists stay only in private raw.
    def scrub_fields(value):
        if isinstance(value, list):
            return [scrub_fields(v) for v in value]
        if not isinstance(value, dict):
            return value
        clean = {}
        for key, item in value.items():
            if key.casefold() in {"env", "environ", "subprocess_environment",
                                   "process_environment", "environment_variables"}:
                clean[key] = "<REDACTED_ENVIRONMENT_FIELDS>"
                changes["environment_fields_removed"] = changes.get("environment_fields_removed", 0) + 1
            elif key == "platform" and isinstance(item, list) and len(item) == 5:
                clean[key] = {"system": item[0], "release": item[2],
                              "version": item[3], "machine": item[4]}
                changes["uname_nodename_removed"] = changes.get("uname_nodename_removed", 0) + 1
            else:
                clean[key] = scrub_fields(item)
        return clean
    try:
        document = json.loads(text)
    except (ValueError, TypeError):
        pass
    else:
        cleaned = scrub_fields(document)
        if changes:
            text = json.dumps(cleaned, ensure_ascii=False, indent=2) + "\n"
    for label, value, replacement in (
        ("workspace_path", workspace, "<A3_WORKSPACE>"),
        ("hostname", hostname, "<REDACTED_HOST>"),
    ):
        if len(value) > 3:
            count = text.count(value)
            if count:
                text = text.replace(value, replacement)
                changes[label] = count
    # Home/user paths in command diagnostics; no arbitrary source rewriting.
    text, n = re.subn(r"/(?:home|Users)/[^/\s\"'<>]+", "/home/<REDACTED_USER>", text)
    if n:
        changes["user_home_path"] = n
    return text, changes


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--source", required=True, type=Path)
    ap.add_argument("--output", required=True, type=Path)
    ap.add_argument("--archive", required=True, type=Path)
    ap.add_argument("--workspace-root", required=True)
    args = ap.parse_args()
    source = args.source.resolve()
    output = args.output.resolve()
    archive = args.archive.resolve()
    if (output == source or output.is_relative_to(source) or archive.is_relative_to(source)
            or archive.is_relative_to(output)):
        ap.error("public outputs must be outside original raw source")
    if archive.exists():
        ap.error("refusing to overwrite public archive")
    output.mkdir(parents=True, exist_ok=False)
    report = {"schema": "a3-public-evidence-redaction.v1", "classification": "PUBLIC_REDACTED_COPY",
              "original_raw": "PRIVATE_RETURN_ONLY", "source_root_label": "evidence",
              "policy": "No binaries/source mirrors/environment fields; scan included text for listed credential/email forms; remove local workspace, hostname and user-home paths; retain permitted versions/UID/GID/capability facts",
              "limitations": "Literal pattern scan plus project-scope review; not an exhaustive secret detector",
              "patterns": sorted(SECRET_PATTERNS), "included": {}, "excluded": {}, "findings": [],
              "result": "IN_PROGRESS", "script": pin(Path(__file__).read_bytes())}
    host = os.uname().nodename if hasattr(os, "uname") else ""
    for path in sorted(source.rglob("*")):
        relative = path.relative_to(source)
        name = relative.as_posix()
        if path.is_symlink():
            raise ValueError("symlink in original evidence: " + name)
        if not path.is_file():
            continue
        data = path.read_bytes()
        original_pin = pin(data)
        if set(relative.parts) & SKIP_COMPONENTS:
            report["excluded"][name] = {"original": original_pin, "reason": "source mirror or disposable test fixture; private return only"}
            continue
        allowed_text = (path.suffix in (".json", ".txt", ".md", ".raw") or
                        path.name.endswith((".stdout.bin", ".stderr.bin")))
        if not allowed_text:
            report["excluded"][name] = {"original": original_pin, "reason": "not in public text-evidence allowlist; private return only"}
            continue
        try:
            value = data.decode("utf-8")
        except UnicodeDecodeError:
            report["excluded"][name] = {"original": original_pin, "reason": "binary; private return only"}
            continue
        if "\x00" in value or path.suffix in (".o", ".pyc"):
            report["excluded"][name] = {"original": original_pin, "reason": "binary/object; private return only"}
            continue
        found = findings(value)
        if found:
            report["findings"].append({"path": name, "pattern_counts": found})
        public, changes = redact(value, args.workspace_root, host)
        found_public = findings(public)
        if found_public:
            report["findings"].append({"path": name, "public_pattern_counts": found_public})
        target = output / "redacted" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        public_bytes = public.encode("utf-8")
        target.write_bytes(public_bytes)
        report["included"][name] = {"original": original_pin, "public": pin(public_bytes),
                                    "redactions": changes, "copy_classification": "PUBLIC_REDACTED_COPY"}
    report["result"] = ("FAIL_REVIEW_REQUIRED" if report["findings"] else
                         "PASS_PUBLIC_COPY_SCAN" if report["included"] else "FAIL_EMPTY_EVIDENCE")
    (output / "REDACTION_MANIFEST.json").write_text(json.dumps(report, indent=2) + "\n")
    (output / "PUBLIC_REDACTED_README_RU.md").write_text(
        "# Публичная редактированная копия evidence A3 v1\n\n"
        "Это явно помеченная PUBLIC_REDACTED_COPY. Оригинальные raw находятся только "
        "в приватном полном возврате. Локальные workspace/home paths и hostname "
        "заменены маркерами; поля environment удалены из публичных отчётов. "
        "Binary objects и повторные source mirrors не публикуются.\n\n"
        "REDACTION_MANIFEST.json связывает SHA-256 оригинала и публичной копии каждого "
        "включённого файла; исходные логи не изменены. Для файла без требуемой замены "
        "хеши совпадают, но он всё равно входит в явно маркированную публичную копию.\n\n"
        "Проверка literal credential/email patterns не является доказательством "
        "отсутствия любых возможных секретов. Evidence дополнительно просмотрено "
        "в пределах source-only задания. Ненулевые rc, FAIL и BLOCKED сохранены.\n")
    if report["result"] != "PASS_PUBLIC_COPY_SCAN":
        print(json.dumps({"result": report["result"], "flagged_records": len(report["findings"])}))
        return 1
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(output.rglob("*")):
            if not path.is_file():
                continue
            info = zipfile.ZipInfo(path.relative_to(output).as_posix(), (2026, 11, 3, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, path.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise ValueError("public ZIP CRC check failed")
    print(json.dumps({"result": report["result"], "included": len(report["included"]),
                      "excluded": len(report["excluded"]), "archive": pin(archive.read_bytes())}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
