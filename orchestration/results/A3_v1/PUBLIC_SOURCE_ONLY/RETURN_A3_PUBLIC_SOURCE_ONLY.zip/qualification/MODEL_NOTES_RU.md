# A3 v1: повтор моделей и защита evidence

Окончательный `model_qualification.py` повторил неизменённые исходные runners:
**core 130/130, intake 380/380**, без ошибок assertions. Это исполняемые модели с
заменой системных операций; native Main/H/Node/bundle не исполнялись. Локальный
`euid=0` не используется как свидетельство профиля Main и не разрешает socket
fixtures. У моделей нет реальных subject-системных вызовов: предварительный
независимый review проверил macro replacements и отсутствие inline assembly и
dynamic-loader обходов; исходный symbol guard разрешает только перечисленные
libc функции памяти, форматирования и тестового управления.

Точная review-квитанция находится в `reviews/EXACT_SOURCE_REVIEW.json` и содержит
14 source pins. Старые runners, модели, core и intake сохранены без изменений.
Новая qualification-обёртка проверяет полный manifest из 59 файлов до и после
работы. Каждый запуск сохраняет stdout/stderr/rc, argv, версии и source hashes.

## Внешняя проверка полноты

Исторический core runner проверял последний summary без достаточной проверки
всех строк. A3 сохраняет этот runner и проверяет его сырой вывод дополнительно:

- JSONL должен быть полным UTF-8 с завершающим newline; повторные JSON keys,
  пустые строки и значения вместо JSON objects запрещены.
- Ровно один summary должен быть последней строкой. Каждый case имеет уникальный
  известный ID, строго boolean `passed`, пустой массив `errors` и точный mode.
- Case inventory восстанавливается из литералов неизменённого source и его
  явных циклов. Для динамических intake-сценариев F01/F02 используются отдельно
  закреплённые счётчики F00: критик независимо пересчитал их по source/trace.
  Сам F00 обязан совпадать с этими счётчиками; совместная подделка F00 и списка
  сценариев не уменьшает обязательный inventory.
- Счётчики summary равны подсчитанным case rows. Core имеет ровно 130 сценариев,
  intake — 380. Receipt не может заявлять release/exec; intake также не может
  заявлять birth. Все classifications остаются model-only.

`model_expectations.json` описывает источник этих expectations и закреплён SHA
в runner. Это проверка целостности evidence и полноты конкретной модели, а не
независимый oracle поведения или физическая квалификация.

## Три сценария независимого критика

| Сценарий | Реальная отрицательная проверка | Результат |
|---|---|---|
| Устаревший review разрешает изменённую модель | Изменён только ожидаемый SHA в отдельной review-квитанции; вызван исходный intake runner | `rc=2`, `NOT_RUN`, список compiler/model actions пуст |
| Неперехваченный OS-symbol попадает в исполняемую модель | В отдельную копию core **model** добавлена inert `used` функция с `getuid()` | `rc=1`, unexpected symbol `getuid`; link/run отсутствуют, executable не создан |
| Поздний успешный summary скрывает потерю/провал case | Поддельные in-memory варианты журнала: hidden fail, duplicate/missing case, duplicate summary, неверный count/mode/type, truncation, duplicate key, scalar; также совместное сокращение F00 и F01 | Все варианты отвергнуты, исходный raw не изменялся |

В финальном attempt2 выполнено 11 отрицательных проверок формата/полноты для
core, 12 для intake и две проверки реальных gates. Ожидаемые ненулевые rc
сохранены как исходные отказавшие вызовы и отдельно оценены как успешные
негативные проверки. Они не переименованы в успешный запуск модели.

`attempt1` сохранён полностью: 130/380 cases и исходный набор отрицательных
проверок. После замечания критика защита evidence усилена без изменения subject
source; `attempt2` относится к окончательным bytes qualification runner. Новых
необязательных повторов после достаточной проверки не выполнялось.

## Точное повторение

Из корня checkout с закреплённым input:

```sh
python3 orchestration/results/A3_v1/qualification/model_qualification.py --input-dir orchestration/stages/A3_qualification_v1/input --output-dir a3-model-replay --review-json orchestration/results/A3_v1/reviews/EXACT_SOURCE_REVIEW.json
```

Каталог output должен отсутствовать. В полном приватном возврате можно заменить
`--input-dir` на `orchestration/results/A3_v1/BASES/input`. Это неизменная копия
всех предоставленных входов, проверенная по исходному manifest.
