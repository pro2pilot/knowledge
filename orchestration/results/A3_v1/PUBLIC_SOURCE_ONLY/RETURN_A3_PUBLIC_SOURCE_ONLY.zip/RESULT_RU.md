# Knowledge A3 qualification v1 — результат

**Compile-only transitive dependency gap полного private derivative Main закрыт.**
Этап в целом остаётся **PARTIAL**: ordinary socket runtime в Pro заблокирован
условиями среды, а GitHub write отклонён инструментом. Полный результат,
неизменные bases, все raw и точный Actions request возвращаются файлами.

**Новый result commit: отсутствует (`null`).** Это не SHA входа. Единственная
попытка создать Git tree из 17 проверенных source-only additions вернула
`user rejected MCP tool call`, без дополнительной причины и без SHA. Повторной
записи или другого write-маршрута не было. Read-only проверка после отказа
подтвердила HEAD ветки `codex/stage-a3-v1-20261103`:
`0684ffa0d132675233d7d9602121f02bb50ff6eb`.

## Результат по свойствам

| Свойство | Статус A3 | Основание и предел |
|---|---|---|
| Полнота исходного input | DONE | 59/59 manifest payload files: длина и SHA-256 совпадают; 502074 payload bytes. Manifest — отдельные 10003 bytes |
| Immutable boundary | DONE | BASE_MAIN, core24700, intake, original derivative/generator и остальные input bytes совпадают до/после. В продукт ничего не внедрено |
| Полный derivative preprocessing и strict compile | DONE_COMPILE_ONLY | Реальные headers, полный неизменный derivative, qualification wrapper; `.o` создан, native link/run отсутствует |
| Native body emission | DONE_COMPILE_ONLY | 15 nonempty LOCAL FUNC в `.text`, disassembly и 15 retention relocations; executable `main` отсутствует |
| Реальная preprocess closure | DONE для данной компиляции | 229 dependencies: 28 pinned project files, 200 system headers, один wrapper; все разрешённые пути и SHA сохранены |
| Историческая upstream provenance deps | PARTIAL | Точно проверен A3 commit/input manifest. Отдельного upstream commit/path для каждого deps-файла вход не содержит |
| Exact derivative reproduction | DONE_SOURCE_ONLY | Оригинальный generator, 11/11 проверок, включая fresh write и отказы; generator fixes не понадобились |
| Core syscall model | DONE_SOURCE_MODEL_ONLY | 130/130 уникальных cases, 0 FAIL в окончательном replay |
| Intake syscall model | DONE_SOURCE_MODEL_ONLY | 380/380 уникальных cases, 0 FAIL в окончательном replay |
| Защита model evidence | DONE | 23 forged-evidence negatives + stale review и unexpected OS-symbol; отказы до compiler/link/run подтверждены там, где требуются |
| Ordinary fixture source | PARTIAL, подготовлен и reviewed | 6 групп × 3 сценария; exact review receipt и ограниченный runner готовы |
| Ordinary fixture runtime в Pro | BLOCKED | Наблюдались EUID=0, EGID=0. Разрешены только unprivileged fixtures. Socket/pipe/pidfd/fork/kcmp fixture attempts = 0 |
| Оригинальный WSL/profile, physical PID reuse, namespace ABA | NOT_PROVEN / NOT_RUN | Не подменяются моделями, компиляцией или ordinary Linux observations |
| Полная offer / identity reservation / release / positive exec | НЕ КВАЛИФИЦИРОВАНО | Core/intake behavior не менялся. Терминальная граница `EOPNOTSUPP` сохранена |
| Прямой GitHub result commit | BLOCKED | Реальный отказ write сохранён; main/tags/releases/другие этапы не изменялись |
| Переход к Actions | Подготовлен pinned request; NOT_DISPATCHED | Exact embedded code ZIP + input commit + argv; стандартный runner, 10 min, no secrets/native subject |

Исходный ZIP скачать не удалось: первая попытка получила `EPERM`. Она не
повторялась. Поэтому оригинальные ZIP SHA/CRC **не объявляются проверенными
локально**. Вместо этого все текстовые файлы восстановлены через GitHub
connector ровно по закреплённому commit и приняты только после проверки bytes
и SHA. Предоставленный ожидаемый ZIP SHA сохранён в acquisition evidence.

## Закреплённый вход и поправка оркестратора

Input commit: `0684ffa0d132675233d7d9602121f02bb50ff6eb`.

SHA-256 исходного `MANIFEST.json`:

```
8ac2c1b86170c70dcee36f5a4fe878688e32f9ca0b7f8032998316fd79a8eb55
```

В `deps/` ровно **32 `.h`**. Оркестратор отдельно подтвердил, что «34» в
исходном PROMPT — описательная ошибка, а не требование искать два файла.
Поправка записана в `reviews/ORCHESTRATOR_AMENDMENT_RU.md`; вход не редактировался.

## Что изменено

Только новые результаты под `orchestration/results/A3_v1/`:

- Qualification wrapper и воспроизводимый compile-only runner, generator
  negative checks, guarded model replay с внешней проверкой целостности JSONL.
- Отдельные ordinary Python fixtures, runner и независимая exact-source review.
- Pinned Actions recipe/bootstrap с embedded source package, без Node actions,
  git checkout, secrets, sudo или изменения host settings.
- Offline apply helper, public-evidence exporter, review и handoff-документы.

Core, intake identity policy, BASE_MAIN, исторический generator и derivative
не заменялись. Полные input bases находятся в приватном `BASES/input/`.
`CHANGESET.json` содержит immutable before/after pins и перечень основных
additions; `MANIFEST.json` связывает все payload файлы полного возврата.

### Почему нужен wrapper

Первый прямой strict compile полного derivative завершился `rc=1`: шесть
private core functions не используются terminal-only derivative. Это настоящий
сохранённый FAIL, а не пропущенный dependency. Preprocessing с реальными
предоставленными headers уже проходил.

Qualification wrapper включает derivative целиком и удерживает native entry
functions в типизированных `static const used` таблицах. Сохранены
`-Wall -Wextra -Werror -Wpedantic -O2`; предупреждения не подавлены, stubs не
подставлены. `readelf`, `nm`, disassembly и relocations подтверждают непустые
локальные тела. Объект не линковался и не запускался. Совместимость declarations
при этой компиляции не доказывает runtime ABI или полную product link closure.

Исторический `DERIVATIVE_PINS.json` по-прежнему содержит старый
`BLOCKED_MISSING_PINNED_TRANSITIVE_HEADERS`. Его точные bytes сохранены;
новое compile-only состояние описано отдельным A3 evidence.

### Модели и качество доказательств

Оригинальные runners и модели выполнены без source edits. Перед model link/run
проверены unresolved symbols. Внешний A3 validator дополнительно требует
полный inventory, уникальные IDs, ровно один последний summary, строгие types,
согласованные counters и model-only classifications.

Критик отдельно перепроверил F00 operation counts для динамических intake
cases. Они закреплены независимо от проверяемого вывода: согласованное удаление
события F00 и соответствующего F01 больше не сокращает обязательный inventory.
Это evidence-integrity проверка конкретной модели, а не physical oracle.

Сохранены оба model attempts. Окончательный `attempt2` относится к текущим
qualification bytes: **130 core + 380 intake**. Дополнительный `getuid` sentinel
был добавлен только в disposable model copy и отвергнут до link/run. Никакой
native subject не был запущен ради отрицательной проверки.

## Ordinary fixtures и переносимый blocker

Подготовлены три сценария на каждую группу:

1. Credential sender substitution: inherited endpoint, queued creator message,
   EOF при ещё живом original creator.
2. Peer death: умерший creator с живым delegated endpoint, retained dead pidfd/
   proc, held namespace handle как object observation.
3. Ancillary: `MSG_TRUNC`/`MSG_CTRUNC`, zero-payload record с rights и отдельный EOF,
   duplicate OFD rights и auto `SCM_PIDFD`; sweep до принятия решения.
4. Pipes/OFD: разделённые pipe objects, общие flags у dup alias, задержка EOF
   оставшимся writer alias.
5. Namespace observations: последовательные read-only наблюдения, явный
   `N2_ABA_namespace_transition=NOT_RUN`, пределы held handles и final equality.
6. Time: исходные S/W/C после EAGAIN, late receive/late cleanup, отмена без
   нового time budget.

Runner проверяет source review, exact input pins, frozen source bytes и
результат после выполнения. Timeout сохраняет оба partial outputs; signal не
выдаётся за termination. Подтверждается только наблюдаемый `leader_reaped`,
`all_descendants_reaped` остаётся `null`.

Здесь не было ни одной runtime попытки fixtures после обнаружения root EUID/GID.
Это **unprivileged precondition blocker**, а не якобы наблюдавшийся UNIX socket
`EPERM`. После отказа общей suite prerequisite остальные группы консервативно
остаются NOT_RUN; это не утверждение о неподдержке каждого их невызванного API.

## Точный Actions request

`ACTIONS_REQUEST.json` принят независимым review и связывает:

| Файл | SHA-256 |
|---|---|
| `qualification/ACTIONS_SOURCE_PAYLOAD.zip` | `a3d177ff029979ae21a8f7c04a59acc0796a4af3e671c8d32275ec41e12244fb` |
| `qualification/actions_prepare_and_run.py` | `eaaf0a91badd8b5063364c24e667e4b40320964bdcec70ed3e7290ba59afb9c7` |
| `qualification/ACTIONS_JOB_RECIPE.yml` | `2421d1cea7186b1af8c96ea72c64c005bd0695e51ecf9e6bcc83078cd188c712` |
| `ACTIONS_REQUEST.json` | `a550c553bc8a8195ee8a8ac1aec2f0b3e2c21be322fcb0845b889fd854b9f99d` |

Recipe содержит точные source bytes в трёх base64 chunks. Перед исполнением
проверяются ZIP SHA/CRC, ровно шесть members, все file pins и оригинальные
59 input files из commit `0684ffa0…`. Это позволяет перенести запрос без
выдуманного code commit и без доверия движущемуся branch HEAD.

Параметры: `ubuntu-24.04`, **10-minute job cap**, `permissions: {}`, только
`workflow_dispatch`; без `uses`, `pull_request_target`, secrets, native subject,
sudo, установки зависимостей или persistent runner. Ordinary runner ограничен
60 секундами. Прямой argv также указан в JSON и `ordinary_README_RU.md`.

Артефакты будущего запроса:

- `knowledge-a3-v1-ordinary-private-raw.zip` — только private collection
  оркестратора.
- `knowledge-a3-v1-ordinary-public-redacted.zip` — после успешной отдельной
  проверки/редактирования публичной копии.
- `A3_v1-bootstrap-evidence` — private bootstrap stdout/stderr/rc, включая отказ
  до создания ordinary archives.

Recipe сам ничего не загружает наружу. Оркестратор должен подготовить private
collector **до dispatch**. Наличие filenames в request не означает, что job
или uploads выполнены; bootstrap отдельно записывает фактический
`artifact_presence`. Workflow не установлен: разрешённый path этого этапа не
включает `.github/workflows/`.

## Все FAIL сохранены

Сохранены прямой compile FAIL, ожидаемые generator/review/symbol refusals,
все предыдущие attempts и реальный transport FAIL: первоначальная recipe
добавляла один лишний LF к bootstrap. Исправлен именно этот байт; повторное
сравнение не применяло strip/rstrip. Пять offline bootstrap negatives доказали
отказ до fetch/urlopen/entry, без сети и fixtures. Старые recipe и request
сохранены рядом с первоначальным FAIL.

Независимый критик — реальный отдельный subagent. Его `CRITIC_RU.md` содержит
**42 сценария: по три на каждую из 14 ключевых групп**. Два implementation
subagents работали параллельно. Недоступность субагентов не симулировалась.

## Передача и применение

Полный приватный возврат содержит raw, bases и бинарные compiler artifacts как
инертные данные. Для GitHub подготовлен отдельный `publication/PUBLIC_RESULT/`
с собственным manifest и явно отмеченным `PUBLIC_RAW_REDACTED.zip`. Public
копии имеют связь original/public SHA, локальные paths/hostname/environment
fields удалены. Полного env dump не делалось. Разрешённые версии и UID/GID/
capability facts сохранены.

Порядок применения — `APPLY_RU.md`; точное продолжение — `NEXT_CHAT_RU.txt`.
Итоговые CRC/SHA и fresh-application raw записываются в отдельный
`RETURN_A3_v1_POST_ZIP.zip`, сопровождающий основной архив. Такая отдельная
квитанция проверяет уже завершённый ZIP и не создаёт самоссылочного hash.

START UTC: **2026-11-02 23:24:04**. Hard stop: **2026-11-03 03:24:04 UTC**.
Работа завершается до контрольного третьего часа. Background continuation не
заявляется. Source/model/compile не являются physical proof или release PASS.
